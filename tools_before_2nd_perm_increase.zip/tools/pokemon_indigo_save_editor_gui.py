#!/usr/bin/env python
"""Pokemon Indigo Save Editor GUI (PKHeX-like lite).

Desktop editor for Pokemon Indigo / Pokemon Anil save files.
Uses the cycle-aware Ruby Marshal core from pokemon_indigo_save_editor.py.
"""

from __future__ import annotations

import argparse
import io
import json
import math
import random
import re
import shutil
import sys
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

import tkinter as tk
from tkinter import font as tkfont
from tkinter import filedialog, messagebox, ttk


HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import pokemon_indigo_save_editor as core  # noqa: E402
from pokemon_indigo_game_data import GameCatalogs, parse_pbs_sections  # noqa: E402
try:
    import pokemon_indigo_probe_mapper as probe_mapper  # noqa: E402
except Exception:  # noqa: BLE001
    probe_mapper = None

EN_POCKET_NAMES = {
    0: "Unused",
    1: "Items",
    2: "Medicine",
    3: "Poke Balls",
    4: "TMs & HMs",
    5: "Berries",
    6: "Mega Stones",
    7: "Battle Items",
    8: "Key Items",
}

DEX_CATEGORY_LABEL_TO_KEY = {
    "Pokédex": "Species",
    "Moves dex": "Moves",
    "Items dex": "Items",
    "Abilities dex": "Abilities",
    "Natures dex": "Natures",
    "Types dex": "Types",
}
DEX_CATEGORY_KEY_TO_LABEL = {value: key for key, value in DEX_CATEGORY_LABEL_TO_KEY.items()}
DEX_CATEGORY_LABELS = list(DEX_CATEGORY_LABEL_TO_KEY.keys())

STAT_ORDER = [
    ("HP", "HP"),
    ("ATTACK", "Atk"),
    ("DEFENSE", "Def"),
    ("SPECIAL_ATTACK", "SpA"),
    ("SPECIAL_DEFENSE", "SpD"),
    ("SPEED", "Spe"),
]
STAT_SHORT_LABELS = {sid: short for sid, short in STAT_ORDER}

TYPE_COLOR_HEX = {
    "NORMAL": "#A8A77A",
    "FIRE": "#EE8130",
    "WATER": "#6390F0",
    "ELECTRIC": "#F7D02C",
    "GRASS": "#7AC74C",
    "ICE": "#96D9D6",
    "FIGHTING": "#C22E28",
    "POISON": "#A33EA1",
    "GROUND": "#E2BF65",
    "FLYING": "#A98FF3",
    "PSYCHIC": "#F95587",
    "BUG": "#A6B91A",
    "ROCK": "#B6A136",
    "GHOST": "#735797",
    "DRAGON": "#6F35FC",
    "DARK": "#705746",
    "STEEL": "#B7B7CE",
    "FAIRY": "#D685AD",
}
TYPE_LIGHT_BG_IDS = {"NORMAL", "ELECTRIC", "GROUND", "ICE", "STEEL", "FAIRY"}
TYPE_SHORT_LABELS = {
    "NORMAL": "NRM",
    "FIRE": "FIR",
    "WATER": "WAT",
    "ELECTRIC": "ELE",
    "GRASS": "GRS",
    "ICE": "ICE",
    "FIGHTING": "FIG",
    "POISON": "PSN",
    "GROUND": "GRD",
    "FLYING": "FLY",
    "PSYCHIC": "PSY",
    "BUG": "BUG",
    "ROCK": "RCK",
    "GHOST": "GST",
    "DRAGON": "DRG",
    "DARK": "DRK",
    "STEEL": "STL",
    "FAIRY": "FRY",
}
TYPE_CHIP_FIXED_WIDTH = 10
TYPE_CHIP_COMPACT_WIDTH = max(4, TYPE_CHIP_FIXED_WIDTH // 2)
LOW_QUALITY_DESC_TOKENS = {"he", "she", "it", "none", "n/a", "na", "null", "undefined"}

NATURE_EFFECTS = {
    "LONELY": ("ATTACK", "DEFENSE"),
    "BRAVE": ("ATTACK", "SPEED"),
    "ADAMANT": ("ATTACK", "SPECIAL_ATTACK"),
    "NAUGHTY": ("ATTACK", "SPECIAL_DEFENSE"),
    "BOLD": ("DEFENSE", "ATTACK"),
    "RELAXED": ("DEFENSE", "SPEED"),
    "IMPISH": ("DEFENSE", "SPECIAL_ATTACK"),
    "LAX": ("DEFENSE", "SPECIAL_DEFENSE"),
    "TIMID": ("SPEED", "ATTACK"),
    "HASTY": ("SPEED", "DEFENSE"),
    "JOLLY": ("SPEED", "SPECIAL_ATTACK"),
    "NAIVE": ("SPEED", "SPECIAL_DEFENSE"),
    "MODEST": ("SPECIAL_ATTACK", "ATTACK"),
    "MILD": ("SPECIAL_ATTACK", "DEFENSE"),
    "QUIET": ("SPECIAL_ATTACK", "SPEED"),
    "RASH": ("SPECIAL_ATTACK", "SPECIAL_DEFENSE"),
    "CALM": ("SPECIAL_DEFENSE", "ATTACK"),
    "GENTLE": ("SPECIAL_DEFENSE", "DEFENSE"),
    "SASSY": ("SPECIAL_DEFENSE", "SPEED"),
    "CAREFUL": ("SPECIAL_DEFENSE", "SPECIAL_ATTACK"),
}

MOVE_FUNCTION_EXACT_HINTS = {
    "StartHealUserEachTurn": "Heals user by 1/16 max HP at end of each turn.",
    "StartHealUserEachTurnTrapUserInBattle": "Heals user by 1/16 max HP each turn and traps user in battle.",
    "HealUserHalfOfTotalHP": "Heals user by 1/2 max HP.",
    "HealTargetHalfOfTotalHP": "Heals target by 1/2 max HP.",
    "HealUserAndAlliesQuarterOfTotalHP": "Heals user and allies by 1/4 max HP.",
    "HealUserAndAlliesQuarterOfTotalHPCureStatus": "Heals user and allies by 1/4 max HP and cures status.",
    "HealUserByHalfOfDamageDone": "Recovers HP equal to 1/2 of damage dealt.",
    "HealUserByHalfOfDamageDoneBurnTarget": "Recovers HP equal to 1/2 of damage dealt.",
    "HealUserByThreeQuartersOfDamageDone": "Recovers HP equal to 3/4 of damage dealt.",
    "MaxUserAttackLoseHalfOfTotalHP": "Sets Attack to +6 and costs 1/2 max HP.",
    "UserLosesHalfOfTotalHP": "User loses 1/2 max HP.",
    "UserLosesHalfOfTotalHPExplosive": "User loses 1/2 max HP.",
    "RecoilHalfOfDamageDealt": "User takes recoil equal to 1/2 of damage dealt.",
    "RecoilThirdOfDamageDealt": "User takes recoil equal to 1/3 of damage dealt.",
    "RecoilThirdOfDamageDealtBurnTarget": "User takes recoil equal to 1/3 of damage dealt.",
    "RecoilThirdOfDamageDealtParalyzeTarget": "User takes recoil equal to 1/3 of damage dealt.",
    "RecoilQuarterOfDamageDealt": "User takes recoil equal to 1/4 of damage dealt.",
    "RecoilHalfOfTotalHP": "User takes recoil equal to 1/2 max HP.",
    "FixedDamageHalfTargetHP": "Deals damage equal to 1/2 of target's current HP.",
    "StartLeechSeedTarget": "Leech Seed drains 1/8 max HP from target each turn.",
}

ITEM_NUMERIC_HINTS = {
    "LEFTOVERS": "Heals holder by 1/16 max HP at end of each turn.",
    "BLACKSLUDGE": "Poison-type holders heal 1/16 max HP per turn; other holders lose 1/8 max HP per turn.",
    "LIFEORB": "Moves deal 1.3x damage; user loses 1/10 max HP after a damaging hit.",
    "EVIOLITE": "If holder can still evolve, Defense and Sp. Def are multiplied by 1.5x.",
    "BIGROOT": "Drain/healing-from-damage effects are multiplied by 1.3x.",
    "CHOICEBAND": "Attack is multiplied by 1.5x; holder is locked into the first selected move.",
    "CHOICESPECS": "Sp. Atk is multiplied by 1.5x; holder is locked into the first selected move.",
    "CHOICESCARF": "Speed is multiplied by 1.5x; holder is locked into the first selected move.",
    "EXPERTBELT": "Super-effective moves deal 1.2x damage.",
    "MUSCLEBAND": "Physical move damage is multiplied by 1.1x.",
    "WISEGLASSES": "Special move damage is multiplied by 1.1x.",
    "ASSAULTVEST": "Sp. Def is multiplied by 1.5x; status moves cannot be selected.",
    "SHELLBELL": "Holder heals by 1/8 of damage dealt.",
    "ROCKYHELMET": "Contact attackers lose 1/6 max HP.",
    "FOCUSSASH": "From full HP, holder survives an otherwise fatal hit at 1 HP.",
}

ABILITY_NUMERIC_HINTS = {
    "INTIMIDATE": "On switch-in, lowers adjacent foes' Attack by 1 stage.",
    "STEADFAST": "If flinched, raises user's Speed by 1 stage.",
    "JUSTIFIED": "When hit by a Dark-type move, raises user's Attack by 1 stage.",
    "SOLARPOWER": "In sun, Sp. Atk is multiplied by 1.5x and user loses 1/8 max HP each turn.",
    "THICKFAT": "Fire- and Ice-type damage taken is halved (0.5x).",
    "HUGEPOWER": "Attack is doubled (2.0x).",
    "PUREPOWER": "Attack is doubled (2.0x).",
    "GUTS": "With a major status, Attack is multiplied by 1.5x.",
    "MARVELSCALE": "With a major status, Defense is multiplied by 1.5x.",
    "SWIFTSWIM": "In rain, Speed is doubled (2.0x).",
    "CHLOROPHYLL": "In sun, Speed is doubled (2.0x).",
    "SANDRUSH": "In sandstorm, Speed is doubled (2.0x).",
    "SLUSHRUSH": "In snow/hail, Speed is doubled (2.0x).",
    "SPEEDBOOST": "At end of each turn, raises Speed by 1 stage.",
    "QUICKFEET": "With a major status, Speed is multiplied by 1.5x.",
    "LIGHTNINGROD": "Draws Electric moves and grants +1 Sp. Atk when triggered.",
}

FUNCTION_STAT_TOKEN_LABELS = (
    ("CriticalHitRate", "critical-hit rate"),
    ("MainStats", "all main stats"),
    ("SpAtk", "Sp. Atk"),
    ("SpDef", "Sp. Def"),
    ("Attack", "Attack"),
    ("Defense", "Defense"),
    ("Accuracy", "Accuracy"),
    ("Evasion", "Evasion"),
    ("Speed", "Speed"),
    ("Atk", "Attack"),
    ("Def", "Defense"),
    ("Spd", "Speed"),
    ("Acc", "Accuracy"),
)


def symbol_name(value: Any) -> str:
    if isinstance(value, core.Symbol):
        return value.name
    if isinstance(value, core.RubyString):
        return str(value)
    if value is None:
        return ""
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.decode("latin-1", errors="replace")
    return str(value)


def to_symbol_or_none(text: str):
    clean = text.strip()
    if not clean:
        return None
    return core.Symbol(clean.lstrip(":"))


def parse_int(text: str, field_name: str) -> int:
    try:
        return int(text.strip())
    except ValueError as exc:
        raise ValueError(f"{field_name} must be an integer.") from exc


def extract_internal_id(text: str) -> str:
    raw = text.strip()
    if "|" in raw:
        raw = raw.split("|", 1)[0].strip()
    return raw


class SaveEditorApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Pokemon Indigo Save Editor")
        self.root.geometry("1180x760")
        self.root.minsize(980, 660)

        self.game_root = HERE.parent
        self.save_path: Path | None = None
        self.save_data: Any = None
        self.modified = False
        self.catalogs: GameCatalogs | None = None
        self.catalog_error: str | None = None
        self.profile_lock_path = (
            probe_mapper.default_profile_path(self.game_root)
            if probe_mapper is not None
            else (self.game_root / "tools" / "editor_profile.lock.json")
        )
        self.profile_lock_data: dict[str, Any] | None = None
        self.profile_lock_warning: str | None = None
        self._translated_desc_cache: dict[str, str] = {}
        self._desc_widget_context: dict[str, tuple[str, str, int | None]] = {}
        self._desc_lock: dict[str, tuple[str, int | None] | None] = {"party": None, "bag": None}
        self._dex_type_chart_defense: dict[str, dict[str, float]] | None = None
        self._dex_type_order: list[str] = []
        self._dex_spawn_index: dict[str, list[dict[str, Any]]] | None = None
        self._dex_item_shop_index: dict[str, list[dict[str, Any]]] | None = None
        self._dex_move_tm_map: dict[str, list[str]] | None = None
        self._dex_wheel_bound_widgets: set[str] = set()
        self._dex_global_wheel_enabled = False
        self._dex_tooltip_window: tk.Toplevel | None = None
        self._dex_tooltip_label: tk.Label | None = None
        self._dex_tooltip_move_cache: dict[str, str] = {}
        self._dex_tooltip_ability_cache: dict[str, str] = {}
        self._party_tooltip_window: tk.Toplevel | None = None
        self._party_tooltip_label: tk.Label | None = None
        self._party_last_description_text = ""
        self._party_wheel_bound_widgets: set[str] = set()
        self._dex_map_names: dict[int, str] = {}
        self._dex_detail_sections: list[ttk.LabelFrame] = []
        self._dex_split_max_left_width = 0
        self._dex_split_min_left_width = 180
        self._dex_split_initialized = False
        self._party_evo_rendering = False
        self._party_evo_update_scheduled = False

        try:
            self.catalogs = GameCatalogs.load(self.game_root)
        except Exception as exc:  # noqa: BLE001
            self.catalogs = None
            self.catalog_error = str(exc)

        self._reload_profile_lock()
        self._build_ui()
        self._install_click_out_commit_behavior()
        self.refresh_save_list()

    # ------------------------- UI setup -------------------------
    def _build_ui(self):
        top = ttk.Frame(self.root, padding=8)
        top.pack(fill="x")

        ttk.Label(top, text="Save File:").pack(side="left")
        self.save_var = tk.StringVar()
        self.save_combo = ttk.Combobox(top, textvariable=self.save_var, width=80, state="readonly")
        self.save_combo.pack(side="left", padx=(6, 6), fill="x", expand=True)

        ttk.Button(top, text="Refresh", command=self.refresh_save_list).pack(side="left", padx=2)
        ttk.Button(top, text="Browse...", command=self.browse_save).pack(side="left", padx=2)
        ttk.Button(top, text="Load", command=self.load_selected_save).pack(side="left", padx=2)
        ttk.Button(top, text="Map Game Data", command=self.run_game_probe_wizard).pack(side="left", padx=2)
        self.save_btn = ttk.Button(top, text="Save Changes", command=self.write_save, state="disabled")
        self.save_btn.pack(side="left", padx=2)

        self.status_var = tk.StringVar(value="Ready.")
        ttk.Label(self.root, textvariable=self.status_var, padding=(8, 0, 8, 4)).pack(fill="x")

        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        self._build_trainer_tab()
        self._build_party_tab()
        self._build_bag_tab()
        self._build_dex_tab()
        self._build_flags_tab()
        self._build_advanced_tab()
        self._build_legality_tab()

    def _install_click_out_commit_behavior(self):
        self.root.bind_all("<Button-1>", self._on_global_click_commit, add="+")

    def _on_global_click_commit(self, event):
        focused = self.root.focus_get()
        if focused is None:
            self._sync_description_lock_from_clicked_widget(event.widget)
            return
        clicked = event.widget
        self._sync_description_lock_from_clicked_widget(clicked)
        if focused == clicked:
            return
        focused_name = str(focused).lower()
        clicked_name = str(clicked).lower()
        if "popdown" in focused_name or "popdown" in clicked_name:
            return
        # Force handlers bound to <FocusOut> to run even when clicking
        # on non-focusable widgets (labels/frames/empty area).
        try:
            focused.event_generate("<FocusOut>")
        except tk.TclError:
            pass

        def ensure_focus_shift():
            current = self.root.focus_get()
            if current is not focused:
                return
            try:
                clicked.focus_set()
            except tk.TclError:
                try:
                    self.root.focus_set()
                except tk.TclError:
                    pass

        self.root.after_idle(ensure_focus_shift)

    def _build_trainer_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="Trainer")
        tab.columnconfigure(0, weight=1)

        form = ttk.Frame(tab)
        form.pack(fill="x", expand=True)
        for col in (1, 3):
            form.columnconfigure(col, weight=1)

        self.trainer_name_var = tk.StringVar()
        self.trainer_id_var = tk.StringVar()
        self.trainer_type_var = tk.StringVar()
        self.money_var = tk.StringVar()
        self.coins_var = tk.StringVar()
        self.bp_var = tk.StringVar()
        self.save_slot_var = tk.StringVar()

        row = 0
        self._add_labeled_entry(form, "Name", self.trainer_name_var, row, 0)
        self._add_labeled_entry(form, "Trainer ID", self.trainer_id_var, row, 2, readonly=True)
        row += 1
        self._add_labeled_entry(form, "Trainer Type", self.trainer_type_var, row, 0)
        self._add_labeled_entry(form, "Save Slot", self.save_slot_var, row, 2)
        row += 1
        self._add_labeled_entry(form, "Money", self.money_var, row, 0)
        self._add_labeled_entry(form, "Coins", self.coins_var, row, 2)
        row += 1
        self._add_labeled_entry(form, "Battle Points", self.bp_var, row, 0)

        badges_frame = ttk.LabelFrame(tab, text="Badges", padding=8)
        badges_frame.pack(fill="x", pady=(12, 4))
        for col in range(4):
            badges_frame.columnconfigure(col, weight=1)
        self.badge_vars: list[tk.BooleanVar] = []
        self.badge_checks: list[ttk.Checkbutton] = []
        for i in range(8):
            v = tk.BooleanVar(value=False)
            c = ttk.Checkbutton(badges_frame, text=f"Badge {i + 1}", variable=v)
            c.grid(row=i // 4, column=i % 4, sticky="w", padx=6, pady=2)
            self.badge_vars.append(v)
            self.badge_checks.append(c)

        btns = ttk.Frame(tab)
        btns.pack(fill="x", pady=(10, 0))
        ttk.Button(btns, text="Apply Trainer Changes", command=self.apply_trainer_changes).pack(side="left")

    def _build_party_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="Party")
        tab.columnconfigure(0, weight=7, minsize=520)
        tab.columnconfigure(1, weight=3, minsize=220)
        tab.rowconfigure(0, weight=1)

        self.pk_species_var = tk.StringVar()
        self.pk_form_var = tk.StringVar()
        self.pk_level_var = tk.StringVar()
        self.pk_exp_var = tk.StringVar()
        self.pk_hp_var = tk.StringVar()
        self.pk_totalhp_var = tk.StringVar()
        self.pk_happiness_var = tk.StringVar()
        self.pk_nature_var = tk.StringVar()
        self.pk_item_var = tk.StringVar()
        self.pk_ability_var = tk.StringVar()
        self.pk_gender_var = tk.StringVar()
        self.pk_name_var = tk.StringVar()
        self.pk_shiny_var = tk.BooleanVar(value=False)
        self.pk_super_shiny_var = tk.BooleanVar(value=False)
        self.pk_attack_var = tk.StringVar()
        self.pk_defense_var = tk.StringVar()
        self.pk_spatk_var = tk.StringVar()
        self.pk_spdef_var = tk.StringVar()
        self.pk_speed_var = tk.StringVar()
        self.pk_obtain_level_var = tk.StringVar()
        self.pk_obtain_map_var = tk.StringVar()
        self.pk_obtain_method_var = tk.StringVar()
        self.pk_obtain_text_var = tk.StringVar()
        self.pk_hatched_map_var = tk.StringVar()
        self.pk_ability_index_var = tk.StringVar()
        self.pk_personal_id_var = tk.StringVar()
        self.pk_forced_form_var = tk.StringVar()
        self.pk_legacy_var = tk.StringVar()

        self._party_selected_mode: str | None = None
        self._party_selected_index: int | None = None
        self._party_selected_box_index: int | None = None

        self._party_ability_label_to_id: dict[str, str] = {}
        self._party_ability_id_to_label: dict[str, str] = {}
        self._party_nature_label_to_id: dict[str, str] = {}
        self._party_nature_id_to_label: dict[str, str] = {}
        self._party_move_label_to_id: dict[str, str] = {}
        self._party_move_id_to_label: dict[str, str] = {}
        self._party_relearn_label_to_id: dict[str, str] = {}
        self._party_relearn_id_to_label: dict[str, str] = {}
        self._party_hidden_abilities: set[str] = set()
        self._party_icon_cache: dict[str, tk.PhotoImage] = {}
        self._party_grid_icon_cache: dict[str, tk.PhotoImage] = {}
        self._party_preview_icon_cache: dict[str, tk.PhotoImage] = {}
        self._party_item_icon_cache: dict[str, tk.PhotoImage] = {}
        self._party_evo_scaled_icon_cache: dict[str, tk.PhotoImage] = {}
        self._party_evo_canvas_image_refs: list[tk.PhotoImage] = []
        self._evo_canvas_image_refs: dict[str, list[tk.PhotoImage]] = {}
        self._evo_chart_show_all_conditions = False
        self._party_grid_icon_scale = 2
        self._party_template_pokemon: core.RubyObject | None = None
        self._combo_all_values: dict[str, list[str]] = {}
        self._combo_nav_index: dict[str, int] = {}

        editor_shell = ttk.Frame(tab)
        editor_shell.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        editor_shell.columnconfigure(0, weight=0, minsize=96)
        editor_shell.columnconfigure(1, weight=1)
        editor_shell.rowconfigure(0, weight=1)

        nav = ttk.Frame(editor_shell)
        nav.grid(row=0, column=0, sticky="ns", padx=(0, 8))
        ttk.Label(nav, text="Editor", font=("", 9, "bold")).pack(anchor="w", pady=(0, 6))
        self.party_editor_section_var = tk.StringVar(value="Main")
        self.party_editor_sections: dict[str, ttk.Frame] = {}
        self.party_editor_order = ["Main", "Met", "Stats", "Moves", "Cosmetic", "OT/Misc"]
        for section in self.party_editor_order:
            tk.Radiobutton(
                nav,
                text=section,
                variable=self.party_editor_section_var,
                value=section,
                indicatoron=0,
                width=12,
                anchor="w",
                padx=8,
                pady=6,
                command=self._on_party_editor_section_changed,
            ).pack(fill="x", pady=(0, 2))

        content_shell = ttk.Frame(editor_shell, relief="groove", borderwidth=1)
        content_shell.grid(row=0, column=1, sticky="nsew")
        content_shell.columnconfigure(0, weight=1)
        content_shell.rowconfigure(0, weight=1)

        self.party_content_canvas = tk.Canvas(content_shell, borderwidth=0, highlightthickness=0)
        self.party_content_canvas.grid(row=0, column=0, sticky="nsew")
        self.party_content_vscroll = ttk.Scrollbar(
            content_shell, orient="vertical", command=self.party_content_canvas.yview
        )
        self.party_content_vscroll.grid(row=0, column=1, sticky="ns")
        self.party_content_canvas.configure(yscrollcommand=self.party_content_vscroll.set)
        self.party_content_canvas.bind("<MouseWheel>", self._on_party_content_mousewheel, add="+")
        self.party_content_canvas.bind("<Button-4>", self._on_party_content_mousewheel, add="+")
        self.party_content_canvas.bind("<Button-5>", self._on_party_content_mousewheel, add="+")
        self._party_wheel_bound_widgets = set()

        content = ttk.Frame(self.party_content_canvas, padding=8)
        self._party_content_window = self.party_content_canvas.create_window((0, 0), window=content, anchor="nw")
        content.bind(
            "<Configure>",
            self._on_party_content_frame_configure,
            add="+",
        )
        self.party_content_canvas.bind(
            "<Configure>",
            self._on_party_content_canvas_configure,
            add="+",
        )
        content.columnconfigure(0, weight=1)
        # Keep editor controls (top section) prioritized; evolution chart adapts to remaining height.
        content.rowconfigure(0, weight=1, minsize=260)
        content.rowconfigure(1, weight=0)

        for section in self.party_editor_order:
            frame = ttk.Frame(content)
            frame.grid(row=0, column=0, sticky="nsew")
            self.party_editor_sections[section] = frame

        species_values: list[str] = []
        item_values: list[str] = []
        if self.catalogs:
            base_species = self.catalogs.base_species_choices()
            if base_species:
                species_values = [item.internal_id for item in base_species]
            else:
                species_values = [item.internal_id for item in self.catalogs.species_by_id.values()]
            species_values.sort(key=str.casefold)
            item_values = sorted(self.catalogs.items_by_id.keys(), key=str.casefold)
            item_values.sort(key=str.casefold)

        self._build_party_main_section(self.party_editor_sections["Main"], species_values, item_values)
        self._build_party_met_section(self.party_editor_sections["Met"])
        self._build_party_stats_section(self.party_editor_sections["Stats"])
        self._build_party_moves_section(self.party_editor_sections["Moves"])
        self._build_party_cosmetic_section(self.party_editor_sections["Cosmetic"])
        self._build_party_ot_misc_section(self.party_editor_sections["OT/Misc"])
        self._build_party_evolution_section(content)
        self._bind_party_content_mousewheel_recursive(content)
        self._on_party_editor_section_changed()

        right = ttk.Frame(tab)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(0, weight=0)
        right.rowconfigure(1, weight=1)

        self._build_party_side_preview(right)

        slots_shell = ttk.LabelFrame(right, text="Box / Party Slots", padding=6)
        slots_shell.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        slots_shell.columnconfigure(0, weight=1)
        slots_shell.rowconfigure(2, weight=1)

        mode_row = ttk.Frame(slots_shell)
        mode_row.grid(row=0, column=0, sticky="w")
        self.party_view_mode_var = tk.StringVar(value="Party")
        ttk.Radiobutton(
            mode_row,
            text="Box",
            value="Box",
            variable=self.party_view_mode_var,
            command=self._on_party_mode_changed,
        ).pack(side="left")
        ttk.Radiobutton(
            mode_row,
            text="Party",
            value="Party",
            variable=self.party_view_mode_var,
            command=self._on_party_mode_changed,
        ).pack(side="left", padx=(6, 0))

        select_row = ttk.Frame(slots_shell)
        select_row.grid(row=1, column=0, sticky="ew", pady=(6, 6))
        select_row.columnconfigure(2, weight=1)
        ttk.Button(select_row, text="Refresh", command=self.refresh_party_tab).grid(row=0, column=0, padx=(0, 6))
        self.party_prev_box_btn = ttk.Button(select_row, text="<", width=3, command=self.party_prev_box)
        self.party_prev_box_btn.grid(row=0, column=1, padx=2)
        self.party_box_var = tk.StringVar()
        self.party_box_option_to_index: dict[str, int] = {}
        self.party_box_combo = ttk.Combobox(select_row, textvariable=self.party_box_var, state="readonly", width=24)
        self.party_box_combo.grid(row=0, column=2, sticky="ew", padx=2)
        self.party_box_combo.bind("<<ComboboxSelected>>", self.on_party_box_selected)
        self.party_next_box_btn = ttk.Button(select_row, text=">", width=3, command=self.party_next_box)
        self.party_next_box_btn.grid(row=0, column=3, padx=2)
        self.party_slot_status_var = tk.StringVar(value="Select a target slot.")
        ttk.Label(select_row, textvariable=self.party_slot_status_var).grid(
            row=1, column=0, columnspan=4, sticky="w", pady=(6, 0)
        )

        grid_host = ttk.Frame(slots_shell)
        grid_host.grid(row=2, column=0, sticky="nsew")
        grid_host.columnconfigure(0, weight=1)
        grid_host.rowconfigure(0, weight=1)
        self.party_grid_frame = ttk.Frame(grid_host, borderwidth=1, relief="solid", padding=2)
        self.party_grid_frame.grid(row=0, column=0, sticky="nsew")

        action_row = ttk.Frame(slots_shell)
        action_row.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        action_row.columnconfigure(3, weight=1)
        ttk.Button(action_row, text="Load Slot -> Editor", command=self.load_selected_slot_into_editor).grid(
            row=0, column=0, sticky="w"
        )
        ttk.Button(action_row, text="Apply Edit", command=self.apply_selected_pokemon).grid(
            row=0, column=1, sticky="w", padx=(6, 0)
        )
        ttk.Button(action_row, text="Set New To Slot", command=self.set_new_pokemon_to_selected_slot).grid(
            row=0, column=2, sticky="w", padx=(6, 0)
        )

        self._refresh_party_box_controls()
        self._on_party_mode_changed()
        self.refresh_party_legality_dropdowns(reset_invalid=False)
        self.update_party_editor_preview()
        self.update_party_evolution_chart()

    def _build_party_main_section(self, frame: ttk.Frame, species_values: list[str], item_values: list[str]):
        for col in (1, 3):
            frame.columnconfigure(col, weight=1)

        row = 0
        ttk.Label(frame, text="Species").grid(row=row, column=0, sticky="w", padx=(0, 6), pady=4)
        self.pk_species_combo = ttk.Combobox(
            frame, textvariable=self.pk_species_var, width=28
        )
        self.pk_species_combo.grid(row=row, column=1, sticky="ew", padx=(0, 16), pady=4)
        self._set_combo_values(self.pk_species_combo, species_values)
        self._enable_combo_search(self.pk_species_combo)
        self._register_description_widget(self.pk_species_combo, "party", "species")
        self.pk_species_combo.bind("<<ComboboxSelected>>", self.on_species_or_form_changed)
        self.pk_species_combo.bind("<<ComboboxSelected>>", lambda _e: self.update_party_description("species"), add="+")
        self.pk_species_combo.bind("<Enter>", lambda _e: self.update_party_description("species"), add="+")
        level_entry = self._add_labeled_entry(frame, "Level", self.pk_level_var, row, 2)
        level_entry.bind("<FocusOut>", lambda _e: self._refresh_stats_from_editor_inputs())
        self.pk_shiny_star_check = tk.Checkbutton(
            frame,
            text="★",
            variable=self.pk_shiny_var,
            command=self.on_shiny_changed,
            fg="#cc8a00",
            width=2,
        )
        self.pk_shiny_star_check.grid(row=row, column=4, sticky="w", padx=(4, 0), pady=4)
        row += 1

        form_entry = self._add_labeled_entry(frame, "Form", self.pk_form_var, row, 0)
        form_entry.bind("<FocusOut>", self.on_species_or_form_changed)
        self._add_labeled_entry(frame, "EXP", self.pk_exp_var, row, 2)
        row += 1

        ttk.Label(frame, text="Nature").grid(row=row, column=0, sticky="w", padx=(0, 6), pady=4)
        self.pk_nature_combo = ttk.Combobox(
            frame,
            textvariable=self.pk_nature_var,
            width=28,
        )
        self.pk_nature_combo.grid(row=row, column=1, sticky="ew", padx=(0, 16), pady=4)
        self._refresh_nature_choices()
        self._enable_combo_search(self.pk_nature_combo)
        self._register_description_widget(self.pk_nature_combo, "party", "nature")
        self.pk_nature_combo.bind("<<ComboboxSelected>>", self.on_nature_changed)
        self.pk_nature_combo.bind("<FocusOut>", self.on_nature_changed)
        self.pk_nature_combo.bind("<Enter>", lambda _e: self.update_party_description("nature"), add="+")
        gender_entry = self._add_labeled_entry(frame, "Gender", self.pk_gender_var, row, 2)
        gender_entry.bind("<FocusOut>", lambda _e: self.update_party_editor_preview(), add="+")
        row += 1
        ttk.Label(frame, text="Nature effect").grid(row=row, column=0, sticky="w", padx=(0, 6), pady=(0, 4))
        self.pk_nature_effect_var = tk.StringVar(value="")
        self.pk_nature_up_var = tk.StringVar(value="")
        self.pk_nature_sep_var = tk.StringVar(value="")
        self.pk_nature_down_var = tk.StringVar(value="")
        self.pk_nature_neutral_var = tk.StringVar(value="")
        nature_effect_frame = ttk.Frame(frame)
        nature_effect_frame.grid(row=row, column=1, columnspan=3, sticky="w", pady=(0, 4))
        ttk.Label(nature_effect_frame, textvariable=self.pk_nature_neutral_var, foreground="#606060").pack(side="left")
        ttk.Label(nature_effect_frame, textvariable=self.pk_nature_up_var, foreground="#c03535").pack(side="left")
        ttk.Label(nature_effect_frame, textvariable=self.pk_nature_sep_var).pack(side="left")
        ttk.Label(nature_effect_frame, textvariable=self.pk_nature_down_var, foreground="#2b5fc9").pack(side="left")
        row += 1

        ttk.Label(frame, text="Held Item").grid(row=row, column=0, sticky="w", padx=(0, 6), pady=4)
        self.pk_item_combo = ttk.Combobox(frame, textvariable=self.pk_item_var, width=28)
        self.pk_item_combo.grid(row=row, column=1, sticky="ew", padx=(0, 16), pady=4)
        self._set_combo_values(self.pk_item_combo, item_values)
        self._enable_combo_search(self.pk_item_combo)
        self._register_description_widget(self.pk_item_combo, "party", "item")
        self.pk_item_combo.bind("<<ComboboxSelected>>", lambda _e: self.update_party_description("item"), add="+")
        self.pk_item_combo.bind("<FocusOut>", lambda _e: self.update_party_description("item"), add="+")
        self.pk_item_combo.bind("<Enter>", lambda _e: self.update_party_description("item"), add="+")
        self.pk_item_combo.bind("<<ComboboxSelected>>", lambda _e: self.update_party_editor_preview(), add="+")
        self.pk_item_combo.bind("<FocusOut>", lambda _e: self.update_party_editor_preview(), add="+")
        ttk.Label(frame, text="Ability").grid(row=row, column=2, sticky="w", padx=(0, 6), pady=4)
        self.pk_ability_combo = ttk.Combobox(frame, textvariable=self.pk_ability_var, width=28)
        self.pk_ability_combo.grid(row=row, column=3, sticky="ew", padx=(0, 16), pady=4)
        self._enable_combo_search(self.pk_ability_combo)
        self._register_description_widget(self.pk_ability_combo, "party", "ability")
        self.pk_ability_combo.bind("<<ComboboxSelected>>", self.on_ability_changed, add="+")
        self.pk_ability_combo.bind("<FocusOut>", self.on_ability_changed, add="+")
        self.pk_ability_combo.bind("<Enter>", lambda _e: self.update_party_description("ability"), add="+")
        row += 1

        self._add_labeled_entry(frame, "Friendship", self.pk_happiness_var, row, 0)
        self._add_labeled_entry(frame, "Nickname", self.pk_name_var, row, 2)
        row += 1
        ttk.Button(frame, text="Load Species Defaults", command=self.load_species_defaults_into_editor).grid(
            row=row, column=0, columnspan=2, sticky="w", pady=(8, 0)
        )

    def _build_party_evolution_section(self, parent: ttk.Frame):
        evo_frame = ttk.LabelFrame(parent, text="Evolution Chart", padding=6)
        self.party_evo_frame = evo_frame
        evo_frame.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        evo_frame.columnconfigure(0, weight=1)
        evo_frame.rowconfigure(0, weight=1)
        self.party_evo_canvas = tk.Canvas(
            evo_frame,
            height=210,
            bg="#fbfbfb",
            highlightthickness=1,
            highlightbackground="#cccccc",
        )
        self.party_evo_canvas.grid(row=0, column=0, sticky="nsew")

    def _run_scheduled_party_evo_update(self):
        self._party_evo_update_scheduled = False
        self.update_party_evolution_chart()

    def _on_party_content_frame_configure(self, _event=None):
        if not hasattr(self, "party_content_canvas"):
            return
        try:
            self.party_content_canvas.configure(scrollregion=self.party_content_canvas.bbox("all"))
        except Exception:
            pass

    def _on_party_content_canvas_configure(self, event):
        if not hasattr(self, "party_content_canvas"):
            return
        try:
            self.party_content_canvas.itemconfigure(self._party_content_window, width=event.width)
        except Exception:
            pass
        if self._party_evo_update_scheduled:
            return
        self._party_evo_update_scheduled = True
        try:
            self.root.after_idle(self._run_scheduled_party_evo_update)
        except Exception:
            self._party_evo_update_scheduled = False

    def _bind_party_content_mousewheel_recursive(self, widget):
        if widget is None:
            return
        key = str(widget)
        if key not in self._party_wheel_bound_widgets:
            try:
                widget.bind("<MouseWheel>", self._on_party_content_mousewheel, add="+")
                widget.bind("<Button-4>", self._on_party_content_mousewheel, add="+")
                widget.bind("<Button-5>", self._on_party_content_mousewheel, add="+")
                self._party_wheel_bound_widgets.add(key)
            except Exception:
                pass
        try:
            children = widget.winfo_children()
        except Exception:
            children = []
        for child in children:
            self._bind_party_content_mousewheel_recursive(child)

    def _on_party_content_mousewheel(self, event):
        if not hasattr(self, "party_content_canvas"):
            return
        canvas = self.party_content_canvas
        target = getattr(event, "widget", None)

        if not self._is_widget_descendant(target, canvas):
            try:
                hovered = self.root.winfo_containing(self.root.winfo_pointerx(), self.root.winfo_pointery())
            except Exception:
                hovered = None
            if not self._is_widget_descendant(hovered, canvas):
                return
        return self._scroll_canvas_mousewheel(canvas, event)

    @staticmethod
    def _scroll_canvas_mousewheel(canvas: tk.Canvas, event):
        try:
            x0, y0, x1, y1 = [int(float(v)) for v in str(canvas.cget("scrollregion")).split()]
        except Exception:
            return
        if (y1 - y0) <= canvas.winfo_height():
            return
        if getattr(event, "delta", 0):
            steps = int(-event.delta / 120)
            if steps == 0:
                steps = -1 if event.delta > 0 else 1
        else:
            num = int(getattr(event, "num", 0))
            steps = -1 if num == 4 else 1
        canvas.yview_scroll(steps, "units")
        return "break"

    @staticmethod
    def _estimate_party_evolution_height(
        root_branch_count: int,
        viewport_height: int,
    ) -> int:
        if root_branch_count <= 4:
            return viewport_height
        cluster_count = (root_branch_count + 3) // 4
        cols = min(3, max(1, cluster_count))
        rows = (cluster_count + cols - 1) // cols
        # Reserve enough per cluster row so lower rows stay visible with scrolling.
        needed = 44 + (rows * 268)
        return max(viewport_height, needed)

    @staticmethod
    def _split_chart_columns_for_width(cluster_count: int, width: int, node_half: int) -> int:
        if cluster_count <= 0:
            return 1
        side_pad = max(8, node_half + 10)
        usable_w = max(120, int(width) - (2 * side_pad))
        # Keep cluster cell wide enough; when viewport is narrow, wrap clusters to next row.
        min_cell_width = 340
        cols_by_width = max(1, usable_w // min_cell_width)
        return max(1, min(3, cluster_count, cols_by_width))

    def _build_party_side_preview(self, parent: ttk.Frame):
        preview = ttk.LabelFrame(parent, text="Preview", padding=8)
        preview.grid(row=0, column=0, sticky="ew")
        preview.columnconfigure(1, weight=1)

        left = ttk.Frame(preview)
        left.grid(row=0, column=0, sticky="nw")
        right = ttk.Frame(preview)
        right.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        right.columnconfigure(0, weight=1)

        self.party_preview_sprite_label = tk.Label(
            left,
            text="(No Pokemon)",
            bg="#f6f6f6",
            relief="solid",
            bd=1,
            anchor="center",
            justify="center",
        )
        self.party_preview_sprite_placeholder = tk.PhotoImage(width=96, height=96)
        self.party_preview_sprite_label.configure(image=self.party_preview_sprite_placeholder, compound="center")
        self.party_preview_sprite_label.image = self.party_preview_sprite_placeholder
        self.party_preview_sprite_label.pack(anchor="nw")

        item_row = ttk.Frame(left)
        item_row.pack(anchor="w", pady=(6, 0))
        self.party_preview_item_icon_label = tk.Label(
            item_row, bg="#f6f6f6", relief="solid", bd=1, padx=2, pady=2
        )
        self.party_preview_item_placeholder = tk.PhotoImage(width=32, height=32)
        self.party_preview_item_icon_label.configure(image=self.party_preview_item_placeholder)
        self.party_preview_item_icon_label.image = self.party_preview_item_placeholder
        self.party_preview_item_icon_label.pack(side="left")
        self.party_preview_item_name_var = tk.StringVar(value="(No item)")
        ttk.Label(item_row, textvariable=self.party_preview_item_name_var).pack(side="left", padx=(6, 0))

        self.party_preview_species_var = tk.StringVar(value="-")
        ttk.Label(right, textvariable=self.party_preview_species_var, font=("", 10, "bold")).grid(
            row=0, column=0, sticky="w"
        )
        self.party_preview_lv_gender_var = tk.StringVar(value="Lv 1 | Gender: -")
        ttk.Label(right, textvariable=self.party_preview_lv_gender_var).grid(row=1, column=0, sticky="w", pady=(2, 0))
        type_row = ttk.Frame(right)
        type_row.grid(row=2, column=0, sticky="w", pady=(2, 0))
        ttk.Label(type_row, text="Type:").pack(side="left")
        self.party_preview_type_chip_host = ttk.Frame(type_row)
        self.party_preview_type_chip_host.pack(side="left", padx=(6, 0))
        self._render_type_chip_row(self.party_preview_type_chip_host, [], short=False, empty_text="-")

        self.party_preview_hp_bar_width = 180
        self.party_preview_hp_bar_height = 12
        self.party_preview_hp_canvas = tk.Canvas(
            right,
            width=self.party_preview_hp_bar_width,
            height=self.party_preview_hp_bar_height,
            highlightthickness=1,
            highlightbackground="#7a7a7a",
            bg="#2d2d2d",
        )
        self.party_preview_hp_canvas.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        self.party_preview_hp_fill_rect = self.party_preview_hp_canvas.create_rectangle(
            1, 1, 1, self.party_preview_hp_bar_height - 1, fill="#59c441", outline=""
        )
        self.party_preview_hp_text_var = tk.StringVar(value="HP: 0/0")
        ttk.Label(right, textvariable=self.party_preview_hp_text_var).grid(row=4, column=0, sticky="w", pady=(3, 0))
        self.party_preview_hp_canvas.bind("<Configure>", lambda _e: self.update_party_editor_preview(), add="+")

    def _build_party_met_section(self, frame: ttk.Frame):
        for col in (1, 3):
            frame.columnconfigure(col, weight=1)
        row = 0
        self._add_labeled_entry(frame, "Obtain Level", self.pk_obtain_level_var, row, 0)
        self._add_labeled_entry(frame, "Obtain Method", self.pk_obtain_method_var, row, 2)
        row += 1
        self._add_labeled_entry(frame, "Obtain Map", self.pk_obtain_map_var, row, 0)
        self._add_labeled_entry(frame, "Hatched Map", self.pk_hatched_map_var, row, 2)
        row += 1
        self._add_labeled_entry(frame, "Obtain Text", self.pk_obtain_text_var, row, 0, width=56)

    def _build_party_stats_section(self, frame: ttk.Frame):
        for c in range(5):
            frame.columnconfigure(c, weight=0)
        frame.columnconfigure(1, weight=1)
        frame.columnconfigure(4, weight=1)

        ttk.Label(frame, text=" ").grid(row=0, column=0, padx=(0, 4), pady=(0, 4))
        ttk.Label(frame, text="Base").grid(row=0, column=1, padx=4, pady=(0, 4))
        ttk.Label(frame, text="IVs").grid(row=0, column=2, padx=4, pady=(0, 4))
        ttk.Label(frame, text="EVs").grid(row=0, column=3, padx=4, pady=(0, 4))
        ttk.Label(frame, text="Stats").grid(row=0, column=4, padx=4, pady=(0, 4))

        self.party_stat_name_labels: dict[str, tk.Label] = {}
        self.party_base_stat_vars: dict[str, tk.StringVar] = {}
        self.party_iv_vars: dict[str, tk.StringVar] = {}
        self.party_ev_vars: dict[str, tk.StringVar] = {}
        self.party_final_stat_vars: dict[str, tk.StringVar] = {}

        for row, (stat_id, stat_label) in enumerate(STAT_ORDER, start=1):
            name_lbl = tk.Label(frame, text=f"{stat_label}:", width=6, anchor="e")
            name_lbl.grid(row=row, column=0, sticky="e", padx=(0, 4), pady=2)
            self.party_stat_name_labels[stat_id] = name_lbl

            base_var = tk.StringVar(value="0")
            self.party_base_stat_vars[stat_id] = base_var
            ttk.Label(frame, textvariable=base_var, width=6, anchor="center").grid(
                row=row, column=1, padx=4, pady=2
            )

            iv_var = tk.StringVar(value="0")
            self.party_iv_vars[stat_id] = iv_var
            iv_entry = ttk.Entry(frame, textvariable=iv_var, width=6)
            iv_entry.grid(row=row, column=2, padx=4, pady=2)
            iv_entry.bind("<FocusOut>", lambda _e, sid=stat_id: self.on_iv_ev_focus_out("iv", sid))

            ev_var = tk.StringVar(value="0")
            self.party_ev_vars[stat_id] = ev_var
            ev_entry = ttk.Entry(frame, textvariable=ev_var, width=6)
            ev_entry.grid(row=row, column=3, padx=4, pady=2)
            ev_entry.bind("<FocusOut>", lambda _e, sid=stat_id: self.on_iv_ev_focus_out("ev", sid))

            final_var = tk.StringVar(value="0")
            self.party_final_stat_vars[stat_id] = final_var
            ttk.Label(frame, textvariable=final_var, width=8, anchor="center").grid(
                row=row, column=4, padx=4, pady=2
            )

        self.party_hidden_power_var = tk.StringVar(value="Unknown")
        ttk.Label(frame, text="Hidden Power Type:").grid(row=8, column=0, columnspan=2, sticky="w", pady=(8, 2))
        self.party_hidden_power_chip_host = ttk.Frame(frame)
        self.party_hidden_power_chip_host.grid(row=8, column=2, sticky="w", pady=(8, 2))
        self._render_type_chip_row(self.party_hidden_power_chip_host, [], short=False, empty_text="Unknown")
        ttk.Button(frame, text="Max EVs", command=self.set_all_evs_max).grid(
            row=8, column=3, columnspan=2, sticky="w", padx=(8, 0), pady=(8, 2)
        )

        ttk.Label(
            frame,
            text="IV limit: 0-31 each, total capped at 186. EV limit: 0-252 each (no total cap).",
        ).grid(row=9, column=0, columnspan=5, sticky="w", pady=(6, 0))

    def _build_party_moves_section(self, frame: ttk.Frame):
        current = ttk.LabelFrame(frame, text="Current Moves", padding=8)
        current.pack(fill="x")
        current.columnconfigure(1, weight=1)
        self.move_id_vars = []
        self.move_pp_vars = []
        self.move_ppup_vars = []
        self.move_id_combos: list[ttk.Combobox] = []
        self.move_pp_entries: list[ttk.Entry] = []
        self.move_ppup_entries: list[ttk.Entry] = []
        for i in range(4):
            move_var = tk.StringVar()
            pp_var = tk.StringVar()
            ppup_var = tk.StringVar()
            self.move_id_vars.append(move_var)
            self.move_pp_vars.append(pp_var)
            self.move_ppup_vars.append(ppup_var)
            ttk.Label(current, text=f"Move {i + 1}").grid(row=i, column=0, sticky="w", padx=(0, 6), pady=2)
            move_combo = ttk.Combobox(current, textvariable=move_var, width=26)
            move_combo.grid(row=i, column=1, sticky="ew", padx=(0, 6), pady=2)
            self._enable_combo_search(move_combo)
            self._register_description_widget(move_combo, "party", "move", i)
            move_combo.bind("<<ComboboxSelected>>", lambda _e, idx=i: self.on_move_combo_changed(idx), add="+")
            move_combo.bind("<FocusOut>", lambda _e, idx=i: self.on_move_combo_changed(idx, force_pp=False), add="+")
            move_combo.bind("<Enter>", lambda _e, idx=i: self.update_party_description("move", idx), add="+")
            self.move_id_combos.append(move_combo)
            ttk.Label(current, text="PP").grid(row=i, column=2, sticky="w", padx=(6, 2))
            pp_entry = ttk.Entry(current, textvariable=pp_var, width=6)
            pp_entry.grid(row=i, column=3, sticky="w", padx=2, pady=2)
            pp_entry.bind("<FocusOut>", lambda _e, idx=i: self.on_move_pp_focus_out(idx), add="+")
            self.move_pp_entries.append(pp_entry)
            ttk.Label(current, text="PPUp").grid(row=i, column=4, sticky="w", padx=(6, 2))
            ppup_entry = ttk.Entry(current, textvariable=ppup_var, width=6)
            ppup_entry.grid(row=i, column=5, sticky="w", padx=2, pady=2)
            ppup_entry.bind("<FocusOut>", lambda _e, idx=i: self.on_move_ppup_changed(idx), add="+")
            self.move_ppup_entries.append(ppup_entry)

        relearn = ttk.LabelFrame(frame, text="Relearn Moves", padding=8)
        relearn.pack(fill="x", pady=(10, 0))
        relearn.columnconfigure(1, weight=1)
        self.relearn_move_vars: list[tk.StringVar] = []
        self.relearn_move_combos: list[ttk.Combobox] = []
        for i in range(4):
            rv = tk.StringVar(value="(None)")
            self.relearn_move_vars.append(rv)
            ttk.Label(relearn, text=f"Relearn {i + 1}").grid(row=i, column=0, sticky="w", padx=(0, 6), pady=2)
            combo = ttk.Combobox(relearn, textvariable=rv, width=30)
            combo.grid(row=i, column=1, sticky="ew", pady=2)
            self._set_combo_values(combo, ["(None)"])
            self._enable_combo_search(combo)
            self._register_description_widget(combo, "party", "relearn", i)
            combo.bind("<<ComboboxSelected>>", lambda _e, idx=i: self.update_party_description("relearn", idx), add="+")
            combo.bind("<FocusOut>", lambda _e, idx=i: self.update_party_description("relearn", idx), add="+")
            combo.bind("<Enter>", lambda _e, idx=i: self.update_party_description("relearn", idx), add="+")
            self.relearn_move_combos.append(combo)

    def _build_party_cosmetic_section(self, frame: ttk.Frame):
        ttk.Checkbutton(frame, text="Super Shiny", variable=self.pk_super_shiny_var).grid(
            row=0, column=0, sticky="w", pady=4
        )

    def _build_party_ot_misc_section(self, frame: ttk.Frame):
        for col in (1, 3):
            frame.columnconfigure(col, weight=1)
        row = 0
        ability_index_entry = self._add_labeled_entry(frame, "Ability Index", self.pk_ability_index_var, row, 0)
        ability_index_entry.bind("<FocusOut>", self.on_ability_index_focus_out, add="+")
        self._add_labeled_entry(frame, "Personal ID", self.pk_personal_id_var, row, 2)
        row += 1
        forced_form_entry = self._add_labeled_entry(frame, "Forced Form", self.pk_forced_form_var, row, 0)
        forced_form_entry.bind("<FocusOut>", self.on_forced_form_focus_out, add="+")
        self._add_labeled_entry(frame, "Legacy Data", self.pk_legacy_var, row, 2)

    def _on_party_editor_section_changed(self):
        selected = self.party_editor_section_var.get()
        for section, frame in self.party_editor_sections.items():
            if section == selected:
                frame.tkraise()

    def _on_party_mode_changed(self):
        is_box = self.party_view_mode_var.get() == "Box"
        if is_box:
            self.party_box_combo.state(["!disabled"])
            self.party_prev_box_btn.state(["!disabled"])
            self.party_next_box_btn.state(["!disabled"])
        else:
            self.party_box_combo.state(["disabled"])
            self.party_prev_box_btn.state(["disabled"])
            self.party_next_box_btn.state(["disabled"])
        self._party_selected_mode = None
        self._party_selected_index = None
        self._party_selected_box_index = None
        self.party_slot_status_var.set("Select a target slot.")
        self._render_party_slot_grid()

    def _get_storage_boxes(self) -> list:
        storage = self.get_root_key("storage_system")
        if not isinstance(storage, core.RubyObject):
            return []
        boxes = core.read_attr(storage, "@boxes", [])
        if not isinstance(boxes, list):
            return []
        return boxes

    def _get_box_pokemon_list(self, box_obj: Any) -> list:
        if not isinstance(box_obj, core.RubyObject):
            return []
        data = core.read_attr(box_obj, "@pokemon", [])
        if not isinstance(data, list):
            return []
        return data

    def _box_display_name(self, box_obj: Any, index: int) -> str:
        base = f"Box {index + 1}"
        if not isinstance(box_obj, core.RubyObject):
            return base
        raw = symbol_name(core.read_attr(box_obj, "@name", "")).strip()
        return f"{base} - {raw}" if raw else base

    def _selected_box_index(self) -> int:
        raw = self.party_box_var.get().strip()
        return self.party_box_option_to_index.get(raw, 0)

    def _refresh_party_box_controls(self):
        self.party_box_option_to_index = {}
        if self.save_data is None:
            self.party_box_combo["values"] = []
            self.party_box_var.set("")
            return
        boxes = self._get_storage_boxes()
        values: list[str] = []
        for i, box in enumerate(boxes):
            label = self._box_display_name(box, i)
            values.append(label)
            self.party_box_option_to_index[label] = i
        self.party_box_combo["values"] = values
        if not values:
            self.party_box_var.set("")
            return
        storage = self.get_root_key("storage_system")
        current = core.read_attr(storage, "@currentBox", 0) if isinstance(storage, core.RubyObject) else 0
        try:
            current_index = int(current)
        except (TypeError, ValueError):
            current_index = 0
        if current_index < 0 or current_index >= len(values):
            current_index = 0
        self.party_box_var.set(values[current_index])

    def on_party_box_selected(self, _event=None):
        storage = self.get_root_key("storage_system")
        if isinstance(storage, core.RubyObject):
            storage.attributes["@currentBox"] = self._selected_box_index()
        self._party_selected_mode = None
        self._party_selected_index = None
        self._party_selected_box_index = None
        self.party_slot_status_var.set("Select a target slot.")
        self._render_party_slot_grid()

    def party_prev_box(self):
        values = list(self.party_box_combo["values"])
        if not values:
            return
        idx = self._selected_box_index() - 1
        if idx < 0:
            idx = len(values) - 1
        self.party_box_var.set(values[idx])
        self.on_party_box_selected()

    def party_next_box(self):
        values = list(self.party_box_combo["values"])
        if not values:
            return
        idx = self._selected_box_index() + 1
        if idx >= len(values):
            idx = 0
        self.party_box_var.set(values[idx])
        self.on_party_box_selected()

    def _party_slot_cells(self) -> tuple[list[Any], int, int, str, int | None]:
        if self.save_data is None:
            return [], 2, 3, "party", None
        if self.party_view_mode_var.get() == "Box":
            boxes = self._get_storage_boxes()
            box_idx = self._selected_box_index()
            if box_idx < 0 or box_idx >= len(boxes):
                return [], 5, 6, "box", None
            return self._get_box_pokemon_list(boxes[box_idx]), 5, 6, "box", box_idx
        player = self.get_root_key("player")
        party = core.read_attr(player, "@party", []) if isinstance(player, core.RubyObject) else []
        if not isinstance(party, list):
            party = []
        return party, 2, 3, "party", None

    def _slot_display_label(self, entry: Any, idx: int) -> str:
        if isinstance(entry, core.RubyObject):
            species_id = symbol_name(core.read_attr(entry, "@species", ""))
            species = self.catalogs.canonical_species_id(species_id) if self.catalogs else species_id
            species = species or species_id
            level = core.read_attr(entry, "@level", "?")
            return f"#{idx + 1}\n{species}\nLv {level}"
        return f"#{idx + 1}\n(empty)"

    def _pokemon_icon_candidates_from_fields(self, species_id: str, form: int = 0) -> list[str]:
        species_raw = str(species_id or "").strip().lstrip(":")
        if not species_raw:
            return []
        species = self.catalogs.canonical_species_id(species_raw) if self.catalogs else species_raw
        species = species or species_raw
        try:
            form_int = int(form)
        except (TypeError, ValueError):
            form_int = 0
        out: list[str] = []
        if form_int > 0:
            out.append(f"{species}_{form_int}")
        out.append(species)
        return out

    def _pokemon_icon_candidates(self, pkmn: core.RubyObject) -> list[str]:
        species_raw = symbol_name(core.read_attr(pkmn, "@species", "")).strip()
        form = core.read_attr(pkmn, "@form", 0)
        return self._pokemon_icon_candidates_from_fields(species_raw, form=form)

    def _get_party_icon_image_for_fields(self, species_id: str, form: int, shiny: bool) -> tk.PhotoImage | None:
        subdir = "Icons shiny" if shiny else "Icons"
        root_dir = HERE.parent / "Graphics" / "Pokemon" / subdir
        for stem in self._pokemon_icon_candidates_from_fields(species_id, form=form):
            cache_key = f"{subdir}:{stem}"
            if cache_key in self._party_icon_cache:
                return self._party_icon_cache[cache_key]
            path = root_dir / f"{stem}.png"
            if not path.exists():
                continue
            try:
                img = tk.PhotoImage(file=str(path))
                img = self._normalize_icon_frame(img)
            except Exception:
                continue
            self._party_icon_cache[cache_key] = img
            return img
        return None

    def _get_party_icon_image(self, pkmn: Any) -> tk.PhotoImage | None:
        if not isinstance(pkmn, core.RubyObject):
            return None
        shiny = bool(core.read_attr(pkmn, "@shiny", False))
        species_raw = symbol_name(core.read_attr(pkmn, "@species", "")).strip()
        form = core.read_attr(pkmn, "@form", 0)
        scale = max(1, int(getattr(self, "_party_grid_icon_scale", 1)))
        cache_key = f"grid:{species_raw}:{form}:{int(shiny)}:{scale}"
        cached = self._party_grid_icon_cache.get(cache_key)
        if cached is not None:
            return cached
        base = self._get_party_icon_image_for_fields(species_raw, form=form, shiny=shiny)
        if base is None:
            return None
        if scale <= 1:
            scaled = base
        else:
            try:
                scaled = base.subsample(scale, scale)
            except Exception:
                scaled = base
        self._party_grid_icon_cache[cache_key] = scaled
        return scaled

    def _get_party_preview_icon_image(self, species_id: str, form: int, shiny: bool) -> tk.PhotoImage | None:
        key = f"preview:{species_id}:{form}:{int(shiny)}"
        if key in self._party_preview_icon_cache:
            return self._party_preview_icon_cache[key]
        base = self._get_party_icon_image_for_fields(species_id, form=form, shiny=shiny)
        if base is None:
            return None
        try:
            if base.width() <= 48:
                scaled = base.zoom(2, 2)
            elif base.width() > 96:
                scaled = base.subsample(2, 2)
            else:
                scaled = base
        except Exception:
            scaled = base
        self._party_preview_icon_cache[key] = scaled
        return scaled

    def _get_item_icon_image(self, item_id: str) -> tk.PhotoImage | None:
        raw = str(item_id or "").strip().lstrip(":")
        if not raw:
            return None
        canonical = self.catalogs.canonical_item_id(raw) if self.catalogs else raw
        item_key = canonical or raw
        cache_key = f"item:{item_key}"
        if cache_key in self._party_item_icon_cache:
            return self._party_item_icon_cache[cache_key]
        root = HERE.parent / "Graphics" / "Items"
        candidates = [
            root / f"{item_key}.png",
            root / "Key items" / f"{item_key}_key.png",
            root / "000.png",
        ]
        for path in candidates:
            if not path.exists():
                continue
            try:
                img = tk.PhotoImage(file=str(path))
            except Exception:
                continue
            self._party_item_icon_cache[cache_key] = img
            return img
        return None

    @staticmethod
    def _gender_label_from_value(value: int) -> str:
        if value == 0:
            return "Male"
        if value == 1:
            return "Female"
        if value == 2:
            return "Genderless"
        return "Unknown"

    def update_party_editor_preview(self):
        if not hasattr(self, "party_preview_sprite_label"):
            return
        species_raw = self.pk_species_var.get().strip()
        species_id = ""
        if species_raw:
            try:
                species_id = self.resolve_species_id(species_raw)
            except Exception:
                species_id = extract_internal_id(species_raw).strip().lstrip(":")
        form = self._clamp_int(self.pk_form_var.get(), 0, 999, 0)
        shiny = bool(self.pk_shiny_var.get())

        preview_img = self._get_party_preview_icon_image(species_id, form=form, shiny=shiny) if species_id else None
        if preview_img is None:
            preview_img = self.party_preview_sprite_placeholder
        self.party_preview_sprite_label.configure(
            image=preview_img,
            text="" if species_id else "(No Pokemon)",
        )
        self.party_preview_sprite_label.image = preview_img

        item_id = ""
        item_label = "(No item)"
        if self.pk_item_var.get().strip():
            try:
                item_id = self.resolve_item_id(self.pk_item_var.get())
                item_label = item_id
            except Exception:
                item_id = ""
                item_label = self.pk_item_var.get().strip()
        item_img = self._get_item_icon_image(item_id) if item_id else None
        if item_img is None:
            item_img = self.party_preview_item_placeholder
        self.party_preview_item_icon_label.configure(image=item_img)
        self.party_preview_item_icon_label.image = item_img
        self.party_preview_item_name_var.set(item_label)

        species_label = species_id or "(No species)"
        level = self._clamp_int(self.pk_level_var.get(), 1, 100, 1)
        gender = self._clamp_int(self.pk_gender_var.get(), 0, 2, 0)
        self.party_preview_species_var.set(species_label)
        self.party_preview_lv_gender_var.set(f"Lv {level} | Gender: {self._gender_label_from_value(gender)}")
        type_ids: list[str] = []
        if species_id and self.catalogs:
            type_ids = self._dex_species_type_ids(species_id, form=form)
        if hasattr(self, "party_preview_type_chip_host"):
            self._render_type_chip_row(
                self.party_preview_type_chip_host,
                type_ids,
                short=False,
                empty_text="-",
            )

        total_hp = self._clamp_int(self.pk_totalhp_var.get(), 0, 9999, 0)
        cur_hp = self._clamp_int(self.pk_hp_var.get(), 0, 9999, total_hp)
        if total_hp <= 0:
            total_hp = max(cur_hp, 1)
        cur_hp = max(0, min(cur_hp, total_hp))
        ratio = cur_hp / total_hp if total_hp > 0 else 0.0
        actual_bar_w = self.party_preview_hp_canvas.winfo_width()
        if actual_bar_w <= 2:
            actual_bar_w = self.party_preview_hp_bar_width
        self.party_preview_hp_bar_width = max(120, actual_bar_w)
        fill_w = int((self.party_preview_hp_bar_width - 2) * ratio)
        if cur_hp > 0:
            fill_w = max(1, fill_w)
        fill_w = max(0, min(self.party_preview_hp_bar_width - 2, fill_w))
        if ratio > 0.5:
            bar_color = "#59c441"
        elif ratio > 0.2:
            bar_color = "#d4b146"
        else:
            bar_color = "#cf4a4a"
        self.party_preview_hp_canvas.coords(
            self.party_preview_hp_fill_rect,
            1,
            1,
            1 + fill_w,
            self.party_preview_hp_bar_height - 1,
        )
        self.party_preview_hp_canvas.itemconfig(self.party_preview_hp_fill_rect, fill=bar_color)
        self.party_preview_hp_text_var.set(f"HP: {cur_hp}/{total_hp}")

    @staticmethod
    def _normalize_icon_frame(img: tk.PhotoImage) -> tk.PhotoImage:
        width, height = img.width(), img.height()
        if width <= height:
            return img
        frame_w = height
        try:
            return img.copy(from_coords=(0, 0, frame_w, height))
        except Exception:
            cropped = tk.PhotoImage(width=frame_w, height=height)
            try:
                cropped.tk.call(str(cropped), "copy", str(img), "-from", 0, 0, frame_w, height, "-to", 0, 0)
                return cropped
            except Exception:
                return img

    def _render_party_slot_grid(self):
        for widget in self.party_grid_frame.winfo_children():
            widget.destroy()

        entries, rows, cols, mode, box_idx = self._party_slot_cells()
        total = rows * cols
        wrap_len = 64 if cols <= 3 else 52
        for r in range(rows):
            self.party_grid_frame.rowconfigure(r, weight=1)
        for c in range(cols):
            self.party_grid_frame.columnconfigure(c, weight=1)

        for i in range(total):
            entry = entries[i] if i < len(entries) else None
            label = self._slot_display_label(entry, i)
            selected = (
                self._party_selected_mode == mode
                and self._party_selected_index == i
                and (mode != "box" or self._party_selected_box_index == box_idx)
            )
            btn = tk.Button(
                self.party_grid_frame,
                text=label,
                image=self._get_party_icon_image(entry),
                compound="top",
                justify="center",
                wraplength=wrap_len,
                font=("", 8),
                relief="solid",
                bd=1,
                padx=2,
                pady=2,
                bg="#ffe7a8" if selected else "#dff3dc",
                activebackground="#f6d584" if selected else "#cde9c8",
                command=lambda idx=i: self.select_party_slot(idx),
            )
            btn.grid(row=i // cols, column=i % cols, sticky="nsew", padx=1, pady=1)

    def _build_bag_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="Bag")
        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(1, weight=1)

        top = ttk.Frame(tab)
        top.pack(fill="x")

        ttk.Label(top, text="Pocket").pack(side="left")
        self.bag_pocket_var = tk.StringVar()
        self.bag_pocket_option_to_index: dict[str, int] = {}
        pocket_values: list[str] = []
        # Always show English pocket labels in UI.
        for i in range(1, 9):
            label = f"{i} - {EN_POCKET_NAMES.get(i, f'Pocket {i}')}"
            self.bag_pocket_option_to_index[label] = i
            pocket_values.append(label)
        label0 = f"0 - {EN_POCKET_NAMES.get(0, 'Unused')}"
        self.bag_pocket_option_to_index[label0] = 0
        pocket_values.append(label0)
        self.bag_pocket_var.set(pocket_values[0])
        self.bag_pocket_combo = ttk.Combobox(
            top, textvariable=self.bag_pocket_var, state="readonly", width=20, values=pocket_values
        )
        self.bag_pocket_combo.pack(side="left", padx=(6, 6))
        self.bag_pocket_combo.bind("<<ComboboxSelected>>", self.on_bag_pocket_selected)
        ttk.Button(top, text="Refresh Pocket", command=self.refresh_bag_list).pack(side="left")

        body = ttk.Panedwindow(tab, orient="horizontal")
        body.pack(fill="both", expand=True, pady=(8, 0))

        left = ttk.Frame(body)
        right = ttk.Frame(body, padding=(8, 0, 0, 0))
        body.add(left, weight=2)
        body.add(right, weight=3)
        right.columnconfigure(1, weight=1)
        right.rowconfigure(3, weight=1)

        self.bag_list = tk.Listbox(left, exportselection=False)
        self.bag_list.pack(fill="both", expand=True)
        self.bag_list.bind("<<ListboxSelect>>", self.on_bag_item_select)

        self.bag_item_var = tk.StringVar()
        self.bag_qty_var = tk.StringVar()
        self._bag_item_label_to_id: dict[str, str] = {}
        self._bag_item_id_to_label: dict[str, str] = {}
        item_values: list[str] = []
        ttk.Label(right, text="Item").grid(row=0, column=0, sticky="w", padx=(0, 6), pady=4)
        self.bag_item_combo = ttk.Combobox(right, textvariable=self.bag_item_var, width=38)
        self.bag_item_combo.grid(row=0, column=1, sticky="ew", padx=(0, 16), pady=4)
        self._set_combo_values(self.bag_item_combo, item_values)
        self._enable_combo_search(self.bag_item_combo)
        self._register_description_widget(self.bag_item_combo, "bag", "item")
        self.bag_item_combo.bind("<<ComboboxSelected>>", lambda _e: self.update_bag_description(), add="+")
        self.bag_item_combo.bind("<FocusOut>", lambda _e: self.update_bag_description(), add="+")
        self.bag_item_combo.bind("<Enter>", lambda _e: self.update_bag_description(), add="+")
        self._add_labeled_entry(right, "Quantity", self.bag_qty_var, 1, 0)

        btns = ttk.Frame(right)
        btns.grid(row=2, column=0, columnspan=4, sticky="w", pady=(10, 0))
        ttk.Button(btns, text="Add New", command=self.bag_add_item).pack(side="left", padx=(0, 4))
        ttk.Button(btns, text="Update Selected", command=self.bag_update_item).pack(side="left", padx=4)
        ttk.Button(btns, text="Remove Selected", command=self.bag_remove_item).pack(side="left", padx=4)
        bag_desc_frame = ttk.LabelFrame(right, text="Description", padding=6)
        bag_desc_frame.grid(row=3, column=0, columnspan=4, sticky="nsew", pady=(12, 0))
        self.bag_desc_text = tk.Text(bag_desc_frame, height=8, wrap="word")
        self.bag_desc_text.pack(fill="both", expand=True)
        self.bag_desc_text.configure(state="disabled")
        self.update_bag_item_dropdown()
        self.update_bag_description()

    def _build_flags_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="Switches/Vars")
        tab.columnconfigure(0, weight=1)

        sw_frame = ttk.LabelFrame(tab, text="Switch", padding=8)
        sw_frame.pack(fill="x")
        sw_frame.columnconfigure(1, weight=1)
        self.switch_index_var = tk.StringVar(value="1")
        self.switch_value_var = tk.BooleanVar(value=False)
        self._add_labeled_entry(sw_frame, "Index", self.switch_index_var, 0, 0, width=8)
        ttk.Checkbutton(sw_frame, text="Value", variable=self.switch_value_var).grid(row=0, column=2, sticky="w", padx=10)
        ttk.Button(sw_frame, text="Load", command=self.load_switch).grid(row=0, column=3, padx=4)
        ttk.Button(sw_frame, text="Apply", command=self.apply_switch).grid(row=0, column=4, padx=4)

        var_frame = ttk.LabelFrame(tab, text="Variable", padding=8)
        var_frame.pack(fill="x", pady=(10, 0))
        var_frame.columnconfigure(1, weight=1)
        self.var_index_var = tk.StringVar(value="1")
        self.var_value_var = tk.StringVar()
        self.var_type_label_var = tk.StringVar(value="Type: ?")
        self._add_labeled_entry(var_frame, "Index", self.var_index_var, 0, 0, width=8)
        self._add_labeled_entry(var_frame, "Value", self.var_value_var, 1, 0, width=50)
        ttk.Label(var_frame, textvariable=self.var_type_label_var).grid(row=1, column=2, sticky="w", padx=8)
        btns = ttk.Frame(var_frame)
        btns.grid(row=2, column=0, columnspan=4, sticky="w", pady=(6, 0))
        ttk.Button(btns, text="Load", command=self.load_variable).pack(side="left", padx=(0, 4))
        ttk.Button(btns, text="Apply", command=self.apply_variable).pack(side="left", padx=4)

    def _build_advanced_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="Advanced")

        row1 = ttk.Frame(tab)
        row1.pack(fill="x")
        ttk.Label(row1, text="Path").pack(side="left")
        self.adv_path_var = tk.StringVar(value="player.@money")
        ttk.Entry(row1, textvariable=self.adv_path_var).pack(side="left", fill="x", expand=True, padx=(6, 6))
        ttk.Button(row1, text="Get", command=self.adv_get).pack(side="left")

        row2 = ttk.Frame(tab)
        row2.pack(fill="x", pady=(8, 0))
        ttk.Label(row2, text="Value").pack(side="left")
        self.adv_value_var = tk.StringVar()
        ttk.Entry(row2, textvariable=self.adv_value_var).pack(side="left", fill="x", expand=True, padx=(6, 6))
        ttk.Label(row2, text="Type").pack(side="left")
        self.adv_type_var = tk.StringVar(value="auto")
        ttk.Combobox(
            row2,
            textvariable=self.adv_type_var,
            state="readonly",
            width=10,
            values=["auto", "int", "float", "str", "bool", "nil", "symbol", "json"],
        ).pack(side="left", padx=(6, 6))
        ttk.Button(row2, text="Set", command=self.adv_set).pack(side="left")

        row3 = ttk.Frame(tab)
        row3.pack(fill="x", pady=(8, 0))
        ttk.Button(row3, text="List Children", command=self.adv_list_children).pack(side="left")

        self.adv_output = tk.Text(tab, height=24, wrap="none")
        self.adv_output.pack(fill="both", expand=True, pady=(8, 0))

    def _build_legality_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="Legality")
        top = ttk.Frame(tab)
        top.pack(fill="x")
        ttk.Button(top, text="Run Legality Check", command=self.run_legality_check).pack(side="left")
        ttk.Label(
            top,
            text="Checks: unknown item/species/move/ability IDs + basic level/PP ranges",
        ).pack(side="left", padx=10)
        self.legal_output = tk.Text(tab, wrap="none", height=28)
        self.legal_output.pack(fill="both", expand=True, pady=(8, 0))

    def _build_dex_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.dex_tab = tab
        self.nb.add(tab, text="Dex")
        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(1, weight=1)

        self.dex_category_var = tk.StringVar(value=DEX_CATEGORY_KEY_TO_LABEL.get("Species", "Pokédex"))
        self.dex_search_var = tk.StringVar()
        self.dex_form_var = tk.StringVar(value="0")
        self.dex_result_count_var = tk.StringVar(value="0 results")
        self.dex_title_var = tk.StringVar(value="Dex")
        self.dex_subtitle_var = tk.StringVar(value="Select a category and entry.")
        self._dex_pairs: list[tuple[str, str]] = []
        self._dex_visible_pairs: list[tuple[str, str]] = []

        controls = ttk.Frame(tab)
        controls.grid(row=0, column=0, sticky="ew")
        controls.columnconfigure(3, weight=1)

        ttk.Label(controls, text="Category").grid(row=0, column=0, sticky="w", padx=(0, 6))
        self.dex_category_combo = ttk.Combobox(
            controls,
            textvariable=self.dex_category_var,
            width=16,
            state="readonly",
            values=DEX_CATEGORY_LABELS,
        )
        self.dex_category_combo.grid(row=0, column=1, sticky="w", padx=(0, 12))
        self.dex_category_combo.bind("<<ComboboxSelected>>", self._on_dex_category_changed)

        ttk.Label(controls, text="Search").grid(row=0, column=2, sticky="w", padx=(0, 6))
        self.dex_search_entry = ttk.Entry(controls, textvariable=self.dex_search_var)
        self.dex_search_entry.grid(row=0, column=3, sticky="ew", padx=(0, 12))
        self.dex_search_entry.bind("<KeyRelease>", self._on_dex_search_changed, add="+")
        self.dex_search_entry.bind("<FocusOut>", self._on_dex_search_changed, add="+")

        ttk.Label(controls, text="Form").grid(row=0, column=4, sticky="w", padx=(0, 4))
        self.dex_form_entry = ttk.Entry(controls, textvariable=self.dex_form_var, width=5)
        self.dex_form_entry.grid(row=0, column=5, sticky="w", padx=(0, 8))
        self.dex_form_entry.bind("<FocusOut>", self._on_dex_form_changed, add="+")
        self.dex_form_entry.bind("<Return>", self._on_dex_form_changed, add="+")
        ttk.Label(controls, textvariable=self.dex_result_count_var).grid(row=0, column=6, sticky="e")

        shell = ttk.Panedwindow(tab, orient="horizontal")
        shell.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        self.dex_shell = shell

        left = ttk.Frame(shell, width=320)
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)
        self.dex_filter_frame = left
        self.dex_result_list = tk.Listbox(left, exportselection=False)
        self.dex_result_list.grid(row=0, column=0, sticky="nsew")
        dex_list_scroll = ttk.Scrollbar(left, orient="vertical", command=self.dex_result_list.yview)
        dex_list_scroll.grid(row=0, column=1, sticky="ns")
        self.dex_result_list.configure(yscrollcommand=dex_list_scroll.set)
        self.dex_result_list.bind("<<ListboxSelect>>", self._on_dex_result_selected)
        shell.add(left, weight=2)

        right = ttk.Frame(shell)
        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)
        self.dex_result_frame = right
        header = ttk.Frame(right, padding=(10, 8), relief="groove")
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(1, weight=1)

        self.dex_sprite_placeholder = tk.PhotoImage(width=96, height=96)
        self.dex_sprite_label = ttk.Label(header, image=self.dex_sprite_placeholder)
        self.dex_sprite_label.grid(row=0, column=0, rowspan=3, sticky="nw", padx=(0, 12))
        self.dex_sprite_label.image = self.dex_sprite_placeholder

        ttk.Label(header, textvariable=self.dex_title_var, font=("", 14, "bold")).grid(row=0, column=1, sticky="w")
        ttk.Label(header, textvariable=self.dex_subtitle_var, foreground="#4d4d4d").grid(row=1, column=1, sticky="w")
        self.dex_hero_frame = ttk.Frame(header)
        self.dex_hero_frame.grid(row=2, column=1, sticky="ew", pady=(6, 0))
        self.dex_hero_frame.columnconfigure(1, weight=1)

        detail_shell = ttk.Frame(right)
        detail_shell.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        detail_shell.columnconfigure(0, weight=1)
        detail_shell.rowconfigure(0, weight=1)

        self.dex_detail_canvas = tk.Canvas(detail_shell, borderwidth=0, highlightthickness=0)
        self.dex_detail_canvas.grid(row=0, column=0, sticky="nsew")
        dex_detail_scroll = ttk.Scrollbar(detail_shell, orient="vertical", command=self.dex_detail_canvas.yview)
        dex_detail_scroll.grid(row=0, column=1, sticky="ns")
        self.dex_detail_canvas.configure(yscrollcommand=dex_detail_scroll.set)

        self.dex_detail_body = ttk.Frame(self.dex_detail_canvas)
        self._dex_detail_window = self.dex_detail_canvas.create_window((0, 0), window=self.dex_detail_body, anchor="nw")
        self.dex_detail_body.bind(
            "<Configure>",
            lambda _e: self.dex_detail_canvas.configure(scrollregion=self.dex_detail_canvas.bbox("all")),
        )
        self.dex_detail_canvas.bind(
            "<Configure>",
            lambda e: self.dex_detail_canvas.itemconfigure(self._dex_detail_window, width=e.width),
        )
        self.dex_detail_canvas.bind("<MouseWheel>", self._on_dex_detail_mousewheel, add="+")
        self.dex_detail_canvas.bind("<Button-4>", self._on_dex_detail_mousewheel, add="+")
        self.dex_detail_canvas.bind("<Button-5>", self._on_dex_detail_mousewheel, add="+")
        self.dex_detail_body.bind("<MouseWheel>", self._on_dex_detail_mousewheel, add="+")
        self.dex_detail_body.bind("<Button-4>", self._on_dex_detail_mousewheel, add="+")
        self.dex_detail_body.bind("<Button-5>", self._on_dex_detail_mousewheel, add="+")
        self._install_dex_global_mousewheel()

        shell.add(right, weight=5)
        shell.bind("<Configure>", self._on_dex_shell_configure, add="+")
        shell.bind("<B1-Motion>", self._on_dex_shell_drag, add="+")
        shell.bind("<ButtonRelease-1>", self._on_dex_shell_drag, add="+")
        tab.after(60, self._dex_init_split_limits)

        self._update_dex_query_values()
        self._on_dex_search_changed()

    def _on_dex_shell_configure(self, _event=None):
        if not hasattr(self, "dex_shell"):
            return
        if not self._dex_split_initialized:
            self._dex_split_initialized = True
            self.root.after_idle(self._dex_init_split_limits)
            return
        self.root.after_idle(self._dex_apply_split_constraints)

    def _on_dex_shell_drag(self, _event=None):
        if not hasattr(self, "dex_shell"):
            return
        self.root.after_idle(self._dex_apply_split_constraints)

    def _dex_init_split_limits(self):
        if not hasattr(self, "dex_shell") or not hasattr(self, "dex_filter_frame"):
            return
        shell = self.dex_shell
        try:
            shell.update_idletasks()
            current = int(shell.sashpos(0))
        except Exception:
            try:
                current = max(220, int(self.dex_filter_frame.winfo_width()))
            except Exception:
                current = 260
        min_left = max(160, min(280, int(current * 0.55)))
        self._dex_split_min_left_width = min_left
        self._dex_split_max_left_width = max(min_left, current)
        self._dex_apply_split_constraints()

    def _dex_apply_split_constraints(self):
        if not hasattr(self, "dex_shell"):
            return
        shell = self.dex_shell
        try:
            total_w = int(shell.winfo_width())
            if total_w <= 1:
                return
            min_left = max(120, int(self._dex_split_min_left_width or 180))
            max_left_cfg = int(self._dex_split_max_left_width or 0)
            if max_left_cfg <= 0:
                max_left_cfg = max(min_left, int(total_w * 0.33))
                self._dex_split_max_left_width = max_left_cfg

            # Keep result/details pane usable while allowing the filter pane to shrink.
            right_min = max(420, int(total_w * 0.48))
            dynamic_max = max(min_left, total_w - right_min)
            max_left = max(min_left, min(max_left_cfg, dynamic_max))

            current = int(shell.sashpos(0))
            desired = max(min_left, min(current, max_left))
            if desired != current:
                shell.sashpos(0, desired)
        except Exception:
            return

    def _dex_selected_category_key(self) -> str:
        label = (self.dex_category_var.get().strip() or DEX_CATEGORY_KEY_TO_LABEL.get("Species", "Pokédex"))
        return DEX_CATEGORY_LABEL_TO_KEY.get(label, "Species")

    @staticmethod
    def _dex_category_label_for_key(category_key: str) -> str:
        return DEX_CATEGORY_KEY_TO_LABEL.get(category_key, category_key)

    def _on_dex_category_changed(self, _event=None):
        self._hide_dex_tooltip()
        self.dex_search_var.set("")
        is_species = self._dex_selected_category_key() == "Species"
        self.dex_form_entry.configure(state="normal" if is_species else "disabled")
        self._update_dex_query_values()

    def _on_dex_form_changed(self, _event=None):
        if self._dex_selected_category_key() == "Species":
            self._on_dex_query_confirmed()

    def _on_dex_search_changed(self, _event=None):
        if not hasattr(self, "dex_result_list"):
            return
        query = self.dex_search_var.get().strip().casefold()
        previous_id = self._resolve_dex_entry_id()
        if query:
            pairs = [pair for pair in self._dex_pairs if query in f"{pair[0]} {pair[1]}".casefold()]
        else:
            pairs = list(self._dex_pairs)
        self._dex_visible_pairs = pairs
        self.dex_result_list.delete(0, tk.END)
        for label, _entry_id in pairs:
            self.dex_result_list.insert(tk.END, label)
        self.dex_result_count_var.set(f"{len(pairs)} results")

        if not pairs:
            self._on_dex_query_confirmed()
            return

        index = 0
        if previous_id:
            for i, (_label, entry_id) in enumerate(pairs):
                if entry_id == previous_id:
                    index = i
                    break
        try:
            self.dex_result_list.selection_clear(0, tk.END)
            self.dex_result_list.selection_set(index)
            self.dex_result_list.activate(index)
            self.dex_result_list.see(index)
        except tk.TclError:
            pass
        self._on_dex_query_confirmed()

    def _on_dex_result_selected(self, _event=None):
        self._on_dex_query_confirmed()

    def _on_dex_query_confirmed(self, _event=None):
        self._hide_dex_tooltip()
        if not hasattr(self, "dex_detail_body"):
            return
        if not self.catalogs:
            self._dex_render_payload(
                {
                    "title": "Dex",
                    "subtitle": "Catalog data is not loaded.",
                    "hero": [],
                    "sections": [
                        {
                            "kind": "text",
                            "title": "Status",
                            "text": "Catalog data is not loaded.",
                        }
                    ],
                }
            )
            return
        category_key = self._dex_selected_category_key()
        entry_id = self._resolve_dex_entry_id()
        if not entry_id:
            self._dex_render_payload(
                {
                    "title": "Dex",
                    "subtitle": "No matching entry selected.",
                    "hero": [],
                    "sections": [
                        {
                            "kind": "text",
                            "title": "Status",
                            "text": "No matching entry selected.",
                        }
                    ],
                }
            )
            return
        try:
            payload = self._dex_build_payload(category_key, entry_id)
        except Exception as exc:  # noqa: BLE001
            payload = {
                "title": "Dex",
                "subtitle": "Failed to render details.",
                "hero": [],
                "sections": [
                    {
                        "kind": "text",
                        "title": "Error",
                        "text": f"Failed to render Dex details:\n{exc}",
                    }
                ],
            }
        self._dex_render_payload(payload)

    def _update_dex_query_values(self):
        if not hasattr(self, "dex_result_list"):
            return
        if not self.catalogs:
            self._dex_pairs = []
            self._dex_visible_pairs = []
            self.dex_result_list.delete(0, tk.END)
            self.dex_result_count_var.set("0 results")
            return

        category = self._dex_selected_category_key()
        pairs: list[tuple[str, str]] = []
        if category == "Species":
            choices = self.catalogs.base_species_choices()
            for item in choices:
                sid = self.catalogs.canonical_species_id(item.internal_id) or item.internal_id
                label = self._dex_display_name_for_entry("Species", sid)
                if sid:
                    pairs.append((label, sid))
        elif category == "Moves":
            for mid in sorted(self.catalogs.moves_by_id.keys(), key=str.casefold):
                pairs.append((self._dex_display_name_for_entry("Moves", mid), mid))
        elif category == "Items":
            for iid in sorted(self.catalogs.items_by_id.keys(), key=str.casefold):
                pairs.append((self._dex_display_name_for_entry("Items", iid), iid))
        elif category == "Abilities":
            for aid in sorted(self.catalogs.abilities_by_id.keys(), key=str.casefold):
                pairs.append((self._dex_display_name_for_entry("Abilities", aid), aid))
        elif category == "Natures":
            for nature in sorted((str(n).strip().upper() for n in self.catalogs.natures), key=str.casefold):
                if nature:
                    pairs.append((self._dex_display_name_for_entry("Natures", nature), nature))
        elif category == "Types":
            for tid in sorted(self.catalogs.type_names_by_id.keys(), key=str.casefold):
                pairs.append((self._dex_display_name_for_entry("Types", tid), tid))
        pairs.sort(key=lambda row: row[0].casefold())
        self._dex_pairs = pairs
        self._on_dex_search_changed()

    def _resolve_dex_entry_id(self) -> str:
        if not hasattr(self, "dex_result_list"):
            return ""
        selection = self.dex_result_list.curselection()
        if not selection:
            return ""
        idx = int(selection[0])
        if idx < 0 or idx >= len(self._dex_visible_pairs):
            return ""
        _label, entry_id = self._dex_visible_pairs[idx]
        return entry_id

    def _dex_display_name_for_entry(self, category_key: str, entry_id: str) -> str:
        if not self.catalogs:
            return self._prettify_internal_id(entry_id)
        key = str(category_key or "").strip()
        eid = str(entry_id or "").strip().lstrip(":")
        if key == "Species":
            canonical = self.catalogs.canonical_species_id(eid) or eid
            return self._prettify_internal_id(canonical)
        if key == "Moves":
            canonical = self.catalogs.canonical_move_id(eid) or eid
            return self._prettify_internal_id(canonical)
        if key == "Items":
            canonical = self.catalogs.canonical_item_id(eid) or eid
            return self._dex_item_display_name(canonical)
        if key == "Abilities":
            canonical = self.catalogs.canonical_ability_id(eid) or eid
            return self._english_ability_name_for_id(canonical)
        if key == "Natures":
            return self._title_case_words(eid)
        if key == "Types":
            return self._prettify_internal_id(eid)
        return self._prettify_internal_id(eid)

    def _dex_item_display_name(self, item_id: str) -> str:
        raw = str(item_id or "").strip().lstrip(":")
        if not raw:
            return ""
        canonical = self.catalogs.canonical_item_id(raw) if self.catalogs else raw
        canonical = canonical or raw
        m = re.match(r"^(TM|HM)(\d+)$", canonical, flags=re.IGNORECASE)
        if not m or not self.catalogs:
            return self._prettify_internal_id(canonical)
        label = self._tm_hm_display_label(canonical, pocket_index=4)
        if label and label.upper() != canonical.upper():
            return label
        return canonical.upper()

    @staticmethod
    def _dex_tm_sort_key(item_id: str) -> tuple[int, int, str]:
        raw = str(item_id or "").strip().upper()
        m = re.match(r"^(TM|HM)(\d+)$", raw)
        if not m:
            return (2, 9999, raw)
        bucket = 0 if m.group(1) == "TM" else 1
        try:
            num = int(m.group(2))
        except ValueError:
            num = 9999
        return (bucket, num, raw)

    def _dex_move_tm_labels(self, move_id: str) -> list[str]:
        if not self.catalogs:
            return []
        canonical_move = self.catalogs.canonical_move_id(move_id) or str(move_id or "").strip().lstrip(":")
        if not canonical_move:
            return []
        if self._dex_move_tm_map is None:
            move_tm_map: dict[str, list[str]] = {}
            for iid, item in self.catalogs.items_by_id.items():
                m = re.match(r"^(TM|HM)(\d+)$", iid, flags=re.IGNORECASE)
                if not m:
                    continue
                move_raw = str(item.extra.get("Move", "")).strip().lstrip(":")
                if not move_raw:
                    continue
                mid = self.catalogs.canonical_move_id(move_raw) or move_raw
                if not mid:
                    continue
                move_tm_map.setdefault(mid, []).append(iid.upper())
            for mid in list(move_tm_map.keys()):
                uniq = sorted(set(move_tm_map[mid]), key=self._dex_tm_sort_key)
                move_tm_map[mid] = uniq
            self._dex_move_tm_map = move_tm_map
        return list(self._dex_move_tm_map.get(canonical_move, []))

    @staticmethod
    def _dex_entity_cell(raw: Any) -> tuple[str, str, str] | None:
        if not isinstance(raw, dict):
            return None
        kind = str(raw.get("kind", "")).strip().casefold()
        entry_id = str(raw.get("id", "")).strip().lstrip(":")
        label = str(raw.get("label", "")).strip()
        if kind not in {"move", "ability"} or not entry_id:
            return None
        if not label:
            label = entry_id
        return kind, entry_id, label

    def _dex_tooltip_enabled(self) -> bool:
        return self._dex_selected_category_key() == "Species"

    def _hide_dex_tooltip(self):
        tip = self._dex_tooltip_window
        if tip is None:
            return
        try:
            tip.withdraw()
        except Exception:
            pass

    def _show_dex_tooltip(self, text: str, x_root: int, y_root: int):
        content = str(text or "").strip()
        if not content:
            self._hide_dex_tooltip()
            return
        tip = self._dex_tooltip_window
        if tip is None or not tip.winfo_exists():
            tip = tk.Toplevel(self.root)
            tip.wm_overrideredirect(True)
            try:
                tip.attributes("-topmost", True)
            except Exception:
                pass
            label = tk.Label(
                tip,
                text=content,
                justify="left",
                anchor="nw",
                bg="#fffde8",
                fg="#1f1f1f",
                relief="solid",
                bd=1,
                padx=8,
                pady=6,
                font=("", 9),
                wraplength=520,
            )
            label.pack(fill="both", expand=True)
            self._dex_tooltip_window = tip
            self._dex_tooltip_label = label
        else:
            label = self._dex_tooltip_label
            if label is None or not label.winfo_exists():
                self._dex_tooltip_window = None
                self._dex_tooltip_label = None
                self._show_dex_tooltip(content, x_root, y_root)
                return
            label.configure(text=content)
        # Position tooltip with its top-left at the mouse tail.
        try:
            tip.wm_geometry(f"+{int(x_root) + 12}+{int(y_root) + 14}")
            tip.deiconify()
            tip.lift()
        except Exception:
            pass

    def _hide_party_tooltip(self):
        tip = self._party_tooltip_window
        if tip is None:
            return
        try:
            tip.withdraw()
        except Exception:
            pass

    def _show_party_tooltip(self, text: str, event: Any = None, widget: Any = None):
        content = str(text or "").strip()
        if not content:
            self._hide_party_tooltip()
            return
        tip = self._party_tooltip_window
        if tip is None or not tip.winfo_exists():
            tip = tk.Toplevel(self.root)
            tip.wm_overrideredirect(True)
            try:
                tip.attributes("-topmost", True)
            except Exception:
                pass
            label = tk.Label(
                tip,
                text=content,
                justify="left",
                anchor="nw",
                bg="#fffde8",
                fg="#1f1f1f",
                relief="solid",
                bd=1,
                padx=8,
                pady=6,
                font=("", 9),
                wraplength=560,
            )
            label.pack(fill="both", expand=True)
            self._party_tooltip_window = tip
            self._party_tooltip_label = label
        else:
            label = self._party_tooltip_label
            if label is None or not label.winfo_exists():
                self._party_tooltip_window = None
                self._party_tooltip_label = None
                self._show_party_tooltip(content, event=event, widget=widget)
                return
            label.configure(text=content)
        try:
            if event is not None and hasattr(event, "x_root") and hasattr(event, "y_root"):
                x_root = int(getattr(event, "x_root"))
                y_root = int(getattr(event, "y_root"))
                if x_root <= 0 and y_root <= 0 and widget is not None:
                    x_root = int(widget.winfo_rootx()) + 8
                    y_root = int(widget.winfo_rooty()) + int(widget.winfo_height()) + 6
            elif widget is not None:
                x_root = int(widget.winfo_rootx()) + 8
                y_root = int(widget.winfo_rooty()) + int(widget.winfo_height()) + 6
            else:
                x_root = int(self.root.winfo_pointerx())
                y_root = int(self.root.winfo_pointery())
            # Top-left of tooltip starts at cursor tail.
            tip.wm_geometry(f"+{x_root + 12}+{y_root + 14}")
            tip.deiconify()
            tip.lift()
        except Exception:
            pass

    def _dex_move_tooltip_text(self, move_id: str) -> str:
        if not self.catalogs:
            return ""
        canonical = self.catalogs.canonical_move_id(move_id) or str(move_id or "").strip().lstrip(":")
        if not canonical:
            return ""
        cached = self._dex_tooltip_move_cache.get(canonical)
        if cached is not None:
            return cached
        raw_desc = self.catalogs.move_description(canonical)
        summary = self._move_numeric_summary_lines(canonical, raw_desc, "")
        summary = [
            line
            for line in summary
            if not line.startswith("Internal function code:")
            and not line.startswith("Numeric values detected in description text:")
        ]
        base_desc, summary = self._resolve_entity_description("move", canonical, raw_desc, summary)
        if summary:
            if base_desc:
                text = f"{base_desc}\n\n" + "\n".join(f"- {line}" for line in summary)
            else:
                text = "\n".join(f"- {line}" for line in summary)
        else:
            text = base_desc
        text = text.strip()
        self._dex_tooltip_move_cache[canonical] = text
        return text

    def _dex_ability_tooltip_text(self, ability_id: str) -> str:
        if not self.catalogs:
            return ""
        canonical = self.catalogs.canonical_ability_id(ability_id) or str(ability_id or "").strip().lstrip(":")
        if not canonical:
            return ""
        cached = self._dex_tooltip_ability_cache.get(canonical)
        if cached is not None:
            return cached
        raw_desc = self.catalogs.ability_description(canonical)
        summary = self._ability_numeric_summary_lines(canonical, raw_desc, "")
        summary = [
            line
            for line in summary
            if not line.startswith("Numeric values detected in description text:")
        ]
        base_desc, summary = self._resolve_entity_description("ability", canonical, raw_desc, summary)
        if summary:
            if base_desc:
                text = f"{base_desc}\n\n" + "\n".join(f"- {line}" for line in summary)
            else:
                text = "\n".join(f"- {line}" for line in summary)
        else:
            text = base_desc
        text = text.strip()
        self._dex_tooltip_ability_cache[canonical] = text
        return text

    def _dex_entity_tooltip_text(self, kind: str, entry_id: str) -> str:
        if kind == "move":
            return self._dex_move_tooltip_text(entry_id)
        if kind == "ability":
            return self._dex_ability_tooltip_text(entry_id)
        return ""

    def _bind_dex_entity_tooltip(self, widget, kind: str, entry_id: str):
        def on_hover(event):
            if not self._dex_tooltip_enabled():
                self._hide_dex_tooltip()
                return
            text = self._dex_entity_tooltip_text(kind, entry_id)
            if not text:
                self._hide_dex_tooltip()
                return
            self._show_dex_tooltip(text, event.x_root, event.y_root)

        widget.bind("<Enter>", on_hover, add="+")
        widget.bind("<Motion>", on_hover, add="+")
        widget.bind("<Leave>", lambda _e: self._hide_dex_tooltip(), add="+")
        widget.bind("<ButtonPress>", lambda _e: self._hide_dex_tooltip(), add="+")

    def _dex_move_detail_cells(self, move_id: str) -> tuple[str, str, str, str, str]:
        if not self.catalogs:
            mid = str(move_id or "").strip().lstrip(":")
            return (self._prettify_internal_id(mid), "-", "-", "-", "-")
        mid = self.catalogs.canonical_move_id(move_id) or str(move_id or "").strip().lstrip(":")
        move_name = self._dex_display_name_for_entry("Moves", mid)
        move = self.catalogs.moves_by_id.get(mid)
        if not move:
            return (move_name, "-", "-", "-", "-")
        move_type = self._prettify_internal_id(str(move.extra.get("Type", "")).strip().lstrip(":")) or "-"
        category_raw = str(move.extra.get("Category", "")).strip().lstrip(":")
        category = self._prettify_internal_id(category_raw) if category_raw else "-"
        power = str(move.extra.get("Power", "")).strip() or "-"
        acc = str(move.extra.get("Accuracy", "")).strip() or "-"
        return (move_name, move_type, category, power, acc)

    def _dex_move_rows_for_ids(self, move_ids: list[str]) -> list[tuple[Any, Any, Any, Any, Any]]:
        rows: list[tuple[Any, Any, Any, Any, Any]] = []
        seen: set[str] = set()
        for raw in move_ids:
            mid = (self.catalogs.canonical_move_id(raw) if self.catalogs else raw) or str(raw or "").strip().lstrip(":")
            if not mid or mid in seen:
                continue
            move_name, move_type, category, power, acc = self._dex_move_detail_cells(mid)
            rows.append(({"kind": "move", "id": mid, "label": move_name}, move_type, category, power, acc))
            seen.add(mid)
        rows.sort(key=lambda row: self._value_to_text(row[0]).casefold())
        return rows

    def _dex_tm_rows_for_species(self, valid_moves: list[str]) -> list[tuple[Any, Any, Any, Any, Any, Any]]:
        if not self.catalogs:
            return []
        valid_set = {
            (self.catalogs.canonical_move_id(mid) or str(mid or "").strip().lstrip(":"))
            for mid in valid_moves
            if str(mid or "").strip()
        }
        rows: list[tuple[Any, Any, Any, Any, Any, Any]] = []
        for iid, item in self.catalogs.items_by_id.items():
            m = re.match(r"^(TM|HM)(\d+)$", iid, flags=re.IGNORECASE)
            if not m:
                continue
            move_raw = str(item.extra.get("Move", "")).strip().lstrip(":")
            if not move_raw:
                continue
            move_id = self.catalogs.canonical_move_id(move_raw) or move_raw
            if move_id not in valid_set:
                continue
            move_name, move_type, category, power, acc = self._dex_move_detail_cells(move_id)
            rows.append((iid.upper(), {"kind": "move", "id": move_id, "label": move_name}, move_type, category, power, acc))
        rows.sort(key=lambda row: self._dex_tm_sort_key(row[0]))
        return rows

    @staticmethod
    def _dex_join_list(values: list[str], limit: int = 40) -> str:
        if not values:
            return "(none)"
        if len(values) <= limit:
            return ", ".join(values)
        extra = len(values) - limit
        return f"{', '.join(values[:limit])}, ... (+{extra} more)"

    def _dex_build_payload(self, category: str, entry_id: str) -> dict[str, Any]:
        raw_category = str(category or "").strip() or "Species"
        category_key = DEX_CATEGORY_LABEL_TO_KEY.get(raw_category, raw_category)
        if category_key == "Species":
            return self._dex_species_payload(entry_id)
        if category_key == "Moves":
            return self._dex_move_payload(entry_id)
        if category_key == "Items":
            return self._dex_item_payload(entry_id)
        if category_key == "Abilities":
            return self._dex_ability_payload(entry_id)
        if category_key == "Natures":
            return self._dex_nature_payload(entry_id)
        if category_key == "Types":
            return self._dex_type_payload(entry_id)
        return {
            "title": "Dex",
            "subtitle": "Unknown category.",
            "hero": [],
            "sections": [{"kind": "text", "title": "Status", "text": "Unknown category."}],
        }

    def _dex_render_payload(self, payload: dict[str, Any]):
        title = str(payload.get("title", "Dex"))
        subtitle = str(payload.get("subtitle", ""))
        hero = payload.get("hero", [])
        sections = payload.get("sections", [])
        sprite_spec = payload.get("image")

        # Backward compatibility for previous payload shape.
        if not sections:
            overview = payload.get("overview", [])
            rows = payload.get("rows", [])
            notes = str(payload.get("notes", "")).strip()
            sections = []
            if overview:
                sections.append({"kind": "kv", "title": "Overview", "rows": overview})
            if rows:
                sections.append(
                    {
                        "kind": "table",
                        "title": "Details",
                        "columns": ["Section", "Entry"],
                        "rows": rows,
                    }
                )
            if notes:
                sections.append({"kind": "text", "title": "Description", "text": notes})
            if not sections:
                sections = [{"kind": "text", "title": "Status", "text": "No details available."}]

        self.dex_title_var.set(title)
        self.dex_subtitle_var.set(subtitle)
        self._dex_set_sprite_preview(sprite_spec)

        for child in self.dex_hero_frame.winfo_children():
            child.destroy()
        for row_idx, row in enumerate(hero):
            if not isinstance(row, (list, tuple)) or len(row) < 2:
                continue
            key = str(row[0])
            value = row[1]
            ttk.Label(self.dex_hero_frame, text=f"{key}:", font=("", 9, "bold")).grid(
                row=row_idx, column=0, sticky="nw", padx=(0, 6), pady=1
            )
            self._render_value_or_type_chips(
                self.dex_hero_frame,
                key,
                value,
                row=row_idx,
                column=1,
                wraplength=740,
                short=False,
                max_per_row=3,
            )

        self._dex_clear_detail_sections()
        for section in sections:
            if not isinstance(section, dict):
                continue
            kind = str(section.get("kind", "text")).strip().lower()
            title_text = str(section.get("title", "Section"))
            if kind == "kv":
                self._dex_add_kv_section(title_text, section.get("rows", []))
            elif kind == "table":
                self._dex_add_table_section(
                    title_text,
                    section.get("columns", []),
                    section.get("rows", []),
                    section.get("height"),
                )
            elif kind == "evolution_chart":
                self._dex_add_evolution_chart_section(
                    title_text,
                    str(section.get("species_id", "")).strip(),
                    self._clamp_int(str(section.get("form", 0)), 0, 999, 0),
                    section.get("height"),
                    bool(section.get("show_all_conditions", False)),
                )
            elif kind == "stats":
                self._dex_add_stats_section(title_text, section.get("rows", []))
            elif kind == "moves_grid":
                self._dex_add_moves_grid_section(title_text, section.get("blocks", []))
            elif kind == "type_matchups":
                self._dex_add_type_matchups_section(
                    title_text,
                    section.get("defenses", []),
                    section.get("attacks", []),
                    str(section.get("defense_title", "Type Defenses")),
                    str(section.get("attack_title", "Type Attacks")),
                )
            else:
                text = str(section.get("text", "")).strip() or "No details available."
                self._dex_add_text_section(title_text, text)

        try:
            self.dex_detail_body.update_idletasks()
            self.dex_detail_canvas.configure(scrollregion=self.dex_detail_canvas.bbox("all"))
            self.dex_detail_canvas.yview_moveto(0.0)
        except Exception:
            pass
        self._dex_bind_mousewheel_recursive(self.dex_detail_body)

    def _install_dex_global_mousewheel(self):
        if self._dex_global_wheel_enabled:
            return
        try:
            self.root.bind_all("<MouseWheel>", self._on_dex_global_mousewheel, add="+")
            self.root.bind_all("<Button-4>", self._on_dex_global_mousewheel, add="+")
            self.root.bind_all("<Button-5>", self._on_dex_global_mousewheel, add="+")
            self._dex_global_wheel_enabled = True
        except Exception:
            self._dex_global_wheel_enabled = False

    def _on_dex_global_mousewheel(self, event):
        if not hasattr(self, "dex_detail_canvas") or not hasattr(self, "nb") or not hasattr(self, "dex_tab"):
            return
        try:
            if str(self.nb.select()) != str(self.dex_tab):
                return
        except Exception:
            return
        canvas = self.dex_detail_canvas
        target = getattr(event, "widget", None)
        if not self._is_widget_descendant(target, canvas):
            try:
                hovered = self.root.winfo_containing(self.root.winfo_pointerx(), self.root.winfo_pointery())
            except Exception:
                hovered = None
            if not self._is_widget_descendant(hovered, canvas):
                return
        return self._scroll_canvas_mousewheel(canvas, event)

    def _dex_bind_mousewheel_recursive(self, widget):
        if self._dex_global_wheel_enabled:
            return
        if widget is None:
            return
        key = str(widget)
        if key not in self._dex_wheel_bound_widgets:
            try:
                widget.bind("<MouseWheel>", self._on_dex_detail_mousewheel, add="+")
                widget.bind("<Button-4>", self._on_dex_detail_mousewheel, add="+")
                widget.bind("<Button-5>", self._on_dex_detail_mousewheel, add="+")
                self._dex_wheel_bound_widgets.add(key)
            except Exception:
                pass
        try:
            children = widget.winfo_children()
        except Exception:
            children = []
        for child in children:
            self._dex_bind_mousewheel_recursive(child)

    @staticmethod
    def _is_widget_descendant(widget, parent) -> bool:
        if widget is None or parent is None:
            return False
        wname = str(widget)
        pname = str(parent)
        return wname == pname or wname.startswith(f"{pname}.")

    def _on_dex_detail_mousewheel(self, event):
        if not hasattr(self, "dex_detail_canvas"):
            return
        canvas = self.dex_detail_canvas
        target = getattr(event, "widget", None)
        if not self._is_widget_descendant(target, canvas):
            try:
                hovered = self.root.winfo_containing(self.root.winfo_pointerx(), self.root.winfo_pointery())
            except Exception:
                hovered = None
            if not self._is_widget_descendant(hovered, canvas):
                return

        return self._scroll_canvas_mousewheel(canvas, event)

    def _dex_set_sprite_preview(self, sprite_spec: Any):
        if not hasattr(self, "dex_sprite_label"):
            return
        img = self.dex_sprite_placeholder
        if isinstance(sprite_spec, dict):
            species_id = str(sprite_spec.get("species_id", "")).strip()
            item_id = str(sprite_spec.get("item_id", "")).strip()
            form = self._clamp_int(str(sprite_spec.get("form", 0)), 0, 999, 0)
            shiny = bool(sprite_spec.get("shiny", False))
            if species_id:
                img2 = self._get_party_preview_icon_image(species_id, form=form, shiny=shiny)
                if img2 is not None:
                    img = img2
            elif item_id:
                img2 = self._get_item_icon_image(item_id)
                if img2 is not None:
                    try:
                        img = img2.zoom(2, 2) if img2.width() <= 32 else img2
                    except Exception:
                        img = img2
        self.dex_sprite_label.configure(image=img)
        self.dex_sprite_label.image = img

    def _dex_clear_detail_sections(self):
        self._hide_dex_tooltip()
        for frame in self._dex_detail_sections:
            try:
                frame.destroy()
            except Exception:
                pass
        self._dex_detail_sections = []

    def _dex_add_text_section(self, title: str, text: str):
        frame = ttk.LabelFrame(self.dex_detail_body, text=title, padding=8)
        frame.pack(fill="x", expand=False, pady=(0, 8))
        is_description = str(title or "").strip().casefold() == "description"
        lbl_font = ("", 9, "bold") if is_description else None
        ttk.Label(frame, text=text, justify="left", wraplength=860, font=lbl_font).pack(anchor="w")
        self._dex_detail_sections.append(frame)

    def _dex_add_kv_section(self, title: str, rows: Any):
        frame = ttk.LabelFrame(self.dex_detail_body, text=title, padding=8)
        frame.pack(fill="x", expand=False, pady=(0, 8))
        frame.columnconfigure(1, weight=1)
        row_items = rows if isinstance(rows, list) else []
        if not row_items:
            ttk.Label(frame, text="(none)").grid(row=0, column=0, sticky="w")
            self._dex_detail_sections.append(frame)
            return
        for idx, row in enumerate(row_items):
            if not isinstance(row, (list, tuple)) or len(row) < 2:
                continue
            key = str(row[0]).strip()
            value = row[1]
            ttk.Label(frame, text=f"{key}:", font=("", 9, "bold")).grid(
                row=idx, column=0, sticky="nw", padx=(0, 8), pady=1
            )
            value_list = value if isinstance(value, list) else []
            ability_entities = [
                self._dex_entity_cell(entry)
                for entry in value_list
                if isinstance(entry, dict)
            ]
            ability_entities = [entry for entry in ability_entities if entry is not None and entry[0] == "ability"]
            if key.casefold() == "abilities" and ability_entities:
                holder = ttk.Frame(frame)
                holder.grid(row=idx, column=1, sticky="nw", pady=1)
                row_cursor = 0
                col_cursor = 0
                for kind, entry_id, label in ability_entities:
                    chip = tk.Label(
                        holder,
                        text=label,
                        bg="#f0f2f5",
                        fg="#1f1f1f",
                        padx=6,
                        pady=2,
                        bd=1,
                        relief="solid",
                        font=("", 8, "bold"),
                    )
                    chip.grid(row=row_cursor, column=col_cursor, sticky="w", padx=2, pady=1)
                    self._bind_dex_entity_tooltip(chip, kind, entry_id)
                    col_cursor += 1
                    if col_cursor >= 3:
                        col_cursor = 0
                        row_cursor += 1
                continue
            self._render_value_or_type_chips(
                frame,
                key,
                value,
                row=idx,
                column=1,
                wraplength=820,
                short=False,
                max_per_row=4,
            )
        self._dex_detail_sections.append(frame)

    def _dex_add_table_section(self, title: str, columns: Any, rows: Any, height_hint: Any = None):
        frame = ttk.LabelFrame(self.dex_detail_body, text=title, padding=8)
        frame.pack(fill="both", expand=False, pady=(0, 8))
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)

        col_list = [str(c) for c in columns if str(c).strip()] if isinstance(columns, list) else []
        if not col_list:
            col_list = ["Value"]

        row_list = rows if isinstance(rows, list) else []
        try:
            hinted = int(height_hint)
        except (TypeError, ValueError):
            hinted = 0
        if hinted <= 0:
            hinted = max(1, min(7, len(row_list) if row_list else 1))

        type_cols = [idx for idx, label in enumerate(col_list) if self._is_type_field_label(label)]
        if type_cols:
            self._dex_add_type_aware_table_content(frame, col_list, row_list, hinted, type_cols)
            self._dex_detail_sections.append(frame)
            return

        tree = ttk.Treeview(
            frame,
            columns=tuple(f"c{i}" for i in range(len(col_list))),
            show="headings",
            height=hinted,
        )
        for idx, label in enumerate(col_list):
            cid = f"c{idx}"
            tree.heading(cid, text=label)
            stretch = idx == len(col_list) - 1
            width = 110 if len(col_list) > 1 else 320
            tree.column(cid, anchor="w", width=width, stretch=stretch)
        tree.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        tree.configure(yscrollcommand=scroll.set)

        if not row_list:
            tree.insert("", "end", values=("(none)",) + tuple("" for _ in range(len(col_list) - 1)))
        else:
            for row in row_list:
                if isinstance(row, (list, tuple)):
                    values = [str(v) for v in row[: len(col_list)]]
                else:
                    values = [str(row)]
                while len(values) < len(col_list):
                    values.append("")
                tree.insert("", "end", values=tuple(values))
        self._dex_detail_sections.append(frame)

    def _dex_add_type_aware_table_content(
        self,
        frame: ttk.LabelFrame,
        col_list: list[str],
        row_list: list[Any],
        hinted: int,
        type_cols: list[int],
    ):
        shell = ttk.Frame(frame)
        shell.grid(row=0, column=0, sticky="nsew")
        shell.columnconfigure(0, weight=1)
        shell.rowconfigure(1, weight=1)

        header = ttk.Frame(shell)
        header.grid(row=0, column=0, sticky="ew")
        for idx, label in enumerate(col_list):
            header.columnconfigure(idx, weight=1 if idx == len(col_list) - 1 else 0)
            ttk.Label(header, text=label, font=("", 9, "bold")).grid(
                row=0, column=idx, sticky="w", padx=(2, 8), pady=(0, 4)
            )

        body_canvas_h = max(68, min(420, (max(1, hinted) * 30) + 8))
        canvas = tk.Canvas(shell, height=body_canvas_h, borderwidth=0, highlightthickness=0)
        canvas.grid(row=1, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(shell, orient="vertical", command=canvas.yview)
        scroll.grid(row=1, column=1, sticky="ns")
        canvas.configure(yscrollcommand=scroll.set)

        body = ttk.Frame(canvas)
        body_window = canvas.create_window((0, 0), window=body, anchor="nw")
        body.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(body_window, width=e.width), add="+")
        self._dex_bind_mousewheel_recursive(body)

        if not row_list:
            row_list = [("(none)",) + tuple("" for _ in range(max(0, len(col_list) - 1)))]

        for ridx, row in enumerate(row_list):
            if isinstance(row, (list, tuple)):
                values: list[Any] = list(row[: len(col_list)])
            else:
                values = [row]
            while len(values) < len(col_list):
                values.append("")

            for cidx, raw in enumerate(values):
                body.columnconfigure(cidx, weight=1 if cidx == len(col_list) - 1 else 0)
                cell = ttk.Frame(body)
                cell.grid(row=ridx, column=cidx, sticky="nw", padx=(2, 8), pady=1)
                if cidx in type_cols:
                    type_ids = self._extract_type_ids(raw)
                    if type_ids:
                        self._render_type_chip_row(
                            cell,
                            type_ids,
                            short=False,
                            empty_text="-",
                            max_per_row=3,
                            clear_existing=False,
                        )
                    else:
                        ttk.Label(cell, text=self._value_to_text(raw).strip() or "-", justify="left").pack(anchor="w")
                else:
                    ttk.Label(
                        cell,
                        text=self._value_to_text(raw).strip(),
                        justify="left",
                        wraplength=360,
                    ).pack(anchor="w")

    @staticmethod
    def _dex_table_column_layout(col_list: list[str]) -> list[tuple[int, int]]:
        out: list[tuple[int, int]] = []
        for idx, raw_label in enumerate(col_list):
            label = re.sub(r"[^a-z0-9]+", " ", str(raw_label or "").casefold()).strip()
            if label in {"lv", "lvl", "level", "tm", "hm", "tm no", "hm no"}:
                out.append((0, 58))
            elif label in {"move", "name"}:
                out.append((3, 180))
            elif label in {"type"}:
                out.append((1, 92))
            elif label in {"cat", "category"}:
                out.append((0, 72))
            elif label in {"power", "acc", "accuracy", "pp", "rate", "levels"}:
                out.append((0, 66))
            elif label in {"map", "method", "location"}:
                out.append((2, 140))
            else:
                out.append((1 if idx == len(col_list) - 1 else 0, 110))
        if out and not any(weight > 0 for weight, _min_w in out):
            weight, min_w = out[-1]
            out[-1] = (max(1, weight), min_w)
        return out

    def _dex_add_inline_table_content(self, frame: ttk.Frame, col_list: list[str], row_list: list[Any]):
        table = ttk.Frame(frame)
        table.grid(row=0, column=0, sticky="ew")
        specs = self._dex_table_column_layout(col_list)
        for idx, (weight, min_w) in enumerate(specs):
            table.columnconfigure(idx, weight=weight, minsize=min_w)

        for cidx, label in enumerate(col_list):
            ttk.Label(table, text=str(label), font=("", 9, "bold")).grid(
                row=0, column=cidx, sticky="w", padx=(2, 8), pady=(0, 4)
            )
        ttk.Separator(table, orient="horizontal").grid(
            row=1, column=0, columnspan=max(1, len(col_list)), sticky="ew", pady=(0, 4)
        )

        norm_rows = row_list if row_list else [("(none)",) + tuple("" for _ in range(max(0, len(col_list) - 1)))]
        for ridx, row in enumerate(norm_rows, start=2):
            if isinstance(row, (list, tuple)):
                values = list(row[: len(col_list)])
            else:
                values = [row]
            while len(values) < len(col_list):
                values.append("")
            for cidx, raw in enumerate(values):
                cell = ttk.Frame(table)
                cell.grid(row=ridx, column=cidx, sticky="nw", padx=(2, 8), pady=1)
                entity = self._dex_entity_cell(raw)
                if entity is not None:
                    kind, entry_id, label = entity
                    lbl = ttk.Label(
                        cell,
                        text=label.strip() or "-",
                        justify="left",
                        wraplength=420 if cidx == len(col_list) - 1 else 280,
                    )
                    lbl.grid(row=0, column=0, sticky="nw")
                    self._bind_dex_entity_tooltip(lbl, kind, entry_id)
                    continue
                self._render_value_or_type_chips(
                    cell,
                    col_list[cidx],
                    raw,
                    row=0,
                    column=0,
                    wraplength=420 if cidx == len(col_list) - 1 else 280,
                    short=False,
                    max_per_row=3,
                    padx=(0, 0),
                    pady=0,
                )

    def _dex_add_moves_grid_section(self, title: str, blocks: Any):
        frame = ttk.LabelFrame(self.dex_detail_body, text=title, padding=8)
        frame.pack(fill="x", expand=False, pady=(0, 8))
        frame.columnconfigure(0, weight=1)

        shell = ttk.Frame(frame)
        shell.grid(row=0, column=0, sticky="ew")
        shell.columnconfigure(0, weight=1)
        shell.columnconfigure(1, weight=1)

        left_col = ttk.Frame(shell)
        right_col = ttk.Frame(shell)
        left_col.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        right_col.grid(row=0, column=1, sticky="nsew", padx=(6, 0))

        block_rows = blocks if isinstance(blocks, list) else []
        if not block_rows:
            ttk.Label(frame, text="No move data.").grid(row=1, column=0, sticky="w", pady=(6, 0))
            self._dex_detail_sections.append(frame)
            return

        left_items: list[dict[str, Any]] = []
        right_items: list[dict[str, Any]] = []
        for block in block_rows:
            if not isinstance(block, dict):
                continue
            target = right_items if int(block.get("column", 0)) == 1 else left_items
            target.append(block)
        left_items.sort(key=lambda b: int(b.get("order", 0)))
        right_items.sort(key=lambda b: int(b.get("order", 0)))

        def render_block(parent, block: dict[str, Any]):
            sub = ttk.LabelFrame(parent, text=str(block.get("title", "Moves")), padding=6)
            sub.pack(fill="x", expand=False, pady=(0, 8))
            sub.columnconfigure(0, weight=1)

            columns = block.get("columns", [])
            col_list = [str(c) for c in columns if str(c).strip()] if isinstance(columns, list) else []
            if not col_list:
                col_list = ["Value"]
            rows = block.get("rows", [])
            row_list = rows if isinstance(rows, list) else []
            self._dex_add_inline_table_content(sub, col_list, row_list)

        for block in left_items:
            render_block(left_col, block)
        for block in right_items:
            render_block(right_col, block)

        def _layout(_event=None):
            try:
                width = int(shell.winfo_width())
            except Exception:
                width = 0
            stacked = width > 0 and width < 900
            try:
                left_col.grid_forget()
                right_col.grid_forget()
            except Exception:
                pass
            if stacked:
                left_col.grid(row=0, column=0, sticky="ew", padx=(0, 0))
                right_col.grid(row=1, column=0, sticky="ew", padx=(0, 0))
                shell.columnconfigure(1, weight=0)
            else:
                left_col.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
                right_col.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
                shell.columnconfigure(1, weight=1)

        shell.bind("<Configure>", _layout, add="+")
        frame.after(10, _layout)
        self._dex_detail_sections.append(frame)

    def _dex_add_stats_section(self, title: str, rows: Any):
        frame = ttk.LabelFrame(self.dex_detail_body, text=title, padding=8)
        frame.pack(fill="x", expand=False, pady=(0, 8))
        frame.columnconfigure(1, weight=1)

        row_list = rows if isinstance(rows, list) else []
        if not row_list:
            ttk.Label(frame, text="(none)").grid(row=0, column=0, sticky="w")
            self._dex_detail_sections.append(frame)
            return

        total = 0
        for idx, row in enumerate(row_list):
            if not isinstance(row, (list, tuple)) or len(row) < 2:
                continue
            name = str(row[0]).strip()
            value = self._clamp_int(str(row[1]), 0, 255, 0)
            total += value
            ttk.Label(frame, text=name, width=8).grid(row=idx, column=0, sticky="w", padx=(0, 6), pady=1)
            bar = ttk.Progressbar(frame, mode="determinate", maximum=255, value=value)
            bar.grid(row=idx, column=1, sticky="ew", padx=(0, 6), pady=1)
            ttk.Label(frame, text=str(value), width=4).grid(row=idx, column=2, sticky="e", pady=1)
        ttk.Label(frame, text=f"BST: {total}", font=("", 9, "bold")).grid(
            row=len(row_list), column=0, columnspan=3, sticky="w", pady=(6, 0)
        )
        self._dex_detail_sections.append(frame)

    @staticmethod
    def _value_to_text(value: Any) -> str:
        if isinstance(value, dict):
            label = str(value.get("label", "")).strip()
            if label:
                return label
        if isinstance(value, (list, tuple, set)):
            return ", ".join(str(v) for v in value if str(v).strip())
        return str(value)

    @staticmethod
    def _sanitize_lookup_token(text: str) -> str:
        return re.sub(r"[^a-z0-9]+", "", str(text or "").casefold())

    def _known_type_ids(self) -> list[str]:
        known: set[str] = {str(t).strip().upper() for t in TYPE_COLOR_HEX.keys()}
        if self.catalogs:
            known.update(str(t).strip().upper() for t in self.catalogs.type_names_by_id.keys())
        return sorted((t for t in known if t), key=str.casefold)

    def _normalize_type_id(self, raw: Any) -> str:
        text = str(raw or "").strip()
        if not text:
            return ""
        text = text.lstrip(":").strip()
        if not text:
            return ""
        known = self._known_type_ids()
        upper = text.upper().replace("-", "_").replace(" ", "_")
        if upper in known:
            return upper

        needle = self._sanitize_lookup_token(text)
        if not needle:
            return ""
        for tid in known:
            if needle == self._sanitize_lookup_token(self._prettify_internal_id(tid)):
                return tid
            if self.catalogs:
                display = self.catalogs.type_names_by_id.get(tid, "")
                if display and needle == self._sanitize_lookup_token(display):
                    return tid
        return ""

    def _extract_type_ids(self, value: Any) -> list[str]:
        out: list[str] = []
        if isinstance(value, (list, tuple, set)):
            for item in value:
                for tid in self._extract_type_ids(item):
                    if tid not in out:
                        out.append(tid)
            return out

        raw = str(value or "").strip()
        if not raw:
            return out
        parts = [p.strip() for p in re.split(r"[\\/,|]", raw) if p.strip()]
        if not parts:
            parts = [raw]
        for part in parts:
            tid = self._normalize_type_id(part)
            if tid and tid not in out:
                out.append(tid)
        return out

    def _is_pure_type_value(self, value: Any) -> bool:
        if isinstance(value, (list, tuple, set)):
            values = [str(v).strip() for v in value if str(v).strip()]
            if not values:
                return False
            return all(bool(self._normalize_type_id(v)) for v in values)
        raw = str(value or "").strip()
        if not raw:
            return False
        parts = [p.strip() for p in re.split(r"[\\/,|]", raw) if p.strip()]
        if not parts:
            return False
        return all(bool(self._normalize_type_id(p)) for p in parts)

    @staticmethod
    def _is_type_field_label(label: str) -> bool:
        key = re.sub(r"[^a-z0-9]+", " ", str(label or "").casefold()).strip()
        if not key:
            return False
        if key in {"type", "types", "hidden power type", "primary type", "secondary type"}:
            return True
        return key.endswith(" type") or key.startswith("type ")

    def _render_type_chip_row(
        self,
        parent,
        type_ids: list[str],
        *,
        short: bool = False,
        empty_text: str = "(none)",
        max_per_row: int = 4,
        clear_existing: bool = True,
        chip_width: int | None = None,
    ):
        if clear_existing:
            for child in parent.winfo_children():
                child.destroy()
        values = [str(t).strip().upper() for t in type_ids if str(t).strip()]
        if not values:
            ttk.Label(parent, text=empty_text).grid(row=0, column=0, sticky="w")
            return
        chunks = self._dex_chunk_list(values, size=max(1, max_per_row))
        for r, chunk in enumerate(chunks):
            for c, tid in enumerate(chunk):
                chip = self._dex_make_type_chip(parent, tid, short=short, chip_width=chip_width)
                chip.grid(row=r, column=c, sticky="w", padx=2, pady=1)

    def _render_value_or_type_chips(
        self,
        parent,
        field_label: str,
        raw_value: Any,
        *,
        row: int,
        column: int,
        wraplength: int,
        short: bool = False,
        max_per_row: int = 4,
        padx: tuple[int, int] = (0, 0),
        pady: int | tuple[int, int] = 1,
    ):
        text_value = self._value_to_text(raw_value).strip()
        if self._is_type_field_label(field_label):
            type_ids = self._extract_type_ids(raw_value)
        else:
            fallback_ids = self._extract_type_ids(raw_value)
            type_ids = fallback_ids if fallback_ids and self._is_pure_type_value(raw_value) else []
        if type_ids:
            holder = ttk.Frame(parent)
            holder.grid(row=row, column=column, sticky="nw", padx=padx, pady=pady)
            self._render_type_chip_row(
                holder,
                type_ids,
                short=short,
                empty_text=text_value or "-",
                max_per_row=max_per_row,
                clear_existing=False,
            )
        else:
            ttk.Label(parent, text=text_value, wraplength=wraplength, justify="left").grid(
                row=row, column=column, sticky="nw", padx=padx, pady=pady
            )

    def _dex_type_chip_colors(self, type_id: str) -> tuple[str, str]:
        tid = str(type_id or "").strip().upper()
        bg = TYPE_COLOR_HEX.get(tid, "#6d7781")
        fg = "#1b1b1b" if tid in TYPE_LIGHT_BG_IDS else "#ffffff"
        return bg, fg

    def _dex_type_chip_label(self, type_id: str, short: bool = False) -> str:
        tid = str(type_id or "").strip().upper()
        if short:
            return TYPE_SHORT_LABELS.get(tid, self._prettify_internal_id(tid)[:3].upper())
        return self._prettify_internal_id(tid)

    def _dex_make_type_chip(self, parent, type_id: str, short: bool = False, chip_width: int | None = None):
        bg, fg = self._dex_type_chip_colors(type_id)
        text = self._dex_type_chip_label(type_id, short=short)
        width = chip_width if chip_width is not None else TYPE_CHIP_FIXED_WIDTH
        lbl = tk.Label(
            parent,
            text=text,
            bg=bg,
            fg=fg,
            padx=6,
            pady=2,
            bd=1,
            relief="solid",
            width=max(2, int(width)),
            anchor="center",
            font=("", 8, "bold"),
        )
        return lbl

    @staticmethod
    def _dex_chunk_list(values: list[str], size: int) -> list[list[str]]:
        if size <= 0:
            size = 1
        out: list[list[str]] = []
        for i in range(0, len(values), size):
            out.append(values[i : i + size])
        return out

    def _dex_add_type_matchups_section(
        self,
        title: str,
        defenses: Any,
        attacks: Any,
        defense_title: str = "Type Defenses",
        attack_title: str = "Type Attacks",
    ):
        frame = ttk.LabelFrame(self.dex_detail_body, text=title, padding=8)
        frame.pack(fill="x", expand=False, pady=(0, 8))
        frame.columnconfigure(0, weight=1)

        shell = ttk.Frame(frame)
        shell.grid(row=0, column=0, sticky="ew")
        shell.columnconfigure(0, weight=1)
        shell.columnconfigure(1, weight=1)

        left = ttk.LabelFrame(shell, text=defense_title, padding=6)
        right = ttk.LabelFrame(shell, text=attack_title, padding=6)
        left_body = ttk.Frame(left)
        left_body.pack(fill="x", expand=True)
        right_body = ttk.Frame(right)
        right_body.pack(fill="x", expand=True)

        defense_rows = defenses if isinstance(defenses, list) else []
        if not defense_rows:
            ttk.Label(left_body, text="(none)").grid(row=0, column=0, sticky="w")
        else:
            defense_groups: dict[float, list[str]] = {}
            for row in defense_rows:
                if not isinstance(row, (list, tuple)) or len(row) < 2:
                    continue
                type_id = str(row[0]).strip().upper()
                mult_value = self._dex_parse_multiplier_value(row[1])
                if not type_id or mult_value is None:
                    continue
                defense_groups.setdefault(round(mult_value, 4), []).append(type_id)

            if not defense_groups:
                ttk.Label(left_body, text="(none)").grid(row=0, column=0, sticky="w")
            else:
                line = 0
                for mult_value in sorted(defense_groups.keys(), reverse=True):
                    bucket_label = self._dex_multiplier_bucket_label(mult_value)
                    ttk.Label(left_body, text=f"{bucket_label}:", font=("", 9, "bold")).grid(
                        row=line, column=0, sticky="nw", padx=(0, 6), pady=(2, 1)
                    )
                    chips_wrap = ttk.Frame(left_body)
                    chips_wrap.grid(row=line, column=1, sticky="w", pady=(1, 2))
                    value_ids = sorted(
                        {str(v).strip().upper() for v in defense_groups.get(mult_value, []) if str(v).strip()},
                        key=str.casefold,
                    )
                    if not value_ids:
                        ttk.Label(chips_wrap, text="(none)").grid(row=0, column=0, sticky="w")
                    else:
                        chunks = self._dex_chunk_list(value_ids, size=5)
                        for r, chunk in enumerate(chunks):
                            for c, item_type_id in enumerate(chunk):
                                chip = self._dex_make_type_chip(
                                    chips_wrap,
                                    item_type_id,
                                    short=True,
                                    chip_width=TYPE_CHIP_COMPACT_WIDTH,
                                )
                                chip.grid(row=r, column=c, sticky="w", padx=2, pady=2)
                    line += 1

        attack_rows = attacks if isinstance(attacks, list) else []
        if not attack_rows:
            ttk.Label(right_body, text="(none)").grid(row=0, column=0, sticky="w")
        else:
            line = 0
            for row in attack_rows:
                if not isinstance(row, (list, tuple)) or len(row) < 2:
                    continue
                bucket = str(row[0]).strip()
                values = row[1] if isinstance(row[1], list) else []
                ttk.Label(right_body, text=f"{bucket}:", font=("", 9, "bold")).grid(
                    row=line, column=0, sticky="nw", padx=(0, 6), pady=(2, 1)
                )
                chips_wrap = ttk.Frame(right_body)
                chips_wrap.grid(row=line, column=1, sticky="w", pady=(1, 2))
                value_ids = [str(v).strip().upper() for v in values if str(v).strip()]
                if not value_ids:
                    ttk.Label(chips_wrap, text="(none)").grid(row=0, column=0, sticky="w")
                else:
                    chunks = self._dex_chunk_list(value_ids, size=4)
                    for r, chunk in enumerate(chunks):
                        for c, type_id in enumerate(chunk):
                            chip = self._dex_make_type_chip(
                                chips_wrap,
                                type_id,
                                short=True,
                                chip_width=TYPE_CHIP_COMPACT_WIDTH,
                            )
                            chip.grid(row=r, column=c, sticky="w", padx=2, pady=2)
                line += 1

        def _layout(_event=None):
            try:
                width = int(shell.winfo_width())
            except Exception:
                width = 0
            stacked = width > 0 and width < 760
            try:
                left.grid_forget()
                right.grid_forget()
            except Exception:
                pass
            if stacked:
                left.grid(row=0, column=0, sticky="ew", pady=(0, 8))
                right.grid(row=1, column=0, sticky="ew")
                shell.columnconfigure(1, weight=0)
            else:
                left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
                right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
                shell.columnconfigure(1, weight=1)

        shell.bind("<Configure>", _layout, add="+")
        frame.after(10, _layout)
        self._dex_detail_sections.append(frame)

    def _on_dex_evo_canvas_mousewheel(self, canvas: tk.Canvas, event):
        result = self._scroll_canvas_mousewheel(canvas, event)
        if result == "break":
            return "break"
        return self._on_dex_detail_mousewheel(event)

    def _dex_add_evolution_chart_section(
        self,
        title: str,
        species_id: str,
        form: int,
        height_hint: Any = None,
        show_all_conditions: bool = False,
    ):
        frame = ttk.LabelFrame(self.dex_detail_body, text=title, padding=8)
        frame.pack(fill="both", expand=False, pady=(0, 8))
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)

        shell = ttk.Frame(frame)
        shell.grid(row=0, column=0, sticky="nsew")
        shell.columnconfigure(0, weight=1)
        shell.rowconfigure(0, weight=1)
        try:
            hinted = int(height_hint)
        except (TypeError, ValueError):
            hinted = 340
        chart_h = max(240, hinted)

        canvas = tk.Canvas(shell, height=chart_h, borderwidth=0, highlightthickness=0, background="#fbfbfb")
        canvas.grid(row=0, column=0, sticky="nsew")
        vscroll = ttk.Scrollbar(shell, orient="vertical", command=canvas.yview)
        vscroll.grid(row=0, column=1, sticky="ns")
        canvas.configure(yscrollcommand=vscroll.set)

        canvas.bind("<MouseWheel>", lambda e, c=canvas: self._on_dex_evo_canvas_mousewheel(c, e), add="+")
        canvas.bind("<Button-4>", lambda e, c=canvas: self._on_dex_evo_canvas_mousewheel(c, e), add="+")
        canvas.bind("<Button-5>", lambda e, c=canvas: self._on_dex_evo_canvas_mousewheel(c, e), add="+")

        def _redraw(_event=None, c=canvas, sid=species_id, sid_form=form, show_all=show_all_conditions):
            self._render_evolution_chart_to_canvas(
                c,
                sid,
                sid_form,
                no_species_text="No evolution chain data.",
                invalid_species_text="No evolution chain data.",
                show_all_conditions=show_all,
            )

        canvas.bind("<Configure>", _redraw, add="+")
        try:
            frame.after(10, _redraw)
        except Exception:
            _redraw()

        self._dex_detail_sections.append(frame)

    def _dex_species_payload(self, species_id: str) -> dict[str, Any]:
        assert self.catalogs is not None
        canonical = self.catalogs.canonical_species_id(species_id) or species_id
        form = self._clamp_int(self.dex_form_var.get(), 0, 999, 0)
        self.dex_form_var.set(str(form))
        profile = self.catalogs.get_species_form_profile(canonical, form=form)
        if not profile:
            return {
                "title": "Pokédex",
                "subtitle": f"No profile found for form {form}.",
                "hero": [("Requested ID", canonical), ("Form", str(form))],
                "sections": [
                    {
                        "kind": "text",
                        "title": "Status",
                        "text": f"No species profile found for form {form}.",
                    }
                ],
            }

        item = self.catalogs.species_by_id.get(profile.internal_id) or self.catalogs.species_by_id.get(profile.species_id)
        display_name = self._dex_display_name_for_entry("Species", profile.species_id)
        base = self.catalogs.base_stats_for_species(profile.species_id, form=profile.form)
        bst = sum(int(base.get(k, 0)) for k in ("HP", "ATTACK", "DEFENSE", "SPECIAL_ATTACK", "SPECIAL_DEFENSE", "SPEED"))
        growth = self.catalogs.growth_rate_for_species(profile.species_id, form=profile.form)
        type_ids = self._dex_species_type_ids(profile.species_id, profile.form, profile=profile)
        type_labels = [self._prettify_internal_id(tid) for tid in type_ids]

        ability_ids, hidden_ids = self.catalogs.valid_abilities_for_species(profile.species_id, form=profile.form)
        ability_labels = []
        ability_entries: list[dict[str, str]] = []
        for aid in ability_ids:
            label = self._english_ability_name_for_id(aid)
            if aid in hidden_ids:
                label = f"{label} (H)"
            ability_labels.append(label)
            ability_entries.append({"kind": "ability", "id": aid, "label": label})

        valid_moves = self.catalogs.valid_moves_for_species(profile.species_id, form=profile.form, include_pre_evolutions=True)
        relearn_moves = self.catalogs.valid_relearn_moves_for_species(
            profile.species_id,
            form=profile.form,
            include_pre_evolutions=True,
        )
        level_pairs = sorted(profile.level_up_pairs, key=lambda row: (row[0], row[1].casefold()))
        level_rows: list[tuple[Any, Any, Any, Any, Any, Any]] = []
        evolution_rows: list[tuple[Any, Any, Any, Any, Any]] = []
        for lvl, raw_mid in level_pairs:
            mid = self.catalogs.canonical_move_id(raw_mid) or raw_mid
            move_name, move_type, category, power, acc = self._dex_move_detail_cells(mid)
            move_entry = {"kind": "move", "id": mid, "label": move_name}
            if lvl <= 0:
                evolution_rows.append((move_entry, move_type, category, power, acc))
            else:
                level_rows.append((str(lvl), move_entry, move_type, category, power, acc))

        tm_rows = self._dex_tm_rows_for_species(valid_moves)
        tutor_rows = self._dex_move_rows_for_ids(profile.tutor_moves)
        egg_rows = self._dex_move_rows_for_ids(profile.egg_moves)
        relearn_rows = self._dex_move_rows_for_ids(relearn_moves)

        forms = sorted({pf.form for (_sid, _form), pf in self.catalogs.species_form_profiles.items() if pf.species_id == profile.species_id})
        defense_rows = self._dex_type_defense_rows(type_ids)
        offense_rows = self._dex_type_offense_rows(type_ids)
        spawn_rows = self._dex_spawn_rows_for_species(profile.species_id)

        dex_text_raw = str(item.extra.get("Pokedex", "")).strip() if item else ""
        dex_text = self._english_description(dex_text_raw, "") or dex_text_raw or "No Pokédex description available."
        form_text = f"{profile.form}" + (f" ({profile.form_name})" if profile.form_name else "")
        hero_rows = [
            ("Category", "Pokédex"),
            ("Form", form_text),
            ("Internal ID", profile.species_id),
            ("Type", " / ".join(type_labels) if type_labels else "Unknown"),
        ]
        move_blocks: list[dict[str, Any]] = [
            {
                "title": "Moves learnt by level up",
                "column": 0,
                "order": 0,
                "columns": ["Lv", "Move", "Type", "Cat", "Power", "Acc"],
                "rows": level_rows,
            },
            {
                "title": "Moves learnt on evolution",
                "column": 0,
                "order": 1,
                "columns": ["Move", "Type", "Cat", "Power", "Acc"],
                "rows": evolution_rows,
            },
            {
                "title": "Moves learnt by reminder",
                "column": 0,
                "order": 2,
                "columns": ["Move", "Type", "Cat", "Power", "Acc"],
                "rows": relearn_rows,
            },
            {
                "title": "Egg moves",
                "column": 0,
                "order": 3,
                "columns": ["Move", "Type", "Cat", "Power", "Acc"],
                "rows": egg_rows,
            },
            {
                "title": "Moves learnt by TM/HM",
                "column": 1,
                "order": 0,
                "columns": ["TM", "Move", "Type", "Cat", "Power", "Acc"],
                "rows": tm_rows,
            },
            {
                "title": "Tutor moves",
                "column": 1,
                "order": 1,
                "columns": ["Move", "Type", "Cat", "Power", "Acc"],
                "rows": tutor_rows,
            },
        ]
        sections: list[dict[str, Any]] = [
            {
                "kind": "kv",
                "title": "Pokédex data",
                "rows": [
                    ("Name", display_name),
                    ("Growth Rate", growth),
                    ("Abilities", ability_entries if ability_entries else self._dex_join_list(ability_labels, limit=12)),
                    ("Available Forms", ", ".join(str(v) for v in forms) if forms else "0"),
                    ("Legal Moves (incl. pre-evo)", str(len(valid_moves))),
                    ("Relearn Moves (incl. pre-evo)", str(len(relearn_moves))),
                ],
            },
            {
                "kind": "stats",
                "title": "Base stats",
                "rows": [
                    ("HP", base.get("HP", 0)),
                    ("Atk", base.get("ATTACK", 0)),
                    ("Def", base.get("DEFENSE", 0)),
                    ("SpA", base.get("SPECIAL_ATTACK", 0)),
                    ("SpD", base.get("SPECIAL_DEFENSE", 0)),
                    ("Spe", base.get("SPEED", 0)),
                ],
            },
            {
                "kind": "type_matchups",
                "title": "Type Matchups",
                "defense_title": "Type Defenses",
                "attack_title": "Type Attacks",
                "defenses": defense_rows,
                "attacks": offense_rows,
            },
            {
                "kind": "evolution_chart",
                "title": "Evolution chart",
                "species_id": profile.species_id,
                "form": profile.form,
                "height": 360,
                "show_all_conditions": True,
            },
            {"kind": "moves_grid", "title": "Move learnsets", "blocks": move_blocks},
            {
                "kind": "table",
                "title": "Where to find",
                "columns": ["Map", "Method", "Levels", "Rate"],
                "rows": spawn_rows,
            },
            {
                "kind": "text",
                "title": "Description",
                "text": dex_text,
            },
        ]
        return {
            "title": display_name,
            "subtitle": f"Pokédex - {self._prettify_internal_id(profile.species_id)} (BST {bst})",
            "image": {"species_id": profile.species_id, "form": profile.form, "shiny": False},
            "hero": hero_rows,
            "sections": sections,
        }

    def _dex_move_payload(self, move_id: str) -> dict[str, Any]:
        assert self.catalogs is not None
        canonical = self.catalogs.canonical_move_id(move_id) or move_id
        move = self.catalogs.moves_by_id.get(canonical)
        if not move:
            return {
                "title": "Moves dex",
                "subtitle": "No move data found.",
                "hero": [("Internal ID", canonical)],
                "sections": [{"kind": "text", "title": "Status", "text": "No move data found."}],
            }

        display_name = self._dex_display_name_for_entry("Moves", canonical)
        raw_desc = self.catalogs.move_description(canonical)
        summary = self._move_numeric_summary_lines(canonical, raw_desc, "")
        base_desc, summary = self._resolve_entity_description("move", canonical, raw_desc, summary)
        learners = self._dex_species_with_move(canonical)
        learner_labels = [self._dex_display_name_for_entry("Species", sid) for sid in learners]

        facts = [("Internal ID", canonical)]
        for key in ("Type", "Category", "Power", "Accuracy", "TotalPP", "Priority", "Target", "FunctionCode", "Flags"):
            value = str(move.extra.get(key, "")).strip()
            if value:
                if key == "Type":
                    value = self._prettify_internal_id(value.lstrip(":"))
                facts.append((key, value))
        tm_labels = self._dex_move_tm_labels(canonical)
        if tm_labels:
            facts.append(("TM No.", ", ".join(tm_labels)))
        facts.append(("Learner species", str(len(learner_labels))))

        notes = self._append_mechanics_block(base_desc, summary)
        sections = [
            {"kind": "kv", "title": "Move data", "rows": facts},
            {"kind": "text", "title": "Description", "text": notes},
            {
                "kind": "table",
                "title": "Species that can learn this move",
                "columns": ["Species"],
                "rows": [(label,) for label in learner_labels],
            },
        ]
        return {
            "title": display_name,
            "subtitle": "Moves dex",
            "hero": [("Category", "Moves dex"), ("Name", display_name)],
            "sections": sections,
        }

    def _dex_item_payload(self, item_id: str) -> dict[str, Any]:
        assert self.catalogs is not None
        canonical = self.catalogs.canonical_item_id(item_id) or item_id
        item = self.catalogs.items_by_id.get(canonical)
        if not item:
            return {
                "title": "Items dex",
                "subtitle": "No item data found.",
                "hero": [("Internal ID", canonical)],
                "sections": [{"kind": "text", "title": "Status", "text": "No item data found."}],
            }

        display_name = self._dex_display_name_for_entry("Items", canonical)
        raw_desc = self.catalogs.item_description(canonical)
        summary = self._item_numeric_summary_lines(canonical, raw_desc, "")
        base_desc, summary = self._resolve_entity_description("item", canonical, raw_desc, summary)

        facts = [("Internal ID", canonical)]
        pocket_raw = str(item.extra.get("Pocket", "")).strip()
        if pocket_raw:
            try:
                pidx = int(pocket_raw)
                pocket_text = EN_POCKET_NAMES.get(pidx, f"Pocket {pidx}")
            except ValueError:
                pocket_text = pocket_raw
            facts.append(("Pocket", pocket_text))
        for key in ("Price", "FieldUse", "BattleUse", "Flags"):
            value = str(item.extra.get(key, "")).strip()
            if value:
                facts.append((key, value))

        rows: list[tuple[str, ...]] = []
        move_raw = str(item.extra.get("Move", "")).strip().lstrip(":")
        if move_raw:
            move_key = self.catalogs.canonical_move_id(move_raw) or move_raw
            rows.append((self._dex_display_name_for_entry("Moves", move_key),))

        shop_rows = self._dex_item_shop_rows(canonical)
        notes = self._append_mechanics_block(base_desc, summary)
        sections: list[dict[str, Any]] = [
            {"kind": "kv", "title": "Item data", "rows": facts},
            {"kind": "text", "title": "Description", "text": notes},
        ]
        if rows:
            sections.append(
                {
                    "kind": "table",
                    "title": "Associated move",
                    "columns": ["Move"],
                    "rows": rows,
                    "height": 1,
                }
            )
        if shop_rows:
            sections.append(
                {
                    "kind": "table",
                    "title": "Where to find",
                    "columns": ["Map", "Shop", "Currency"],
                    "rows": shop_rows,
                    "height": min(6, len(shop_rows)),
                }
            )
        return {
            "title": display_name,
            "subtitle": "Items dex",
            "hero": [("Category", "Items dex"), ("Name", display_name)],
            "image": {"item_id": canonical},
            "sections": sections,
        }

    def _dex_ability_payload(self, ability_id: str) -> dict[str, Any]:
        assert self.catalogs is not None
        canonical = self.catalogs.canonical_ability_id(ability_id) or ability_id
        ability = self.catalogs.abilities_by_id.get(canonical)
        if not ability:
            return {
                "title": "Abilities dex",
                "subtitle": "No ability data found.",
                "hero": [("Internal ID", canonical)],
                "sections": [{"kind": "text", "title": "Status", "text": "No ability data found."}],
            }

        display_name = self._english_ability_name_for_id(canonical)
        raw_desc = self.catalogs.ability_description(canonical)
        summary = self._ability_numeric_summary_lines(canonical, raw_desc, "")
        base_desc, summary = self._resolve_entity_description("ability", canonical, raw_desc, summary)
        normal_species, hidden_species = self._dex_species_with_ability(canonical)
        normal_labels = [self._dex_display_name_for_entry("Species", sid) for sid in normal_species]
        hidden_labels = [self._dex_display_name_for_entry("Species", sid) for sid in hidden_species]

        facts = [
            ("Internal ID", canonical),
            ("Normal-slot species", str(len(normal_labels))),
            ("Hidden-slot species", str(len(hidden_labels))),
        ]
        notes = self._append_mechanics_block(base_desc, summary)
        rows = [("Normal", name) for name in normal_labels] + [("Hidden", name) for name in hidden_labels]
        return {
            "title": display_name,
            "subtitle": "Abilities dex",
            "hero": [("Category", "Abilities dex"), ("Name", display_name)],
            "sections": [
                {"kind": "kv", "title": "Ability data", "rows": facts},
                {"kind": "text", "title": "Description", "text": notes},
                {
                    "kind": "table",
                    "title": "Species with this ability",
                    "columns": ["Slot", "Species"],
                    "rows": rows,
                },
            ],
        }

    def _dex_nature_payload(self, nature_id: str) -> dict[str, Any]:
        nature = str(nature_id or "").strip().upper()
        if not nature:
            return {
                "title": "Natures dex",
                "subtitle": "No nature selected.",
                "hero": [],
                "sections": [{"kind": "text", "title": "Status", "text": "No nature selected."}],
            }
        up, down = NATURE_EFFECTS.get(nature, (None, None))
        rows = [("Nature", self._title_case_words(nature)), ("Internal ID", nature)]
        if not up or not down:
            rows.extend(
                [
                    ("Boosted Stat", "None"),
                    ("Lowered Stat", "None"),
                    ("Stat Multipliers", "All non-HP stats remain x1.0"),
                ]
            )
        else:
            rows.extend(
                [
                    ("Boosted Stat", f"{STAT_SHORT_LABELS.get(up, up)} (x1.1)"),
                    ("Lowered Stat", f"{STAT_SHORT_LABELS.get(down, down)} (x0.9)"),
                    ("Other Non-HP Stats", "x1.0"),
                ]
            )
        return {
            "title": self._title_case_words(nature),
            "subtitle": "Natures dex",
            "hero": [("Category", "Natures dex"), ("Name", self._title_case_words(nature))],
            "sections": [
                {"kind": "kv", "title": "Nature data", "rows": rows},
                {"kind": "text", "title": "Description", "text": self._nature_description(nature)},
            ],
        }

    def _dex_type_payload(self, type_id: str) -> dict[str, Any]:
        assert self.catalogs is not None
        tid = str(type_id or "").strip().upper()
        if not tid:
            return {
                "title": "Types dex",
                "subtitle": "No type selected.",
                "hero": [],
                "sections": [{"kind": "text", "title": "Status", "text": "No type selected."}],
            }

        display = self._prettify_internal_id(tid)
        move_ids = [
            mid
            for mid, item in self.catalogs.moves_by_id.items()
            if str(item.extra.get("Type", "")).strip().lstrip(":").upper() == tid
        ]
        move_ids.sort(key=str.casefold)
        move_labels = [self._dex_display_name_for_entry("Moves", mid) for mid in move_ids]
        species_ids = self._dex_species_with_type(tid)
        species_labels = [self._dex_display_name_for_entry("Species", sid) for sid in species_ids]
        defense_rows = self._dex_type_defense_rows([tid])
        offense_rows = self._dex_type_offense_rows([tid])

        detail_rows = [("Internal ID", tid), ("Moves Count", str(len(move_labels))), ("Species Count", str(len(species_labels)))]
        if tid in self.catalogs.hidden_power_type_ids:
            idx = self.catalogs.hidden_power_type_ids.index(tid)
            detail_rows.append(("Hidden Power Index", f"{idx + 1}/{len(self.catalogs.hidden_power_type_ids)}"))

        return {
            "title": display,
            "subtitle": "Types dex",
            "hero": [("Category", "Types dex"), ("Name", display)],
            "sections": [
                {"kind": "kv", "title": "Type data", "rows": detail_rows},
                {
                    "kind": "type_matchups",
                    "title": "Type Matchups",
                    "defense_title": "Type Defenses",
                    "attack_title": "Type Attacks",
                    "defenses": defense_rows,
                    "attacks": offense_rows,
                },
                {"kind": "table", "title": "Moves of this type", "columns": ["Move"], "rows": [(x,) for x in move_labels]},
                {
                    "kind": "table",
                    "title": "Species with this type",
                    "columns": ["Species"],
                    "rows": [(x,) for x in species_labels],
                },
            ],
        }

    def _dex_load_type_chart_data(self) -> tuple[dict[str, dict[str, float]], list[str]]:
        if self._dex_type_chart_defense is not None:
            return self._dex_type_chart_defense, list(self._dex_type_order)

        valid_types = {str(t).strip().upper() for t in (self.catalogs.type_names_by_id.keys() if self.catalogs else [])}
        sections = parse_pbs_sections(HERE.parent / "PBS" / "types.txt")
        defense_map: dict[str, dict[str, float]] = {}

        for raw_id, data in sections.items():
            tid = str(raw_id or "").strip().upper()
            if not tid:
                continue
            is_pseudo = str(data.get("IsPseudoType", data.get("PseudoType", ""))).strip().lower() in {"true", "1", "yes"}
            if is_pseudo:
                continue
            if valid_types and tid not in valid_types:
                continue
            defense_map.setdefault(tid, {})

        if not defense_map:
            for tid in sorted(valid_types, key=str.casefold):
                defense_map.setdefault(tid, {})

        all_types = sorted(defense_map.keys(), key=str.casefold)
        if self.catalogs and self.catalogs.hidden_power_type_ids:
            ordered = [tid for tid in self.catalogs.hidden_power_type_ids if tid in defense_map]
            ordered.extend([tid for tid in all_types if tid not in ordered])
            all_types = ordered

        for def_tid in all_types:
            defense_map[def_tid] = {atk_tid: 1.0 for atk_tid in all_types}

        def _parse_type_list(raw: str) -> list[str]:
            out: list[str] = []
            for chunk in str(raw or "").split(","):
                tid = chunk.strip().lstrip(":").upper()
                if tid and tid in defense_map:
                    out.append(tid)
            return out

        for raw_id, data in sections.items():
            def_tid = str(raw_id or "").strip().upper()
            if def_tid not in defense_map:
                continue
            for atk_tid in _parse_type_list(data.get("Weaknesses", "")):
                defense_map[def_tid][atk_tid] = 2.0
            for atk_tid in _parse_type_list(data.get("Resistances", "")):
                defense_map[def_tid][atk_tid] = 0.5
            for atk_tid in _parse_type_list(data.get("Immunities", "")):
                defense_map[def_tid][atk_tid] = 0.0

        self._dex_type_chart_defense = defense_map
        self._dex_type_order = all_types
        return defense_map, list(all_types)

    @staticmethod
    def _dex_multiplier_label(multiplier: float) -> str:
        value = float(multiplier)
        if abs(value) < 1e-9:
            return "0x"
        rounded = round(value, 4)
        if rounded.is_integer():
            return f"{int(rounded)}x"
        return f"{rounded:g}x"

    @staticmethod
    def _dex_parse_multiplier_value(raw: Any) -> float | None:
        text = str(raw or "").strip().lower().replace(" ", "")
        if not text:
            return None
        if text.startswith("x"):
            text = text[1:]
        if text.endswith("x"):
            text = text[:-1]
        if not text:
            return None
        if "/" in text:
            left, right = text.split("/", 1)
            try:
                num = float(left)
                den = float(right)
            except Exception:
                return None
            if abs(den) < 1e-9:
                return None
            return num / den
        try:
            return float(text)
        except Exception:
            return None

    @staticmethod
    def _dex_multiplier_bucket_label(value: float) -> str:
        rounded = round(float(value), 4)
        if abs(rounded) < 1e-9:
            return "x0"
        if rounded >= 1.0:
            if rounded.is_integer():
                return f"x{int(rounded)}"
            return f"x{rounded:g}"
        reciprocal = round(1.0 / rounded) if abs(rounded) > 1e-9 else 0
        if reciprocal > 0 and abs(rounded - (1.0 / reciprocal)) <= 1e-4:
            return f"x1/{reciprocal}"
        return f"x{rounded:g}"

    def _dex_species_type_ids(
        self,
        species_id: str,
        form: int = 0,
        profile: Any | None = None,
    ) -> list[str]:
        if not self.catalogs:
            return []
        pf = profile if profile is not None else self.catalogs.get_species_form_profile(species_id, form=form)
        candidates: list[str] = []
        if pf is not None:
            if pf.internal_id:
                candidates.append(pf.internal_id)
            if pf.species_id and pf.species_id not in candidates:
                candidates.append(pf.species_id)
        canonical = self.catalogs.canonical_species_id(species_id)
        if canonical and canonical not in candidates:
            candidates.append(canonical)

        type_ids: list[str] = []
        for sid in candidates:
            item = self.catalogs.species_by_id.get(sid)
            if not item:
                continue
            raw_types = str(item.extra.get("Types", item.extra.get("Type", ""))).strip()
            if not raw_types:
                continue
            for chunk in raw_types.split(","):
                tid = chunk.strip().lstrip(":").upper()
                if tid and tid not in type_ids:
                    type_ids.append(tid)
            if type_ids:
                break
        return type_ids

    def _dex_type_defense_rows(self, type_ids: list[str]) -> list[tuple[str, str]]:
        defense_map, type_order = self._dex_load_type_chart_data()
        if not type_ids or not type_order:
            return []
        rows: list[tuple[str, str, float]] = []
        for atk_tid in type_order:
            mult = 1.0
            for def_tid in type_ids:
                mult *= float(defense_map.get(def_tid, {}).get(atk_tid, 1.0))
            rows.append((atk_tid, self._dex_multiplier_label(mult), mult))
        rows.sort(key=lambda row: (-row[2], row[0].casefold()))
        return [(tid, label) for tid, label, _mult in rows]

    def _dex_type_offense_rows(self, attack_type_ids: list[str]) -> list[tuple[str, list[str]]]:
        defense_map, type_order = self._dex_load_type_chart_data()
        if not attack_type_ids or not type_order:
            return [
                ("2x", []),
                ("1/2x", []),
                ("0x", []),
            ]
        strong: list[str] = []
        resisted: list[str] = []
        immune: list[str] = []
        for def_tid in type_order:
            best = 0.0
            for atk_tid in attack_type_ids:
                best = max(best, float(defense_map.get(def_tid, {}).get(atk_tid, 1.0)))
            if best <= 0.0:
                immune.append(def_tid)
            elif best > 1.0:
                strong.append(def_tid)
            elif best < 1.0:
                resisted.append(def_tid)
        strong.sort(key=str.casefold)
        resisted.sort(key=str.casefold)
        immune.sort(key=str.casefold)
        return [
            ("2x", strong),
            ("1/2x", resisted),
            ("0x", immune),
        ]

    def _dex_load_spawn_index(self):
        if self._dex_spawn_index is not None:
            return
        self._dex_spawn_index = {}
        self._dex_map_names = {}
        if not self.catalogs:
            return

        map_sections = parse_pbs_sections(HERE.parent / "PBS" / "map_metadata.txt")
        for raw_id, data in map_sections.items():
            try:
                map_id = int(str(raw_id).strip())
            except (TypeError, ValueError):
                continue
            name = str(data.get("Name", "")).strip()
            if name:
                self._dex_map_names[map_id] = name

        encounters_path = HERE.parent / "PBS" / "encounters.txt"
        if not encounters_path.exists():
            return

        current_map_id: int | None = None
        current_map_hint = ""
        current_method = ""
        for raw in encounters_path.read_text(encoding="utf-8", errors="replace").splitlines():
            stripped = raw.strip()
            if not stripped:
                continue
            if stripped.startswith("#"):
                continue
            m = re.match(r"^\[(\d+)\](?:\s*#\s*(.*))?$", stripped)
            if m:
                try:
                    current_map_id = int(m.group(1))
                except ValueError:
                    current_map_id = None
                current_map_hint = str(m.group(2) or "").strip()
                current_method = ""
                continue
            if current_map_id is None:
                continue

            if raw[:1].isspace():
                if not current_method:
                    continue
                parts = [chunk.strip() for chunk in stripped.split(",")]
                if len(parts) < 4:
                    continue
                method_key = current_method.strip()
                if method_key.upper().endswith("CLASSIC"):
                    continue
                species_raw = parts[1].lstrip(":").strip()
                canonical_species = self.catalogs.canonical_species_id(species_raw) or species_raw.upper()
                if not canonical_species:
                    continue
                try:
                    min_level = int(parts[2])
                    max_level = int(parts[3])
                except (TypeError, ValueError):
                    continue
                try:
                    weight = int(parts[0])
                except (TypeError, ValueError):
                    weight = 0
                map_name = self._dex_map_names.get(current_map_id, "")
                if not map_name:
                    map_name = current_map_hint or f"Map {current_map_id:03d}"
                self._dex_spawn_index.setdefault(canonical_species, []).append(
                    {
                        "map_id": current_map_id,
                        "map_name": map_name,
                        "method": method_key,
                        "min_level": min_level,
                        "max_level": max_level,
                        "weight": weight,
                    }
                )
                continue

            current_method = stripped.split(",", 1)[0].strip()

    def _dex_spawn_rows_for_species(self, species_id: str) -> list[tuple[str, str, str, str]]:
        if not self.catalogs:
            return []
        self._dex_load_spawn_index()
        if self._dex_spawn_index is None:
            return []
        canonical = self.catalogs.canonical_species_id(species_id) or str(species_id or "").strip().lstrip(":").upper()
        entries = self._dex_spawn_index.get(canonical, [])
        if not entries:
            return []

        grouped: dict[tuple[int, str], dict[str, Any]] = {}
        for row in entries:
            map_id = int(row.get("map_id", 0))
            method = str(row.get("method", "")).strip()
            key = (map_id, method)
            current = grouped.get(key)
            if current is None:
                grouped[key] = dict(row)
                continue
            current["min_level"] = min(int(current.get("min_level", 0)), int(row.get("min_level", 0)))
            current["max_level"] = max(int(current.get("max_level", 0)), int(row.get("max_level", 0)))
            current["weight"] = int(current.get("weight", 0)) + int(row.get("weight", 0))

        rows: list[tuple[str, str, str, str]] = []
        for (_map_id, _method), row in sorted(grouped.items(), key=lambda kv: (kv[0][0], kv[0][1].casefold())):
            map_id = int(row.get("map_id", 0))
            map_name = str(row.get("map_name", "")).strip() or f"Map {map_id:03d}"
            map_label = f"{map_name} [{map_id:03d}]"
            method = str(row.get("method", "")).strip() or "Unknown"
            min_level = int(row.get("min_level", 0))
            max_level = int(row.get("max_level", 0))
            level_range = str(min_level) if min_level == max_level else f"{min_level}-{max_level}"
            rate = int(row.get("weight", 0))
            rate_label = f"{rate}%"
            rows.append((map_label, method, level_range, rate_label))
        return rows

    @staticmethod
    def _dex_script_param_text(value: Any) -> str:
        if isinstance(value, core.RubyString):
            return str(value)
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeDecodeError:
                return value.decode("latin-1", errors="replace")
        if isinstance(value, str):
            return value
        return ""

    def _dex_extract_event_scripts(self, map_obj: Any) -> list[str]:
        if not isinstance(map_obj, core.RubyObject):
            return []
        events = core.read_attr(map_obj, "@events", {})
        if not isinstance(events, dict):
            return []
        scripts: list[str] = []
        for event in events.values():
            if not isinstance(event, core.RubyObject):
                continue
            pages = core.read_attr(event, "@pages", [])
            if not isinstance(pages, list):
                continue
            for page in pages:
                if not isinstance(page, core.RubyObject):
                    continue
                commands = core.read_attr(page, "@list", [])
                if not isinstance(commands, list):
                    continue
                idx = 0
                while idx < len(commands):
                    cmd = commands[idx]
                    if not isinstance(cmd, core.RubyObject):
                        idx += 1
                        continue
                    code = core.read_attr(cmd, "@code", None)
                    if code != 355:
                        idx += 1
                        continue
                    lines: list[str] = []
                    params = core.read_attr(cmd, "@parameters", [])
                    if isinstance(params, list) and params:
                        text = self._dex_script_param_text(params[0]).strip()
                        if text:
                            lines.append(text)
                    j = idx + 1
                    while j < len(commands):
                        nxt = commands[j]
                        if not isinstance(nxt, core.RubyObject):
                            break
                        ncode = core.read_attr(nxt, "@code", None)
                        if ncode != 655:
                            break
                        nparams = core.read_attr(nxt, "@parameters", [])
                        if isinstance(nparams, list) and nparams:
                            text = self._dex_script_param_text(nparams[0]).strip()
                            if text:
                                lines.append(text)
                        j += 1
                    if lines:
                        scripts.append("\n".join(lines))
                    idx = j
        return scripts

    def _dex_load_item_shop_index(self):
        if self._dex_item_shop_index is not None:
            return
        self._dex_item_shop_index = {}
        if not self.catalogs:
            return

        if not self._dex_map_names:
            map_sections = parse_pbs_sections(HERE.parent / "PBS" / "map_metadata.txt")
            for raw_id, data in map_sections.items():
                try:
                    map_id = int(str(raw_id).strip())
                except (TypeError, ValueError):
                    continue
                name = str(data.get("Name", "")).strip()
                if name:
                    self._dex_map_names[map_id] = name

        data_dir = HERE.parent / "Data"
        for map_path in sorted(data_dir.glob("Map*.rxdata")):
            m = re.match(r"^Map(\d+)\.rxdata$", map_path.name, flags=re.IGNORECASE)
            if not m:
                continue
            try:
                map_id = int(m.group(1))
            except ValueError:
                continue
            try:
                raw = map_path.read_bytes()
            except Exception:
                continue
            has_poke_mart = b"pbPokemonMart" in raw
            has_bp_shop = b"pbBattlePointShop" in raw
            if not has_poke_mart and not has_bp_shop:
                continue

            try:
                map_obj = core.load_save(map_path)
            except Exception:
                continue
            scripts = self._dex_extract_event_scripts(map_obj)
            if not scripts:
                continue

            map_name = self._dex_map_names.get(map_id, f"Map {map_id:03d}")
            for script in scripts:
                if "pbPokemonMart" in script:
                    for blob in re.findall(r"pbPokemonMart\(\s*\[(.*?)\]\s*\)", script, flags=re.IGNORECASE | re.DOTALL):
                        for sym in re.findall(r":([A-Za-z0-9_]+)", blob):
                            canonical = self.catalogs.canonical_item_id(sym)
                            if not canonical:
                                continue
                            self._dex_item_shop_index.setdefault(canonical, []).append(
                                {
                                    "map_id": map_id,
                                    "map_name": map_name,
                                    "shop_type": "Poké Mart",
                                    "currency": "Money",
                                }
                            )
                if "pbBattlePointShop" in script:
                    for blob in re.findall(r"pbBattlePointShop\(\s*\[(.*?)\]\s*\)", script, flags=re.IGNORECASE | re.DOTALL):
                        for sym in re.findall(r":([A-Za-z0-9_]+)", blob):
                            canonical = self.catalogs.canonical_item_id(sym)
                            if not canonical:
                                continue
                            self._dex_item_shop_index.setdefault(canonical, []).append(
                                {
                                    "map_id": map_id,
                                    "map_name": map_name,
                                    "shop_type": "BP Shop",
                                    "currency": "BP",
                                }
                            )

    def _dex_item_shop_rows(self, item_id: str) -> list[tuple[str, str, str]]:
        if not self.catalogs:
            return []
        self._dex_load_item_shop_index()
        if self._dex_item_shop_index is None:
            return []
        canonical = self.catalogs.canonical_item_id(item_id) or str(item_id or "").strip().lstrip(":").upper()
        entries = self._dex_item_shop_index.get(canonical, [])
        if not entries:
            return []

        seen: set[tuple[int, str, str]] = set()
        rows: list[tuple[str, str, str]] = []
        for row in entries:
            map_id = int(row.get("map_id", 0))
            shop_type = str(row.get("shop_type", "")).strip() or "Shop"
            currency = str(row.get("currency", "")).strip() or "Money"
            key = (map_id, shop_type, currency)
            if key in seen:
                continue
            seen.add(key)
            map_name = str(row.get("map_name", "")).strip() or f"Map {map_id:03d}"
            map_label = f"{map_name} [{map_id:03d}]"
            rows.append((map_label, shop_type, currency))
        rows.sort(key=lambda r: (r[0].casefold(), r[1].casefold(), r[2].casefold()))
        return rows

    def _dex_species_details(self, species_id: str) -> str:
        assert self.catalogs is not None
        canonical = self.catalogs.canonical_species_id(species_id) or species_id
        form = self._clamp_int(self.dex_form_var.get(), 0, 999, 0)
        self.dex_form_var.set(str(form))
        profile = self.catalogs.get_species_form_profile(canonical, form=form)
        if not profile:
            return f"Species: {canonical}\n\nNo species profile found for form {form}."

        item = self.catalogs.species_by_id.get(profile.internal_id) or self.catalogs.species_by_id.get(profile.species_id)
        display_name = item.display_name if item else profile.internal_id
        english_name = self._prettify_internal_id(profile.species_id)
        lines = [
            f"Species: {profile.species_id} - {english_name}",
            f"Display name in data: {display_name}",
            f"Profile ID: {profile.internal_id}",
            f"Form: {profile.form}" + (f" ({profile.form_name})" if profile.form_name else ""),
        ]

        base = self.catalogs.base_stats_for_species(profile.species_id, form=profile.form)
        if base:
            bst = sum(int(base.get(k, 0)) for k in ("HP", "ATTACK", "DEFENSE", "SPECIAL_ATTACK", "SPECIAL_DEFENSE", "SPEED"))
            lines.append(
                "Base stats: "
                f"HP {base.get('HP', 0)} / Atk {base.get('ATTACK', 0)} / Def {base.get('DEFENSE', 0)} / "
                f"SpA {base.get('SPECIAL_ATTACK', 0)} / SpD {base.get('SPECIAL_DEFENSE', 0)} / Spe {base.get('SPEED', 0)}"
            )
            lines.append(f"Base stat total: {bst}")

        growth = self.catalogs.growth_rate_for_species(profile.species_id, form=profile.form)
        lines.append(f"Growth rate: {growth}")

        ability_ids, hidden_ids = self.catalogs.valid_abilities_for_species(profile.species_id, form=profile.form)
        ability_labels = []
        for aid in ability_ids:
            label = self._english_ability_name_for_id(aid)
            if aid in hidden_ids:
                label = f"{label} (H)"
            ability_labels.append(label)
        lines.append(f"Abilities: {self._dex_join_list(ability_labels, limit=12)}")

        forms = sorted(
            {pf.form for (_sid, _form), pf in self.catalogs.species_form_profiles.items() if pf.species_id == profile.species_id}
        )
        if forms:
            lines.append(f"Available forms: {', '.join(str(v) for v in forms)}")

        level_pairs = sorted(profile.level_up_pairs, key=lambda row: (row[0], row[1].casefold()))
        level_moves = [f"Lv{lvl} {self._prettify_internal_id(mid)}" for lvl, mid in level_pairs]
        lines.append(f"Level-up moves (this form): {self._dex_join_list(level_moves, limit=30)}")

        tutor_moves = [self._prettify_internal_id(mid) for mid in profile.tutor_moves]
        egg_moves = [self._prettify_internal_id(mid) for mid in profile.egg_moves]
        lines.append(f"Tutor moves (this form): {self._dex_join_list(tutor_moves, limit=30)}")
        lines.append(f"Egg moves (this form): {self._dex_join_list(egg_moves, limit=30)}")

        valid_moves = self.catalogs.valid_moves_for_species(profile.species_id, form=profile.form, include_pre_evolutions=True)
        relearn_moves = self.catalogs.valid_relearn_moves_for_species(profile.species_id, form=profile.form, include_pre_evolutions=True)
        direct_move_set = {
            self.catalogs.canonical_move_id(mid)
            for mid in (profile.level_up_moves + profile.tutor_moves + profile.egg_moves)
            if self.catalogs.canonical_move_id(mid)
        }
        inherited = [mid for mid in valid_moves if mid not in direct_move_set]
        inherited_names = [self._prettify_internal_id(mid) for mid in inherited]
        lines.append(f"Legal moves incl. pre-evolutions: {len(valid_moves)}")
        lines.append(f"Relearn moves incl. pre-evolutions: {len(relearn_moves)}")
        if inherited_names:
            lines.append(f"Inherited from pre-evolution chain: {self._dex_join_list(inherited_names, limit=30)}")

        evo_text = self._species_evolution_description(profile.species_id, profile.form)
        lines.append("")
        lines.append(evo_text)
        return "\n".join(lines)

    def _dex_species_with_move(self, move_id: str) -> list[str]:
        assert self.catalogs is not None
        canonical = self.catalogs.canonical_move_id(move_id) or move_id
        out: list[str] = []
        seen: set[str] = set()
        for (_sid, _form), profile in self.catalogs.species_form_profiles.items():
            pool = profile.level_up_moves + profile.tutor_moves + profile.egg_moves
            has_move = False
            for raw in pool:
                mid = self.catalogs.canonical_move_id(raw)
                if mid == canonical:
                    has_move = True
                    break
            if not has_move:
                continue
            sid = profile.species_id
            if sid in seen:
                continue
            seen.add(sid)
            out.append(sid)
        out.sort(key=str.casefold)
        return out

    def _dex_move_details(self, move_id: str) -> str:
        assert self.catalogs is not None
        canonical = self.catalogs.canonical_move_id(move_id) or move_id
        move = self.catalogs.moves_by_id.get(canonical)
        if not move:
            return f"Move: {canonical}\n\nNo move data found."
        english_name = self._prettify_internal_id(canonical)
        lines = [f"Move: {canonical} - {english_name}", f"Display name in data: {move.display_name or canonical}"]

        for key in ("Type", "Category", "Power", "Accuracy", "TotalPP", "Priority", "Target", "FunctionCode", "Flags"):
            value = str(move.extra.get(key, "")).strip()
            if value:
                lines.append(f"{key}: {value}")

        raw_desc = self.catalogs.move_description(canonical)
        summary = self._move_numeric_summary_lines(canonical, raw_desc, "")
        base_desc, summary = self._resolve_entity_description("move", canonical, raw_desc, summary)
        lines.append("")
        lines.append(base_desc or "No description available in current game data.")
        if summary:
            lines.append("")
            lines.append("Mechanics (Known):")
            lines.extend(f"- {line}" for line in summary)

        learners = self._dex_species_with_move(canonical)
        learner_labels = [self._prettify_internal_id(sid) for sid in learners]
        lines.append("")
        lines.append(f"Species that can learn this move (any source): {len(learner_labels)}")
        lines.append(self._dex_join_list(learner_labels, limit=45))
        return "\n".join(lines)

    def _dex_item_details(self, item_id: str) -> str:
        assert self.catalogs is not None
        canonical = self.catalogs.canonical_item_id(item_id) or item_id
        item = self.catalogs.items_by_id.get(canonical)
        if not item:
            return f"Item: {canonical}\n\nNo item data found."
        english_name = self._prettify_internal_id(canonical)
        lines = [f"Item: {canonical} - {english_name}", f"Display name in data: {item.display_name or canonical}"]

        pocket_raw = str(item.extra.get("Pocket", "")).strip()
        if pocket_raw:
            try:
                pidx = int(pocket_raw)
            except ValueError:
                pidx = -1
            if pidx >= 0:
                lines.append(f"Pocket: {pidx} - {EN_POCKET_NAMES.get(pidx, f'Pocket {pidx}')}")
            else:
                lines.append(f"Pocket: {pocket_raw}")
        for key in ("Price", "FieldUse", "BattleUse", "Flags"):
            value = str(item.extra.get(key, "")).strip()
            if value:
                lines.append(f"{key}: {value}")

        move_raw = str(item.extra.get("Move", "")).strip().lstrip(":")
        if move_raw:
            move_id = self.catalogs.canonical_move_id(move_raw) or move_raw
            lines.append(f"TM/HM Move: {move_id} - {self._prettify_internal_id(move_id)}")

        raw_desc = self.catalogs.item_description(canonical)
        summary = self._item_numeric_summary_lines(canonical, raw_desc, "")
        base_desc, summary = self._resolve_entity_description("item", canonical, raw_desc, summary)
        lines.append("")
        lines.append(base_desc or "No description available in current game data.")
        if summary:
            lines.append("")
            lines.append("Mechanics (Known):")
            lines.extend(f"- {line}" for line in summary)
        return "\n".join(lines)

    def _dex_species_with_ability(self, ability_id: str) -> tuple[list[str], list[str]]:
        assert self.catalogs is not None
        canonical = self.catalogs.canonical_ability_id(ability_id) or ability_id
        normal: set[str] = set()
        hidden: set[str] = set()
        for (_sid, _form), profile in self.catalogs.species_form_profiles.items():
            sid = profile.species_id
            for raw in profile.ability_ids:
                aid = self.catalogs.canonical_ability_id(raw)
                if aid == canonical:
                    normal.add(sid)
            for raw in profile.hidden_ability_ids:
                aid = self.catalogs.canonical_ability_id(raw)
                if aid == canonical:
                    hidden.add(sid)
        normal_only = sorted((sid for sid in normal if sid not in hidden), key=str.casefold)
        hidden_sorted = sorted(hidden, key=str.casefold)
        return normal_only, hidden_sorted

    def _dex_ability_details(self, ability_id: str) -> str:
        assert self.catalogs is not None
        canonical = self.catalogs.canonical_ability_id(ability_id) or ability_id
        ability = self.catalogs.abilities_by_id.get(canonical)
        if not ability:
            return f"Ability: {canonical}\n\nNo ability data found."
        english_name = self._english_ability_name_for_id(canonical)
        lines = [f"Ability: {canonical} - {english_name}", f"Display name in data: {ability.display_name or canonical}"]
        raw_desc = self.catalogs.ability_description(canonical)
        summary = self._ability_numeric_summary_lines(canonical, raw_desc, "")
        base_desc, summary = self._resolve_entity_description("ability", canonical, raw_desc, summary)
        lines.append("")
        lines.append(base_desc or "No description available in current game data.")
        if summary:
            lines.append("")
            lines.append("Mechanics (Known):")
            lines.extend(f"- {line}" for line in summary)

        normal_species, hidden_species = self._dex_species_with_ability(canonical)
        normal_labels = [self._prettify_internal_id(sid) for sid in normal_species]
        hidden_labels = [self._prettify_internal_id(sid) for sid in hidden_species]
        lines.append("")
        lines.append(f"Species with this ability (normal slots): {len(normal_labels)}")
        lines.append(self._dex_join_list(normal_labels, limit=45))
        lines.append(f"Species with this ability (hidden slot): {len(hidden_labels)}")
        lines.append(self._dex_join_list(hidden_labels, limit=45))
        return "\n".join(lines)

    def _dex_nature_details(self, nature_id: str) -> str:
        nature = str(nature_id or "").strip().upper()
        if not nature:
            return "No nature selected."
        up, down = NATURE_EFFECTS.get(nature, (None, None))
        lines = [f"Nature: {nature}"]
        if not up or not down:
            lines.append("Effect: Neutral nature.")
            lines.append("Multiplier: all non-HP stats stay at 1.0x.")
        else:
            lines.append(f"Boosted stat: {STAT_SHORT_LABELS.get(up, up)} (x1.1)")
            lines.append(f"Lowered stat: {STAT_SHORT_LABELS.get(down, down)} (x0.9)")
            lines.append("Other non-HP stats: x1.0")
        lines.append("")
        lines.append(self._nature_description(nature))
        return "\n".join(lines)

    def _dex_species_with_type(self, type_id: str) -> list[str]:
        assert self.catalogs is not None
        target = str(type_id or "").strip().upper()
        if not target:
            return []
        out: set[str] = set()
        for sid, item in self.catalogs.species_by_id.items():
            raw_types = str(item.extra.get("Types", item.extra.get("Type", ""))).strip()
            if not raw_types:
                continue
            parts = [chunk.strip().lstrip(":").upper() for chunk in raw_types.split(",") if chunk.strip()]
            if target in parts:
                canonical = self.catalogs.canonical_species_id(sid) or sid
                out.add(canonical)
        return sorted(out, key=str.casefold)

    def _dex_type_details(self, type_id: str) -> str:
        assert self.catalogs is not None
        tid = str(type_id or "").strip().upper()
        if not tid:
            return "No type selected."
        display = self.catalogs.type_names_by_id.get(tid, self._prettify_internal_id(tid))
        lines = [f"Type: {tid} - {self._prettify_internal_id(tid)}", f"Display name in data: {display}"]

        if tid in self.catalogs.hidden_power_type_ids:
            idx = self.catalogs.hidden_power_type_ids.index(tid)
            lines.append(f"Hidden Power index order: {idx + 1}/{len(self.catalogs.hidden_power_type_ids)}")

        move_ids = [
            mid
            for mid, item in self.catalogs.moves_by_id.items()
            if str(item.extra.get("Type", "")).strip().lstrip(":").upper() == tid
        ]
        move_ids.sort(key=str.casefold)
        move_labels = [self._prettify_internal_id(mid) for mid in move_ids]
        lines.append(f"Moves of this type: {len(move_labels)}")
        lines.append(self._dex_join_list(move_labels, limit=50))

        species_ids = self._dex_species_with_type(tid)
        species_labels = [self._prettify_internal_id(sid) for sid in species_ids]
        lines.append("")
        lines.append(f"Species listed with this type in catalog: {len(species_labels)}")
        lines.append(self._dex_join_list(species_labels, limit=50))
        return "\n".join(lines)

    @staticmethod
    def _add_labeled_entry(parent, label, variable, row, col, readonly=False, width=28):
        ttk.Label(parent, text=label).grid(row=row, column=col, sticky="w", padx=(0, 6), pady=4)
        entry = ttk.Entry(parent, textvariable=variable, width=width)
        try:
            parent.columnconfigure(col + 1, weight=1)
        except Exception:
            pass
        entry.grid(row=row, column=col + 1, sticky="ew", padx=(0, 16), pady=4)
        if readonly:
            entry.state(["readonly"])
        return entry

    def _register_description_widget(self, widget, panel: str, source: str, index: int | None = None):
        key = str(widget)
        self._desc_widget_context[key] = (panel, source, index)
        widget.bind(
            "<Enter>",
            lambda e, p=panel, s=source, i=index: self._on_description_hover(e, p, s, i),
            add="+",
        )
        widget.bind(
            "<FocusIn>",
            lambda e, p=panel, s=source, i=index: self._on_description_focus_in(e, p, s, i),
            add="+",
        )
        widget.bind(
            "<Button-1>",
            lambda e, p=panel, s=source, i=index: self._on_description_focus_in(e, p, s, i),
            add="+",
        )
        widget.bind("<FocusOut>", lambda _e, p=panel: self._on_description_focus_out(p), add="+")
        widget.bind(
            "<Leave>",
            lambda e, p=panel, s=source, i=index: self._on_description_leave(e, p, s, i),
            add="+",
        )

    def _sync_description_lock_from_clicked_widget(self, clicked):
        if clicked is None:
            self._desc_lock["party"] = None
            self._desc_lock["bag"] = None
            self._hide_party_tooltip()
            return
        clicked_name = str(clicked).lower()
        if "popdown" in clicked_name:
            return
        ctx = self._desc_widget_context.get(str(clicked))
        if ctx is None:
            self._desc_lock["party"] = None
            self._desc_lock["bag"] = None
            self._hide_party_tooltip()
            return
        panel, source, index = ctx
        self._desc_lock[panel] = (source, index)
        other = "bag" if panel == "party" else "party"
        self._desc_lock[other] = None
        if panel != "party":
            self._hide_party_tooltip()

    def _on_description_focus_in(self, event, panel: str, source: str, index: int | None = None):
        self._desc_lock[panel] = (source, index)
        if panel == "party":
            if not self._party_description_has_value(source, index):
                self._hide_party_tooltip()
                return
            text = self.update_party_description(source, index, force=True)
            self._show_party_tooltip(text, event=event, widget=getattr(event, "widget", None))
        elif panel == "bag":
            self.update_bag_description(source=source, force=True)

    def _on_description_focus_out(self, panel: str):
        def _sync_after_focus_change():
            focused = self.root.focus_get()
            if focused is None:
                self._desc_lock[panel] = None
                if panel == "party":
                    self._hide_party_tooltip()
                return
            focused_name = str(focused).lower()
            if "popdown" in focused_name:
                return
            ctx = self._desc_widget_context.get(str(focused))
            if ctx is None or ctx[0] != panel:
                self._desc_lock[panel] = None
                if panel == "party":
                    self._hide_party_tooltip()

        self.root.after_idle(_sync_after_focus_change)

    def _on_description_hover(self, event, panel: str, source: str, index: int | None = None):
        lock = self._desc_lock.get(panel)
        if lock is not None and lock != (source, index):
            if panel == "party":
                self._hide_party_tooltip()
            return
        if panel == "party":
            if not self._party_description_has_value(source, index):
                self._hide_party_tooltip()
                return
            text = self.update_party_description(source, index, force=True)
            self._show_party_tooltip(text, event=event, widget=getattr(event, "widget", None))
        elif panel == "bag":
            self.update_bag_description(source=source, force=True)

    def _on_description_leave(self, _event, panel: str, source: str, index: int | None = None):
        if panel != "party":
            return
        lock = self._desc_lock.get("party")
        if lock is None or lock != (source, index):
            self._hide_party_tooltip()

    def _party_description_has_value(self, source: str | None, index: int | None = None) -> bool:
        kind = str(source or "").strip().lower()
        if kind == "species":
            # Requested: do not show tooltip for Species in Party.
            return False
        try:
            if kind == "item":
                raw = self.pk_item_var.get().strip()
                return bool(self.resolve_item_id(raw)) if raw else False
            if kind == "ability":
                return bool(self.resolve_selected_ability_id(self.pk_ability_var.get()))
            if kind == "nature":
                return bool(self.resolve_selected_nature_id(self.pk_nature_var.get()))
            if kind == "relearn":
                idx = index if index is not None else 0
                if 0 <= idx < len(self.relearn_move_vars):
                    return bool(self.resolve_selected_relearn_move_id(self.relearn_move_vars[idx].get()))
                return False
            if kind == "move":
                idx = index if index is not None else 0
                if 0 <= idx < len(self.move_id_vars):
                    return bool(self.resolve_selected_move_id(self.move_id_vars[idx].get()))
                return False
        except Exception:
            return False
        return False

    def _set_combo_values(self, combo: ttk.Combobox, values: list[str]):
        key = str(combo)
        cleaned: list[str] = []
        seen: set[str] = set()
        for v in values:
            s = str(v)
            if not s or s in seen:
                continue
            cleaned.append(s)
            seen.add(s)
        self._combo_all_values[key] = cleaned
        self._combo_nav_index[key] = 0
        combo["values"] = cleaned

    def _enable_combo_search(self, combo: ttk.Combobox):
        combo.configure(state="normal")
        self._prepare_combo_popdown(combo)
        combo.bind("<KeyPress>", lambda e, cb=combo: self._on_combo_keypress(e, cb), add="+")
        combo.bind("<KeyRelease>", lambda e, cb=combo: self._on_combo_keyrelease(e, cb), add="+")
        combo.bind("<<ComboboxSelected>>", lambda _e, cb=combo: self._reset_combo_filter(cb), add="+")
        combo.bind("<Escape>", lambda _e, cb=combo: self._on_combo_escape(cb), add="+")

    @staticmethod
    def _prepare_combo_popdown(combo: ttk.Combobox):
        try:
            popdown = combo.tk.call("ttk::combobox::PopdownWindow", str(combo))
            listbox_widget = f"{popdown}.f.l"
            # Prevent default listbox map behavior from stealing focus
            # so users can keep typing while the dropdown is shown.
            combo.tk.call("bind", listbox_widget, "<Map>", "break")
        except tk.TclError:
            pass

    def _on_combo_escape(self, combo: ttk.Combobox):
        self._reset_combo_filter(combo)
        try:
            combo.tk.call("ttk::combobox::Unpost", str(combo))
        except tk.TclError:
            pass

    def _reset_combo_filter(self, combo: ttk.Combobox):
        all_values = self._combo_all_values.get(str(combo), [])
        combo["values"] = all_values

    @staticmethod
    def _combo_filtered_values(combo: ttk.Combobox) -> list[str]:
        try:
            values = list(combo.cget("values"))
        except Exception:
            values = []
        return [str(v) for v in values if str(v)]

    @staticmethod
    def _combo_listbox_widget(combo: ttk.Combobox):
        try:
            popdown = combo.tk.call("ttk::combobox::PopdownWindow", str(combo))
            listbox_widget = f"{popdown}.f.l"
            return combo.nametowidget(listbox_widget)
        except Exception:
            return None

    def _sync_combo_highlight(self, combo: ttk.Combobox, index: int):
        values = self._combo_filtered_values(combo)
        if not values:
            return
        idx = max(0, min(int(index), len(values) - 1))
        self._combo_nav_index[str(combo)] = idx
        lb = self._combo_listbox_widget(combo)
        if lb is None:
            return
        try:
            lb.selection_clear(0, tk.END)
            lb.selection_set(idx)
            lb.activate(idx)
            lb.see(idx)
        except Exception:
            return

    def _on_combo_keypress(self, event, combo: ttk.Combobox):
        key = str(event.keysym or "")
        if key not in {"Up", "Down", "Return", "KP_Enter"}:
            return

        values = self._combo_filtered_values(combo)
        if not values:
            all_values = self._combo_all_values.get(str(combo), [])
            if all_values:
                combo["values"] = all_values
                values = [str(v) for v in all_values]
        if not values:
            return "break"

        current_text = combo.get().strip()
        current_idx = self._combo_nav_index.get(str(combo), 0)
        if current_text in values:
            current_idx = values.index(current_text)
        elif current_text:
            query = current_text.casefold()
            for i, val in enumerate(values):
                if query in val.casefold():
                    current_idx = i
                    break
        current_idx = max(0, min(current_idx, len(values) - 1))

        if key in {"Up", "Down"}:
            delta = -1 if key == "Up" else 1
            next_idx = max(0, min(current_idx + delta, len(values) - 1))
            selected = values[next_idx]
            combo.delete(0, tk.END)
            combo.insert(0, selected)
            combo.icursor(tk.END)
            self._sync_combo_highlight(combo, next_idx)
            combo.after_idle(lambda cb=combo: self._post_combo_dropdown(cb))
            return "break"

        # Enter confirms the highlighted/current row.
        chosen_idx = current_idx
        if current_text and current_text in values:
            chosen_idx = values.index(current_text)
        selected = values[chosen_idx]
        combo.delete(0, tk.END)
        combo.insert(0, selected)
        combo.icursor(tk.END)
        self._sync_combo_highlight(combo, chosen_idx)
        try:
            combo.tk.call("ttk::combobox::Unpost", str(combo))
        except tk.TclError:
            pass
        try:
            combo.event_generate("<<ComboboxSelected>>")
        except Exception:
            pass
        return "break"

    def _on_combo_keyrelease(self, event, combo: ttk.Combobox):
        if event.keysym in {
            "Up", "Down", "Left", "Right", "Return", "Tab",
            "Shift_L", "Shift_R", "Control_L", "Control_R",
            "Alt_L", "Alt_R", "Escape", "Home", "End", "Prior", "Next",
        }:
            return
        all_values = self._combo_all_values.get(str(combo), [])
        if not all_values:
            return
        original_text = combo.get()
        query = original_text.strip().casefold()
        if not query:
            filtered = all_values
        else:
            filtered = [v for v in all_values if query in v.casefold()]
            if not filtered:
                filtered = all_values
        combo["values"] = filtered
        self._combo_nav_index[str(combo)] = 0
        if combo.get() != original_text:
            combo.delete(0, tk.END)
            combo.insert(0, original_text)
        combo.icursor(tk.END)
        combo.after_idle(lambda cb=combo: self._post_combo_dropdown(cb))
        combo.after_idle(lambda cb=combo: self._sync_combo_highlight(cb, 0))

    @staticmethod
    def _post_combo_dropdown(combo: ttk.Combobox):
        try:
            combo.tk.call("ttk::combobox::Post", str(combo))
            combo.focus_set()
            combo.icursor(tk.END)
        except tk.TclError:
            pass

    # ------------------------- Mapper/Profile lock -------------------------
    def _reload_profile_lock(self):
        self.profile_lock_warning = None
        if probe_mapper is None:
            self.profile_lock_data = None
            self.profile_lock_warning = "Probe mapper module is unavailable."
            return
        try:
            self.profile_lock_data = probe_mapper.load_profile(self.profile_lock_path)
        except Exception as exc:  # noqa: BLE001
            self.profile_lock_data = None
            self.profile_lock_warning = str(exc)

    def _candidate_probe_save_path(self, preferred: Path | None = None) -> Path | None:
        if preferred and Path(preferred).exists():
            return Path(preferred)
        if self.save_path and self.save_path.exists():
            return self.save_path
        chosen = self.save_var.get().strip()
        if chosen:
            path = Path(chosen)
            if path.exists():
                return path
        return None

    def _run_profile_mapper(self, preferred_save: Path | None = None, show_success: bool = True) -> bool:
        if probe_mapper is None:
            messagebox.showerror(
                "Mapper Unavailable",
                "pokemon_indigo_probe_mapper.py is missing or failed to load.",
            )
            return False
        save_path = self._candidate_probe_save_path(preferred_save)
        if save_path is None:
            initial_dir = str(core.default_save_dir())
            picked = filedialog.askopenfilename(
                title="Select Save File For Mapping",
                initialdir=initial_dir,
                filetypes=[("RGSS Save", "*.rxdata"), ("All files", "*.*")],
            )
            if not picked:
                return False
            save_path = Path(picked)
        try:
            profile = probe_mapper.run_probe(
                game_root=self.game_root,
                save_path=save_path,
                profile_path=self.profile_lock_path,
            )
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Mapper Error", f"Could not run mapper/probe:\n{exc}")
            return False
        self.profile_lock_data = profile
        self.profile_lock_warning = None
        self.set_status(f"Profile lock mapped from {save_path.name}.")
        if show_success:
            messagebox.showinfo(
                "Mapper Completed",
                f"Profile lock updated:\n{self.profile_lock_path}\n\nSave used:\n{save_path}",
            )
        return True

    def run_game_probe_wizard(self):
        self._run_profile_mapper(show_success=True)

    def _ensure_profile_lock(self, save_path: Path | None, interactive: bool = True) -> bool:
        if probe_mapper is None:
            if interactive:
                messagebox.showerror(
                    "Mapper Unavailable",
                    "pokemon_indigo_probe_mapper.py is missing or failed to load.",
                )
            return False
        if self.profile_lock_data is None:
            self._reload_profile_lock()
        ok, reason, _details = probe_mapper.verify_profile_data(
            self.profile_lock_data,
            self.game_root,
            save_path=save_path,
        )
        if ok:
            return True
        if not interactive:
            return False
        should_map = messagebox.askyesno(
            "Profile Lock Required",
            (
                f"{reason}\n\n"
                "To avoid wrong game/save mapping, this editor requires a fresh profile lock.\n"
                "Run mapper now?"
            ),
        )
        if not should_map:
            self.set_status("Blocked: profile lock is missing/outdated.")
            return False
        if not self._run_profile_mapper(preferred_save=save_path, show_success=False):
            self.set_status("Blocked: mapper did not complete.")
            return False
        ok2, reason2, _details2 = probe_mapper.verify_profile_data(
            self.profile_lock_data,
            self.game_root,
            save_path=save_path,
        )
        if not ok2:
            messagebox.showerror("Profile Check Failed", reason2)
            self.set_status("Blocked: profile check failed.")
            return False
        self.set_status("Profile lock check passed.")
        return True

    # ------------------------- Core actions -------------------------
    def set_status(self, text: str):
        suffix = " (modified)" if self.modified else ""
        self.status_var.set(f"{text}{suffix}")

    def mark_modified(self):
        self.modified = True
        self.save_btn.state(["!disabled"])
        self.set_status("Save loaded.")

    def refresh_save_list(self):
        self._reload_profile_lock()
        try:
            files = core.list_save_files(core.default_save_dir())
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Error", f"Cannot read save folder: {exc}")
            return
        values = [str(p) for p in files]
        self.save_combo["values"] = values
        if values and not self.save_var.get():
            self.save_var.set(values[0])
        notes: list[str] = []
        if self.catalog_error:
            notes.append(f"Catalog warning: {self.catalog_error}")
        if probe_mapper is None:
            notes.append("Mapper module unavailable.")
        elif self.profile_lock_data is None:
            notes.append("No profile lock yet (click 'Map Game Data').")
        elif self.profile_lock_warning:
            notes.append(f"Profile lock warning: {self.profile_lock_warning}")
        if notes:
            self.set_status(f"Save list refreshed. {' '.join(notes)}")
        else:
            self.set_status("Save list refreshed.")

    def browse_save(self):
        picked = filedialog.askopenfilename(
            title="Select Save File",
            filetypes=[("RGSS Save", "*.rxdata"), ("All files", "*.*")],
        )
        if picked:
            self.save_var.set(picked)

    def load_selected_save(self):
        chosen = self.save_var.get().strip()
        if not chosen:
            messagebox.showwarning("No Save", "Please select a save file.")
            return
        path = Path(chosen)
        if not path.exists():
            messagebox.showerror("Missing File", f"File not found:\n{path}")
            return
        if not self._ensure_profile_lock(path, interactive=True):
            return
        try:
            self.save_data = core.load_save(path)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Load Error", f"Could not load save:\n{exc}")
            return
        self.save_path = path
        self.modified = False
        self.save_btn.state(["!disabled"])
        issues = core.sanity_check_save_data(self.save_data)
        if issues:
            issue_text = "\n".join(f"- {x}" for x in issues)
            messagebox.showwarning(
                "Save Warning",
                "Loaded save appears corrupted or inconsistent:\n\n"
                f"{issue_text}\n\n"
                "You should restore from an older backup before editing.",
            )
        normalized_count, unresolved_ids = self.normalize_known_ids()
        if normalized_count > 0:
            self.modified = True
            self.save_btn.state(["!disabled"])
            msg = (
                f"Normalized {normalized_count} ID field(s) to canonical game IDs.\n"
                "Click 'Save Changes' to permanently write this fix to the save file."
            )
            if unresolved_ids:
                sample = ", ".join(unresolved_ids[:6])
                msg += f"\n\nUnresolved unknown IDs (sample): {sample}"
            messagebox.showinfo("ID Normalized", msg)
        self.refresh_all_tabs()
        self.set_status(f"Loaded {path.name}")

    def write_save(self):
        if self.save_data is None or self.save_path is None:
            messagebox.showwarning("No Save", "No save loaded.")
            return
        if not self._ensure_profile_lock(self.save_path, interactive=True):
            return
        normalized_count = 0
        unresolved_ids: list[str] = []
        try:
            normalized_count, unresolved_ids = self.normalize_known_ids()
            backup = core.save_save(self.save_path, self.save_data, make_backup=True)
            issues = core.validate_save_file(self.save_path)
            if issues:
                if backup and Path(backup).exists():
                    shutil.copy2(backup, self.save_path)
                issue_text = "\n".join(f"- {x}" for x in issues)
                raise ValueError(
                    "Saved file failed sanity check and was reverted from backup.\n"
                    f"{issue_text}"
                )
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Save Error", f"Could not save file:\n{exc}")
            return
        self.modified = False
        self.set_status(f"Saved {self.save_path.name}")
        msg = f"Saved:\n{self.save_path}"
        if backup:
            msg += f"\n\nBackup:\n{backup}"
        if normalized_count:
            msg += f"\n\nNormalized IDs before save: {normalized_count}"
        if unresolved_ids:
            sample = ", ".join(unresolved_ids[:6])
            msg += f"\nUnresolved unknown IDs (sample): {sample}"
        messagebox.showinfo("Saved", msg)

    def refresh_all_tabs(self):
        self.refresh_trainer_tab()
        self.refresh_party_tab()
        self.refresh_bag_list()
        self.load_switch()
        self.load_variable()
        self.adv_output.delete("1.0", "end")

    # ------------------------- Trainer tab -------------------------
    def refresh_trainer_tab(self):
        player = self.get_player()
        if not player:
            return
        self.trainer_name_var.set(symbol_name(core.read_attr(player, "@name", "")))
        self.trainer_id_var.set(str(core.read_attr(player, "@id", "")))
        self.trainer_type_var.set(symbol_name(core.read_attr(player, "@trainer_type", "")))
        self.money_var.set(str(core.read_attr(player, "@money", 0)))
        self.coins_var.set(str(core.read_attr(player, "@coins", 0)))
        self.bp_var.set(str(core.read_attr(player, "@battle_points", 0)))
        self.save_slot_var.set(symbol_name(core.read_attr(player, "@save_slot", "")))

        badges = core.read_attr(player, "@badges", [])
        if isinstance(badges, list):
            for i, b in enumerate(self.badge_vars):
                if i < len(badges):
                    b.set(bool(badges[i]))
                else:
                    b.set(False)

    def apply_trainer_changes(self):
        player = self.get_player()
        if not player:
            return
        try:
            player.attributes["@name"] = self.trainer_name_var.get().strip()
            if "@trainer_type" in player.attributes:
                player.attributes["@trainer_type"] = to_symbol_or_none(self.trainer_type_var.get())
            if "@money" in player.attributes:
                player.attributes["@money"] = parse_int(self.money_var.get(), "Money")
            if "@coins" in player.attributes:
                player.attributes["@coins"] = parse_int(self.coins_var.get(), "Coins")
            if "@battle_points" in player.attributes:
                player.attributes["@battle_points"] = parse_int(self.bp_var.get(), "Battle Points")
            if "@save_slot" in player.attributes:
                player.attributes["@save_slot"] = self.save_slot_var.get().strip()

            badges = core.read_attr(player, "@badges", [])
            if isinstance(badges, list):
                needed = max(len(badges), len(self.badge_vars))
                if len(badges) < needed:
                    badges.extend([False] * (needed - len(badges)))
                for i, var in enumerate(self.badge_vars):
                    badges[i] = bool(var.get())
                player.attributes["@badges"] = badges
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Apply Error", str(exc))
            return
        self.mark_modified()
        self.set_status("Trainer changes applied.")

    # ------------------------- Party tab -------------------------
    def refresh_party_tab(self):
        self._refresh_party_box_controls()
        self._party_selected_mode = None
        self._party_selected_index = None
        self._party_selected_box_index = None
        self._clear_party_detail_fields()
        self.party_slot_status_var.set("Select a target slot.")
        self._render_party_slot_grid()
        self.update_party_editor_preview()
        self.update_party_evolution_chart()

    def _selected_slot_entry(self) -> tuple[Any, str]:
        if self._party_selected_mode is None or self._party_selected_index is None:
            return None, ""
        idx = self._party_selected_index
        if self._party_selected_mode == "party":
            player = self.get_root_key("player")
            party = core.read_attr(player, "@party", []) if isinstance(player, core.RubyObject) else []
            if not isinstance(party, list):
                return None, f"Party {idx + 1}"
            if idx >= len(party):
                return None, f"Party {idx + 1}"
            return party[idx], f"Party {idx + 1}"
        boxes = self._get_storage_boxes()
        box_idx = self._party_selected_box_index if self._party_selected_box_index is not None else self._selected_box_index()
        if box_idx < 0 or box_idx >= len(boxes):
            return None, f"Box ? Slot {idx + 1}"
        box_name = self._box_display_name(boxes[box_idx], box_idx)
        box_data = self._get_box_pokemon_list(boxes[box_idx])
        if idx >= len(box_data):
            return None, f"{box_name} Slot {idx + 1}"
        return box_data[idx], f"{box_name} Slot {idx + 1}"

    def select_party_slot(self, idx: int):
        _entries, _rows, _cols, mode, box_idx = self._party_slot_cells()
        self._party_selected_mode = mode
        self._party_selected_index = idx
        self._party_selected_box_index = box_idx
        self._render_party_slot_grid()
        entry, label = self._selected_slot_entry()
        if not isinstance(entry, core.RubyObject):
            self.party_slot_status_var.set(f"Target: {label} (empty)")
            return
        self.party_slot_status_var.set(f"Target: {label}")

    def load_selected_slot_into_editor(self):
        entry, label = self._selected_slot_entry()
        if not isinstance(entry, core.RubyObject):
            messagebox.showwarning("No Pokemon", "Selected slot is empty.")
            return
        self._load_selected_pokemon_into_editor(entry)
        self.party_slot_status_var.set(f"Loaded: {label}")

    def _load_selected_pokemon_into_editor(self, pkmn: core.RubyObject):
        species_id = symbol_name(core.read_attr(pkmn, "@species", ""))
        self.pk_species_var.set(self._species_choice(species_id))
        self.pk_form_var.set(str(core.read_attr(pkmn, "@form", 0)))
        self.pk_level_var.set(str(core.read_attr(pkmn, "@level", "")))
        self.pk_exp_var.set(str(core.read_attr(pkmn, "@exp", "")))
        self.pk_hp_var.set(str(core.read_attr(pkmn, "@hp", "")))
        self.pk_totalhp_var.set(str(core.read_attr(pkmn, "@totalhp", "")))
        self.pk_attack_var.set(str(core.read_attr(pkmn, "@attack", "")))
        self.pk_defense_var.set(str(core.read_attr(pkmn, "@defense", "")))
        self.pk_spatk_var.set(str(core.read_attr(pkmn, "@spatk", "")))
        self.pk_spdef_var.set(str(core.read_attr(pkmn, "@spdef", "")))
        self.pk_speed_var.set(str(core.read_attr(pkmn, "@speed", "")))
        self.pk_happiness_var.set(str(core.read_attr(pkmn, "@happiness", "")))
        nature_id = self._nature_choice(symbol_name(core.read_attr(pkmn, "@nature", "")))
        self.pk_nature_var.set(self._party_nature_id_to_label.get(nature_id, self._nature_label_for_id(nature_id)))
        self.pk_name_var.set(symbol_name(core.read_attr(pkmn, "@name", "")))
        self.pk_obtain_level_var.set(str(core.read_attr(pkmn, "@obtain_level", "")))
        self.pk_obtain_map_var.set(str(core.read_attr(pkmn, "@obtain_map", "")))
        self.pk_obtain_method_var.set(str(core.read_attr(pkmn, "@obtain_method", "")))
        self.pk_obtain_text_var.set(symbol_name(core.read_attr(pkmn, "@obtain_text", "")))
        self.pk_hatched_map_var.set(str(core.read_attr(pkmn, "@hatched_map", "")))
        self.pk_ability_index_var.set(self._normalize_optional_int_text(core.read_attr(pkmn, "@ability_index", "")))
        self.pk_personal_id_var.set(str(core.read_attr(pkmn, "@personalID", "")))
        self.pk_forced_form_var.set(self._normalize_optional_int_text(core.read_attr(pkmn, "@forced_form", "")))
        legacy = core.read_attr(pkmn, "@legacy_data", "")
        if isinstance(legacy, (dict, list, tuple, core.RubyObject)):
            self.pk_legacy_var.set(f"<{type(legacy).__name__}>")
        else:
            self.pk_legacy_var.set(symbol_name(legacy))

        self.pk_shiny_var.set(bool(core.read_attr(pkmn, "@shiny", False)))
        self.pk_super_shiny_var.set(bool(core.read_attr(pkmn, "@super_shiny", False)))
        self.pk_gender_var.set(str(core.read_attr(pkmn, "@gender", "")))

        iv_map = self._read_symbol_stat_dict(pkmn, "@iv")
        ev_map = self._read_symbol_stat_dict(pkmn, "@ev")
        for stat_id, _label in STAT_ORDER:
            self.party_iv_vars[stat_id].set(str(iv_map.get(stat_id, 0)))
            self.party_ev_vars[stat_id].set(str(ev_map.get(stat_id, 0)))

        self.refresh_party_legality_dropdowns(reset_invalid=False)
        self._refresh_stats_from_editor_inputs()

        item_id = symbol_name(core.read_attr(pkmn, "@item", ""))
        self.pk_item_var.set(self._item_choice(item_id) if item_id else "")
        ability_id = symbol_name(core.read_attr(pkmn, "@ability", ""))
        if ability_id:
            ability_key = self.catalogs.canonical_ability_id(ability_id) if self.catalogs else ability_id.lstrip(":")
            self.pk_ability_var.set(self._party_ability_id_to_label.get(ability_key, self._ability_choice(ability_id)))
        else:
            self.pk_ability_var.set("")

        moves = core.read_attr(pkmn, "@moves", [])
        for i in range(4):
            if i < len(moves) and isinstance(moves[i], core.RubyObject):
                move = moves[i]
                move_id = symbol_name(core.read_attr(move, "@id", ""))
                if move_id:
                    move_key = self.catalogs.canonical_move_id(move_id) if self.catalogs else move_id.lstrip(":")
                    self.move_id_vars[i].set(self._party_move_id_to_label.get(move_key, self._move_choice(move_id)))
                else:
                    move_key = ""
                    self.move_id_vars[i].set("")
                ppup_value = self._clamp_int(str(core.read_attr(move, "@ppup", 0)), 0, 3, 0)
                pp_value = core.read_attr(move, "@pp", "")
                pp_text = str(pp_value).strip()
                if move_key:
                    max_pp = self._move_max_pp(move_key, ppup_value)
                    if not pp_text:
                        pp_text = str(max_pp)
                    else:
                        pp_text = str(self._clamp_int(pp_text, 0, max_pp, max_pp))
                self.move_pp_vars[i].set(pp_text)
                self.move_ppup_vars[i].set(str(ppup_value))
            else:
                self.move_id_vars[i].set("")
                self.move_pp_vars[i].set("")
                self.move_ppup_vars[i].set("")

        first_moves = core.read_attr(pkmn, "@first_moves", [])
        if not isinstance(first_moves, list):
            first_moves = []
        for i in range(4):
            if i < len(first_moves):
                move_id = symbol_name(first_moves[i])
                move_key = self.catalogs.canonical_move_id(move_id) if self.catalogs else move_id.lstrip(":")
                self.relearn_move_vars[i].set(self._party_relearn_id_to_label.get(move_key, "(None)"))
            else:
                self.relearn_move_vars[i].set("(None)")
        self._sync_ability_index_from_selection(force=False)
        self._update_nature_effect_labels()
        self.update_party_editor_preview()
        self.update_party_evolution_chart()
        self.update_party_description("species")

    def on_species_or_form_changed(self, _event=None):
        self.refresh_party_legality_dropdowns(reset_invalid=True)
        self._refresh_stats_from_editor_inputs()
        editor_blank = not any(
            [
                self.pk_level_var.get().strip(),
                self.pk_exp_var.get().strip(),
                self.pk_nature_var.get().strip(),
                self.move_id_vars[0].get().strip() if self.move_id_vars else "",
            ]
        )
        if editor_blank:
            self.load_species_defaults_into_editor()
        self.update_party_editor_preview()
        self.update_party_evolution_chart()
        self.update_party_description("species")

    def on_nature_changed(self, _event=None):
        self._update_nature_effect_labels()
        self._refresh_stats_from_editor_inputs()
        self.update_party_description("nature")

    @staticmethod
    def _normalize_optional_int_text(value: Any) -> str:
        if value is None:
            return ""
        if isinstance(value, int) and not isinstance(value, bool):
            return str(value)
        raw = str(value).strip()
        if raw.lower() in {"none", "nil", "null"}:
            return ""
        return raw

    def _suggest_ability_index_for_current(self) -> int | None:
        if not self.catalogs:
            return None
        species_id, form = self._current_species_form()
        if not species_id:
            return None
        ability_id = self.resolve_selected_ability_id(self.pk_ability_var.get())
        if not ability_id:
            return None
        profile = self.catalogs.get_species_form_profile(species_id, form=form)
        if not profile:
            return None
        regular: list[str] = []
        for raw in profile.ability_ids:
            aid = self.catalogs.canonical_ability_id(raw)
            if aid and aid not in regular:
                regular.append(aid)
        hidden: set[str] = set()
        for raw in profile.hidden_ability_ids:
            aid = self.catalogs.canonical_ability_id(raw)
            if aid:
                hidden.add(aid)
        if ability_id in hidden:
            return 2
        if ability_id in regular:
            return regular.index(ability_id)
        return 0

    def _sync_ability_index_from_selection(self, force: bool = False):
        suggestion = self._suggest_ability_index_for_current()
        if suggestion is None:
            return
        raw = self.pk_ability_index_var.get().strip()
        if force or raw == "" or raw.lower() in {"none", "nil", "null"}:
            self.pk_ability_index_var.set(str(self._clamp_int(str(suggestion), 0, 3, 0)))

    def on_ability_changed(self, _event=None):
        self._sync_ability_index_from_selection(force=True)
        self.update_party_description("ability")

    def on_ability_index_focus_out(self, _event=None):
        raw = self.pk_ability_index_var.get().strip()
        if raw.lower() in {"", "none", "nil", "null"}:
            self._sync_ability_index_from_selection(force=False)
            return
        try:
            value = parse_int(raw, "Ability Index")
        except Exception:
            self._sync_ability_index_from_selection(force=True)
            return
        self.pk_ability_index_var.set(str(self._clamp_int(str(value), 0, 3, 0)))

    def on_forced_form_focus_out(self, _event=None):
        raw = self.pk_forced_form_var.get().strip()
        if raw.lower() in {"", "none", "nil", "null"}:
            self.pk_forced_form_var.set("")
            return
        try:
            value = parse_int(raw, "Forced Form")
        except Exception:
            self.pk_forced_form_var.set("")
            return
        self.pk_forced_form_var.set(str(self._clamp_int(str(value), 0, 999, 0)))

    def on_shiny_changed(self):
        self.update_party_editor_preview()
        self.update_party_description("species")

    def _nature_choice(self, nature_id: str) -> str:
        return nature_id.strip().lstrip(":").upper()

    def _nature_label_for_id(self, nature_id: str) -> str:
        nature = self._nature_choice(nature_id)
        if not nature:
            return ""
        up, down = NATURE_EFFECTS.get(nature, (None, None))
        if up and down:
            return f"{nature} ({STAT_SHORT_LABELS.get(up, up)}↑ / {STAT_SHORT_LABELS.get(down, down)}↓)"
        return nature

    def _refresh_nature_choices(self):
        if not hasattr(self, "pk_nature_combo"):
            return
        if self.catalogs:
            nature_ids = sorted((self._nature_choice(n) for n in self.catalogs.natures if str(n).strip()), key=str.casefold)
        else:
            nature_ids = sorted({"HARDY", "LONELY", "BRAVE", "ADAMANT", "NAUGHTY", "BOLD", "DOCILE", "RELAXED",
                                 "IMPISH", "LAX", "TIMID", "HASTY", "SERIOUS", "JOLLY", "NAIVE", "MODEST",
                                 "MILD", "QUIET", "BASHFUL", "RASH", "CALM", "GENTLE", "SASSY", "CAREFUL", "QUIRKY"},
                                key=str.casefold)
        label_pairs: list[tuple[str, str]] = []
        for nature_id in nature_ids:
            label = self._nature_label_for_id(nature_id)
            if any(existing == label for existing, _ in label_pairs):
                label = f"{label} [{nature_id}]"
            label_pairs.append((label, nature_id))
        self._party_nature_label_to_id = {label: nid for label, nid in label_pairs}
        self._party_nature_id_to_label = {}
        for label, nature_id in label_pairs:
            self._party_nature_id_to_label.setdefault(nature_id, label)
        self._set_combo_values(self.pk_nature_combo, [label for label, _ in label_pairs])

    def resolve_selected_nature_id(self, text: str) -> str:
        raw = text.strip()
        if not raw:
            return ""
        if raw in self._party_nature_label_to_id:
            return self._party_nature_label_to_id[raw]
        cleaned = re.sub(r"\s+\([^)]+\)\s*$", "", raw)
        cleaned = re.sub(r"\s+\[[^\]]+\]\s*$", "", cleaned)
        cleaned = extract_internal_id(cleaned).strip().lstrip(":").upper()
        if not cleaned:
            return ""
        return cleaned

    def _default_move_pp(self, move_id: str) -> int:
        if self.catalogs:
            return self.catalogs.move_total_pp(move_id, default=5)
        return 5

    def _move_max_pp(self, move_id: str, ppup_value: str | int) -> int:
        base_pp = self._default_move_pp(move_id)
        ppup = self._clamp_int(str(ppup_value), 0, 3, 0)
        # Mainline formula: MaxPP = BasePP + floor(BasePP * PPUps / 5)
        return base_pp + ((base_pp * ppup) // 5)

    def on_move_combo_changed(self, index: int, force_pp: bool = True, update_description: bool = True):
        if index < 0 or index >= len(self.move_id_vars):
            return
        move_id = self.resolve_selected_move_id(self.move_id_vars[index].get())
        ppup = self._clamp_int(self.move_ppup_vars[index].get(), 0, 3, 0)
        self.move_ppup_vars[index].set(str(ppup))
        if force_pp:
            self.move_pp_vars[index].set(str(self._move_max_pp(move_id, ppup)) if move_id else "")
        elif move_id:
            max_pp = self._move_max_pp(move_id, ppup)
            if not self.move_pp_vars[index].get().strip():
                self.move_pp_vars[index].set(str(max_pp))
            else:
                self.move_pp_vars[index].set(str(self._clamp_int(self.move_pp_vars[index].get(), 0, max_pp, max_pp)))
        if update_description:
            self.update_party_description("move", index)

    def on_move_ppup_changed(self, index: int):
        if index < 0 or index >= len(self.move_id_vars):
            return
        ppup = self._clamp_int(self.move_ppup_vars[index].get(), 0, 3, 0)
        self.move_ppup_vars[index].set(str(ppup))
        move_id = self.resolve_selected_move_id(self.move_id_vars[index].get())
        if move_id:
            self.move_pp_vars[index].set(str(self._move_max_pp(move_id, ppup)))
        self.update_party_description("move", index)

    def on_move_pp_focus_out(self, index: int):
        if index < 0 or index >= len(self.move_id_vars):
            return
        move_id = self.resolve_selected_move_id(self.move_id_vars[index].get())
        ppup = self._clamp_int(self.move_ppup_vars[index].get(), 0, 3, 0)
        self.move_ppup_vars[index].set(str(ppup))
        if move_id:
            max_pp = self._move_max_pp(move_id, ppup)
            self.move_pp_vars[index].set(str(self._clamp_int(self.move_pp_vars[index].get(), 0, max_pp, max_pp)))
        else:
            self.move_pp_vars[index].set(str(self._clamp_int(self.move_pp_vars[index].get(), 0, 999, 0)))

    def _set_text_widget_content(self, widget: tk.Text, text: str):
        content = text.strip() or "No description available."
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", content)
        self._bold_type_terms_in_description(widget, content)
        widget.configure(state="disabled")

    def _description_type_terms(self) -> list[str]:
        terms = {self._prettify_internal_id(tid) for tid in self._known_type_ids()}
        return sorted((t for t in terms if t), key=lambda v: (-len(v), v.casefold()))

    def _bold_type_terms_in_description(self, widget: tk.Text, content: str):
        try:
            base_font = tkfont.nametofont(str(widget.cget("font")))
            bold_font = getattr(widget, "_desc_bold_font", None)
            if bold_font is None:
                bold_font = base_font.copy()
                bold_font.configure(weight="bold")
                setattr(widget, "_desc_bold_font", bold_font)
            widget.tag_configure("desc_type_bold", font=bold_font)
            widget.tag_remove("desc_type_bold", "1.0", "end")
            for term in self._description_type_terms():
                pattern = rf"(?i)\b{re.escape(term)}(?:-type)?\b"
                for match in re.finditer(pattern, content):
                    start = f"1.0+{match.start()}c"
                    end = f"1.0+{match.end()}c"
                    widget.tag_add("desc_type_bold", start, end)
        except Exception:
            return

    @staticmethod
    def _title_case_words(text: str) -> str:
        raw = re.sub(r"\s+", " ", str(text or "").strip())
        if not raw:
            return ""
        return raw.title()

    @staticmethod
    def _prettify_internal_id(raw_id: str) -> str:
        text = str(raw_id or "").strip().lstrip(":")
        if not text:
            return ""
        tokens = re.split(r"[_\-\s]+", text)
        suffixes = (
            "POWER",
            "FORCE",
            "GUARD",
            "BODY",
            "SKIN",
            "ARMOR",
            "ARMOUR",
            "STREAM",
            "START",
            "EYES",
            "VOICE",
            "DANCE",
            "STONE",
            "CLAW",
            "COAT",
            "CORD",
            "WHIP",
            "FANG",
            "TOOTH",
            "SHARD",
            "ORB",
        )
        out: list[str] = []
        for token in tokens:
            upper = token.upper()
            if not upper:
                continue
            split_done = False
            for suffix in suffixes:
                if upper.endswith(suffix) and len(upper) > len(suffix) + 2:
                    out.append(upper[: -len(suffix)])
                    out.append(suffix)
                    split_done = True
                    break
            if not split_done:
                out.append(upper)
        return SaveEditorApp._title_case_words(" ".join(out))

    def _translate_to_english(self, text: str) -> str:
        raw = text.strip()
        if not raw:
            return ""
        cached = self._translated_desc_cache.get(raw)
        if cached:
            return cached
        translated = ""
        try:
            url = (
                "https://translate.googleapis.com/translate_a/single"
                f"?client=gtx&sl=auto&tl=en&dt=t&q={urllib.parse.quote(raw)}"
            )
            with urllib.request.urlopen(url, timeout=1.5) as response:
                payload = json.loads(response.read().decode("utf-8", errors="replace"))
            if isinstance(payload, list) and payload and isinstance(payload[0], list):
                parts = []
                for chunk in payload[0]:
                    if isinstance(chunk, list) and chunk:
                        segment = str(chunk[0]).strip()
                        if segment:
                            parts.append(segment)
                translated = "".join(parts).strip()
        except Exception:
            translated = ""
        # Only persist successful translations; allow retry on transient failures.
        if translated:
            self._translated_desc_cache[raw] = translated
        return translated

    def _english_description(self, text: str, fallback: str) -> str:
        raw = str(text or "").strip()
        if not raw:
            return fallback
        is_ascii = all(ord(ch) < 128 for ch in raw)
        looks_non_english_ascii = is_ascii and self._looks_non_english_ascii(raw)
        if is_ascii and not looks_non_english_ascii:
            # Fast path for likely-English descriptions.
            return raw
        translated = self._translate_to_english(raw)
        if translated:
            return translated
        if is_ascii and not looks_non_english_ascii:
            return raw
        return fallback

    @staticmethod
    def _looks_non_english_ascii(text: str) -> bool:
        words = re.findall(r"[A-Za-z']+", str(text or "").casefold())
        if not words:
            return False
        spanish_markers = {
            "al", "del", "con", "sin", "para", "nivel", "ataque", "defensa", "rival",
            "combate", "disminuye", "aumenta", "pokemon", "movimiento", "turno",
            "objetivo", "habilidad", "entra", "sale", "usa", "puede",
        }
        if any(w in spanish_markers for w in words):
            return True
        english_markers = {
            "the", "target", "user", "attack", "defense", "damage", "move",
            "turn", "level", "pokemon", "this", "that", "when", "after", "before",
            "raises", "lowers", "heals", "accuracy", "power", "speed", "ability",
        }
        long_words = [w for w in words if len(w) >= 3]
        if not long_words:
            return False
        english_hits = sum(1 for w in long_words if w in english_markers)
        ratio = english_hits / max(1, len(long_words))
        return ratio < 0.18

    @staticmethod
    def _sanitize_move_description_text(text: str) -> str:
        out = re.sub(r"\s+", " ", str(text or "").strip())
        if not out:
            return ""
        replacements = (
            (r"\bHe\b", "It"),
            (r"\bhe\b", "it"),
            (r"\bShe\b", "It"),
            (r"\bshe\b", "it"),
            (r"\bHis\b", "Its"),
            (r"\bhis\b", "its"),
            (r"\bHer(?=\s+[A-Za-z])", "Its"),
            (r"\bher(?=\s+[A-Za-z])", "its"),
            (r"\bHim\b", "It"),
            (r"\bhim\b", "it"),
            (r"\bHimself\b", "Itself"),
            (r"\bhimself\b", "itself"),
            (r"\bHerself\b", "Itself"),
            (r"\bherself\b", "itself"),
            (r"\bHer\b", "It"),
            (r"\bher\b", "it"),
        )
        for pattern, repl in replacements:
            out = re.sub(pattern, repl, out)
        if out:
            out = out[0].upper() + out[1:]
        return out

    def _is_low_quality_move_description(self, text: str) -> bool:
        raw = str(text or "").strip()
        if not raw:
            return True
        normalized = raw.casefold().strip(". !?")
        if normalized in LOW_QUALITY_DESC_TOKENS:
            return True
        words = re.findall(r"[A-Za-z']+", raw)
        if len(words) <= 2:
            return True
        # Likely still mistranslated if it keeps obvious non-English ASCII markers.
        if all(ord(ch) < 128 for ch in raw) and self._looks_non_english_ascii(raw):
            return True
        return False

    def _english_ability_name_for_id(self, ability_id: str) -> str:
        aid = str(ability_id or "").strip().lstrip(":")
        if not aid:
            return ""
        if self.catalogs:
            canonical = self.catalogs.canonical_ability_id(aid) or aid
            english = self.catalogs.ability_english_name(canonical)
            if english:
                return english
            # Always prefer internal IDs for stable English labels even if catalog
            # display names are localized.
            return self._prettify_internal_id(canonical)
        return self._prettify_internal_id(aid)

    def _tm_hm_display_label(self, item_id: str, pocket_index: int | None = None) -> str:
        iid = str(item_id or "").strip().lstrip(":")
        if not iid:
            return ""
        if pocket_index is None:
            try:
                pocket_index = self.get_selected_bag_pocket_index()
            except Exception:
                pocket_index = None
        if pocket_index != 4 or not self.catalogs:
            return iid
        m = re.match(r"^(TM|HM)(\d+)$", iid, flags=re.IGNORECASE)
        if not m:
            return iid
        item = self.catalogs.items_by_id.get(iid) or self.catalogs.items_by_id.get(self.catalogs.canonical_item_id(iid) or "")
        if not item:
            return iid
        move_raw = str(item.extra.get("Move", "")).strip().lstrip(":")
        if not move_raw:
            return iid
        move_id = self.catalogs.canonical_move_id(move_raw) or move_raw
        move_name = self._prettify_internal_id(move_id)
        if not move_name:
            return iid
        return f"{iid.upper()} - {move_name}"

    def _nature_description(self, nature_id: str) -> str:
        nature = self._nature_choice(nature_id)
        if not nature:
            return ""
        up, down = NATURE_EFFECTS.get(nature, (None, None))
        if not up or not down:
            return "Neutral nature. No stat is increased or decreased."
        return (
            f"Increases {STAT_SHORT_LABELS.get(up, up)} and decreases {STAT_SHORT_LABELS.get(down, down)} "
            "when calculating battle stats."
        )

    @staticmethod
    def _join_with_and(values: list[str]) -> str:
        if not values:
            return ""
        if len(values) == 1:
            return values[0]
        if len(values) == 2:
            return f"{values[0]} and {values[1]}"
        return f"{', '.join(values[:-1])}, and {values[-1]}"

    @staticmethod
    def _dedupe_preserve(lines: list[str]) -> list[str]:
        out: list[str] = []
        seen: set[str] = set()
        for line in lines:
            text = str(line or "").strip()
            if not text:
                continue
            key = text.casefold()
            if key in seen:
                continue
            seen.add(key)
            out.append(text)
        return out

    @staticmethod
    def _extract_numeric_tokens(*texts: str) -> list[str]:
        merged = " ".join(str(text or "") for text in texts if str(text or "").strip())
        if not merged:
            return []
        patterns = (
            r"\b\d+\s*/\s*\d+\b",
            r"\b\d+(?:\.\d+)?\s*%\b",
            r"\b\d+(?:\.\d+)?x\b",
            r"\bx\d+(?:\.\d+)?\b",
            r"\+\d+\b",
            r"-\d+\b",
        )
        out: list[str] = []
        for pattern in patterns:
            for match in re.findall(pattern, merged, flags=re.IGNORECASE):
                token = re.sub(r"\s+", "", str(match))
                if token not in out:
                    out.append(token)
        return out

    @staticmethod
    def _split_function_stat_blob(stat_blob: str) -> list[str]:
        remaining = str(stat_blob or "").strip()
        if not remaining:
            return []
        out: list[str] = []
        while remaining:
            matched = False
            for token, label in FUNCTION_STAT_TOKEN_LABELS:
                if remaining.startswith(token):
                    if label not in out:
                        out.append(label)
                    remaining = remaining[len(token):]
                    matched = True
                    break
            if not matched:
                return []
        return out

    def _move_function_hint(self, function_code: str) -> str:
        code = str(function_code or "").strip()
        if not code or code.upper() == "NONE":
            return ""
        exact = MOVE_FUNCTION_EXACT_HINTS.get(code)
        if exact:
            return exact

        stat_match = re.match(
            r"^(Raise|Lower)(User|Target|Allies|GrassBattlers|GroundedGrassBattlers|PlusMinusUserAndAllies)"
            r"([A-Za-z]+?)(\d)(.*)$",
            code,
        )
        if stat_match:
            action, subject_code, stat_blob, stages_raw, suffix = stat_match.groups()
            stats = self._split_function_stat_blob(stat_blob)
            if stats:
                subject_map = {
                    "User": "user",
                    "Target": "target",
                    "Allies": "all allies",
                    "GrassBattlers": "Grass-type battlers",
                    "GroundedGrassBattlers": "grounded Grass-type battlers",
                    "PlusMinusUserAndAllies": "user and allies with Plus/Minus",
                }
                subject = subject_map.get(subject_code, "affected battlers")
                stage_count = int(stages_raw)
                stage_word = "stage" if stage_count == 1 else "stages"
                verb = "Raises" if action == "Raise" else "Lowers"
                line = f"{verb} {self._join_with_and(stats)} of {subject} by {stage_count} {stage_word}."
                if suffix:
                    line += " Additional conditional effect applies."
                return line

        if "HalfOfTotalHP" in code:
            return "Uses a 1/2 max HP formula in its effect logic."
        if "QuarterOfTotalHP" in code:
            return "Uses a 1/4 max HP formula in its effect logic."
        if "ThirdOfTotalHP" in code:
            return "Uses a 1/3 max HP formula in its effect logic."
        if "ByHalfOfDamageDone" in code:
            return "Uses healing equal to 1/2 of damage dealt."
        if "ByThreeQuartersOfDamageDone" in code:
            return "Uses healing equal to 3/4 of damage dealt."
        if "RecoilHalfOfDamageDealt" in code:
            return "Uses recoil equal to 1/2 of damage dealt."
        if "RecoilThirdOfDamageDealt" in code:
            return "Uses recoil equal to 1/3 of damage dealt."
        if "RecoilQuarterOfDamageDealt" in code:
            return "Uses recoil equal to 1/4 of damage dealt."
        if "PowerHigherWith" in code or "PowerLowerWith" in code:
            return "Power is variable and scales with battle conditions."
        return ""

    def _move_numeric_summary_lines(self, move_id: str, raw_desc: str, english_desc: str) -> list[str]:
        if not self.catalogs or not move_id:
            return []
        canonical = self.catalogs.canonical_move_id(move_id) or move_id
        move = self.catalogs.moves_by_id.get(canonical)
        if not move:
            return []
        lines: list[str] = []

        power_raw = str(move.extra.get("Power", "")).strip()
        if power_raw:
            try:
                power = int(power_raw)
                lines.append(f"Base power: {power}.")
            except ValueError:
                pass

        accuracy_raw = str(move.extra.get("Accuracy", "")).strip()
        if accuracy_raw:
            try:
                accuracy = int(float(accuracy_raw))
                if accuracy <= 0:
                    lines.append("Accuracy: no standard accuracy roll (self-target or guaranteed effect).")
                else:
                    lines.append(f"Accuracy: {accuracy}%.")
            except ValueError:
                pass

        pp_raw = str(move.extra.get("TotalPP", move.extra.get("PP", ""))).strip()
        if pp_raw:
            try:
                lines.append(f"Base PP: {int(pp_raw)}.")
            except ValueError:
                pass

        priority_raw = str(move.extra.get("Priority", "")).strip()
        if priority_raw:
            try:
                priority = int(priority_raw)
                if priority:
                    sign = "+" if priority > 0 else ""
                    lines.append(f"Priority: {sign}{priority}.")
            except ValueError:
                pass

        function_code = str(move.extra.get("FunctionCode", "")).strip()
        function_hint = self._move_function_hint(function_code)
        if function_hint:
            lines.append(function_hint)
        if function_code and function_code.upper() != "NONE":
            lines.append(f"Internal function code: {function_code}.")

        numeric_tokens = self._extract_numeric_tokens(raw_desc, english_desc)
        if numeric_tokens:
            lines.append(f"Numeric values detected in description text: {', '.join(numeric_tokens)}.")
        return self._dedupe_preserve(lines)

    def _item_numeric_summary_lines(self, item_id: str, raw_desc: str, english_desc: str) -> list[str]:
        if not self.catalogs or not item_id:
            return []
        canonical = self.catalogs.canonical_item_id(item_id) or item_id
        item = self.catalogs.items_by_id.get(canonical)
        if not item:
            return []
        lines: list[str] = []

        known = ITEM_NUMERIC_HINTS.get(canonical)
        if known:
            lines.append(known)

        flags = str(item.extra.get("Flags", "")).strip()
        fling_match = re.search(r"\bFling[_\s-]?(\d+)\b", flags, flags=re.IGNORECASE)
        if fling_match:
            lines.append(f"Fling base power: {int(fling_match.group(1))}.")

        numeric_tokens = self._extract_numeric_tokens(raw_desc, english_desc)
        if numeric_tokens:
            lines.append(f"Numeric values detected in description text: {', '.join(numeric_tokens)}.")
        return self._dedupe_preserve(lines)

    def _ability_numeric_summary_lines(self, ability_id: str, raw_desc: str, english_desc: str) -> list[str]:
        if not self.catalogs or not ability_id:
            return []
        canonical = self.catalogs.canonical_ability_id(ability_id) or ability_id
        ability = self.catalogs.abilities_by_id.get(canonical)
        if not ability:
            return []
        lines: list[str] = []

        known = ABILITY_NUMERIC_HINTS.get(canonical)
        if known:
            lines.append(known)

        numeric_tokens = self._extract_numeric_tokens(raw_desc, english_desc)
        if numeric_tokens:
            lines.append(f"Numeric values detected in description text: {', '.join(numeric_tokens)}.")
        return self._dedupe_preserve(lines)

    def _generated_move_flavor_description(self, move_id: str) -> str:
        if not self.catalogs or not move_id:
            return ""
        canonical = self.catalogs.canonical_move_id(move_id) or str(move_id or "").strip().lstrip(":")
        move = self.catalogs.moves_by_id.get(canonical)
        if not move:
            return ""
        type_id = str(move.extra.get("Type", "")).strip().lstrip(":")
        category_id = str(move.extra.get("Category", "")).strip().lstrip(":")
        target_id = str(move.extra.get("Target", "")).strip().lstrip(":")
        type_label = self._prettify_internal_id(type_id) if type_id else ""
        category_label = self._prettify_internal_id(category_id) if category_id else ""
        target_label = self._prettify_internal_id(target_id) if target_id else ""
        parts: list[str] = []
        if type_label and category_label:
            parts.append(f"{type_label}-type {category_label.lower()} move.")
        elif type_label:
            parts.append(f"{type_label}-type move.")
        elif category_label:
            parts.append(f"{category_label} move.")
        if target_label:
            parts.append(f"Target: {target_label}.")
        return " ".join(parts).strip()

    def _resolve_entity_description(
        self,
        kind: str,
        entity_id: str,
        raw_desc: str,
        summary_lines: list[str],
    ) -> tuple[str, list[str]]:
        cleaned = [str(line or "").strip() for line in summary_lines if str(line or "").strip()]
        base_desc = self._english_description(raw_desc, "")
        if kind == "move" and base_desc:
            base_desc = self._sanitize_move_description_text(base_desc)
            if self._is_low_quality_move_description(base_desc):
                base_desc = ""
        if not base_desc:
            if kind == "move":
                base_desc = self._generated_move_flavor_description(entity_id)
            if not base_desc and cleaned:
                base_desc = cleaned[0]
            if not base_desc and kind == "ability":
                base_desc = "No ability description exists in the current game data."
            if not base_desc and kind == "item":
                base_desc = "No item description exists in the current game data."
        base_norm = base_desc.strip().casefold() if base_desc else ""
        if base_norm:
            cleaned = [line for line in cleaned if line.strip().casefold() != base_norm]
        return base_desc.strip(), cleaned

    @staticmethod
    def _append_mechanics_block(description: str, summary_lines: list[str]) -> str:
        lines = [str(line or "").strip() for line in summary_lines if str(line or "").strip()]
        if not lines:
            return description
        block = "Mechanics (Known):\n" + "\n".join(f"- {line}" for line in lines)
        base = str(description or "").strip()
        if not base:
            return block
        return f"{base}\n\n{block}"

    def _evolution_condition_param_label(self, category: str, value: str) -> str:
        raw = str(value or "").strip().lstrip(":")
        if not raw:
            return ""
        cat = str(category or "").strip().lower()
        if not self.catalogs:
            return self._prettify_internal_id(raw)
        if cat == "item":
            canonical = self.catalogs.canonical_item_id(raw) or raw
            return self._dex_item_display_name(canonical)
        if cat == "move":
            canonical = self.catalogs.canonical_move_id(raw) or raw
            return self._dex_display_name_for_entry("Moves", canonical)
        if cat == "species":
            canonical = self.catalogs.canonical_species_id(raw) or raw
            return self._dex_display_name_for_entry("Species", canonical)
        return self._prettify_internal_id(raw)

    def _evolution_condition_text(self, method: str, param: str) -> str:
        method_key = (method or "").strip().upper()
        value = (param or "").strip()
        if method_key == "LEVEL":
            return f"Level {value or '?'}"
        if method_key == "LEVELMALE":
            return f"Level {value or '?'} (male)"
        if method_key == "LEVELFEMALE":
            return f"Level {value or '?'} (female)"
        if method_key == "ITEM":
            item = self._evolution_condition_param_label("item", value)
            return f"Use {item}" if item else "Use required item"
        if method_key == "ITEMFEMALE":
            item = self._evolution_condition_param_label("item", value)
            return f"Use {item} (female)" if item else "Use required item (female)"
        if method_key == "DAYHOLDITEM":
            item = self._evolution_condition_param_label("item", value)
            return f"Level up in daytime while holding {item}" if item else "Level up in daytime while holding required item"
        if method_key == "TRADEITEM":
            item = self._evolution_condition_param_label("item", value)
            return f"Trade while holding {item}" if item else "Trade while holding required item"
        if method_key == "TRADE":
            return "Trade"
        if method_key == "TRADESPECIES":
            species = self._evolution_condition_param_label("species", value)
            return f"Trade for {species}" if species else "Trade for specific species"
        if method_key == "LINKINGCORD":
            return "Use Linking Cord"
        if method_key == "HAPPINESS":
            return "High friendship"
        if method_key == "HAPPINESSDAY":
            return "High friendship\n(day time)"
        if method_key == "HAPPINESSNIGHT":
            return "High friendship\n(night time)"
        if method_key == "HASMOVE":
            move = self._evolution_condition_param_label("move", value)
            return f"Know move {move}" if move else "Know required move"
        if method_key == "HASINPARTY":
            species = self._evolution_condition_param_label("species", value)
            return f"Have {species} in party" if species else "Have required Pokemon in party"
        if method_key == "ATTACKGREATER":
            return f"Level {value or '?'} with Atk > Def"
        if method_key == "DEFENSEGREATER":
            return f"Level {value or '?'} with Def > Atk"
        if method_key == "ATKDEFEQUAL":
            return f"Level {value or '?'} with Atk = Def"
        if method_key == "SYLVEON":
            return "Level up with high friendship and a Fairy-type move"
        if method_key == "CASCOON":
            return "Level up (Cascoon branch)"
        if method_key == "SILCOON":
            return "Level up (Silcoon branch)"
        if method_key == "NINJASK":
            return "Level up (Ninjask branch)"
        if method_key == "SHEDINJA":
            return "Level up with empty party slot and a Poke Ball (Shedinja branch)"
        if not method_key:
            return "Unknown condition"
        pretty = self._prettify_internal_id(method_key)
        val = self._prettify_internal_id(value)
        return f"{pretty}: {val}".strip(": ")

    def _species_evolution_description(self, species_id: str, form: int) -> str:
        if not self.catalogs or not species_id:
            return "Evolution family: No evolution chain data."
        edges = self.catalogs.species_evolution_family_edges(species_id, form=form)
        if not edges:
            return "Evolution family: No evolution chain data."
        children: dict[str, list[tuple[str, str]]] = {}
        parents: dict[str, set[str]] = {}
        nodes: set[str] = set()
        for source, target, conds in edges:
            condition_texts = [self._evolution_condition_text(method, param) for method, param in conds]
            condition_texts = list(dict.fromkeys([t for t in condition_texts if t]))
            condition = " OR ".join(condition_texts) if condition_texts else "Unknown condition"
            children.setdefault(source, []).append((target, condition))
            parents.setdefault(target, set()).add(source)
            nodes.add(source)
            nodes.add(target)
        for source in list(children.keys()):
            children[source].sort(key=lambda row: (row[0].casefold(), row[1].casefold()))
        roots = sorted([n for n in nodes if not parents.get(n)], key=str.casefold)
        if not roots:
            roots = sorted(nodes, key=str.casefold)

        selected = species_id.strip().lstrip(":").upper()
        lines = ["Evolution family chain:"]

        def walk(node: str, prefix: str, edge_label: str, is_last: bool, path: set[str]):
            marker = "* " if node.upper() == selected else ""
            if prefix:
                connector = "\\- " if is_last else "|- "
                label = f" [{edge_label}]" if edge_label else ""
                lines.append(f"{prefix}{connector}{marker}{node}{label}")
            else:
                lines.append(f"{marker}{node}")

            if node in path:
                lines.append(f"{prefix}{'   ' if is_last else '|  '}\\- (cycle truncated)")
                return
            next_path = set(path)
            next_path.add(node)

            next_prefix = prefix + ("   " if is_last else "|  ")
            kids = children.get(node, [])
            for idx, (child, cond) in enumerate(kids):
                child_last = idx == len(kids) - 1
                walk(child, next_prefix, cond, child_last, next_path)

        for idx, root in enumerate(roots):
            walk(root, "", "", idx == len(roots) - 1, set())
            if idx != len(roots) - 1:
                lines.append("")
        return "\n".join(lines)

    def _chart_scaled_image(self, img: tk.PhotoImage, cache_key: str, factor: int) -> tk.PhotoImage:
        if factor <= 1:
            return img
        key = f"{cache_key}:{factor}"
        cached = self._party_evo_scaled_icon_cache.get(key)
        if cached is not None:
            return cached
        try:
            out = img.subsample(factor, factor)
        except Exception:
            out = img
        self._party_evo_scaled_icon_cache[key] = out
        return out

    def _evolution_edge_item_id(self, conditions: list[tuple[str, str]]) -> str:
        if not self.catalogs:
            return ""
        for method, param in conditions:
            method_key = str(method or "").strip().upper()
            value = str(param or "").strip().lstrip(":")
            if method_key == "LINKINGCORD":
                return self.catalogs.canonical_item_id("LINKINGCORD") or "LINKINGCORD"
            if method_key in {"ITEM", "ITEMMALE", "ITEMFEMALE", "USEITEM", "TRADEITEM", "DAYHOLDITEM"} and value:
                return self.catalogs.canonical_item_id(value) or value
        return ""

    def _evolution_edge_short_text(self, conditions: list[tuple[str, str]], item_id: str) -> str:
        _ = item_id
        labels: list[str] = []
        for method, param in conditions:
            text = self._evolution_condition_text(method, param)
            if not text:
                continue
            labels.append(text)
        labels = list(dict.fromkeys(labels))
        out = " + ".join(labels)
        if len(out) > 160:
            out = f"{out[:157]}..."
        return out

    @staticmethod
    def _estimate_wrapped_line_count(text: str, max_chars: int = 28) -> int:
        raw = " ".join(str(text or "").split())
        if not raw:
            return 0
        width = max(8, int(max_chars))
        words = raw.split(" ")
        lines = 1
        line_len = 0
        for word in words:
            wlen = len(word)
            if line_len == 0:
                line_len = wlen
                continue
            if line_len + 1 + wlen <= width:
                line_len += 1 + wlen
            else:
                lines += 1
                line_len = wlen
        return max(1, lines)

    def _evolution_condition_line_count(
        self,
        conditions: list[tuple[str, str]],
        target_node: str | None = None,
    ) -> int:
        _ = target_node
        item_id = self._evolution_edge_item_id(conditions)
        text = self._evolution_edge_short_text(conditions, item_id)
        return self._estimate_wrapped_line_count(text, max_chars=30)

    @staticmethod
    def _filter_evolution_edges_for_selected_species(
        selected_species_id: str,
        edges: list[tuple[str, str, list[tuple[str, str]]]],
    ) -> tuple[list[tuple[str, str, list[tuple[str, str]]]], set[str]]:
        selected = str(selected_species_id or "").strip()
        if not edges:
            return [], {selected} if selected else set()

        all_nodes: set[str] = set()
        for source, target, _conditions in edges:
            all_nodes.add(source)
            all_nodes.add(target)
        if selected:
            all_nodes.add(selected)

        selected_upper = selected.upper()
        selected_outgoing = sum(1 for source, _target, _conditions in edges if source.upper() == selected_upper)
        # If selected species is a branch point itself (ex: Eevee), keep full family chart.
        if selected_outgoing >= 2:
            return list(edges), all_nodes

        children: dict[str, set[str]] = {}
        parents: dict[str, set[str]] = {}
        for source, target, _conditions in edges:
            children.setdefault(source, set()).add(target)
            parents.setdefault(target, set()).add(source)

        start_nodes = [node for node in all_nodes if node.upper() == selected_upper]
        if not start_nodes and selected:
            start_nodes = [selected]

        ancestors: set[str] = set(start_nodes)
        stack = list(start_nodes)
        while stack:
            current = stack.pop()
            for prev in parents.get(current, set()):
                if prev not in ancestors:
                    ancestors.add(prev)
                    stack.append(prev)

        descendants: set[str] = set(start_nodes)
        stack = list(start_nodes)
        while stack:
            current = stack.pop()
            for nxt in children.get(current, set()):
                if nxt not in descendants:
                    descendants.add(nxt)
                    stack.append(nxt)

        keep_nodes = ancestors | descendants
        if selected:
            keep_nodes.add(selected)
        if not keep_nodes:
            keep_nodes = {selected} if selected else set()

        filtered_edges = [(source, target, conds) for source, target, conds in edges if source in keep_nodes and target in keep_nodes]
        return filtered_edges, keep_nodes

    def update_party_evolution_chart(self):
        if not hasattr(self, "party_evo_canvas"):
            return
        if self._party_evo_rendering:
            return
        self._party_evo_rendering = True
        species_raw = self.pk_species_var.get().strip()
        try:
            form = int(self.pk_form_var.get().strip()) if self.pk_form_var.get().strip() else 0
        except ValueError:
            form = 0
        try:
            rendered_height = self._render_evolution_chart_to_canvas(
                self.party_evo_canvas,
                species_raw,
                form,
                no_species_text="Choose a species to view evolution chart.",
                invalid_species_text="Choose a valid species to view evolution chart.",
                show_all_conditions=True,
            )
            try:
                target_height = max(220, int(rendered_height))
            except Exception:
                target_height = 220
            try:
                current_height = int(float(self.party_evo_canvas.cget("height")))
            except Exception:
                current_height = 0
            if abs(current_height - target_height) >= 2:
                try:
                    self.party_evo_canvas.configure(height=target_height)
                except Exception:
                    pass
        finally:
            self._party_evo_rendering = False

    def _render_evolution_chart_to_canvas(
        self,
        canvas: tk.Canvas,
        species_raw: str,
        form: int = 0,
        no_species_text: str = "Choose a species to view evolution chart.",
        invalid_species_text: str = "Choose a valid species to view evolution chart.",
        show_all_conditions: bool = False,
    ) -> int:
        if canvas is None:
            return 220
        old_top = canvas.yview()[0] if str(canvas.cget("scrollregion")).strip() else 0.0
        canvas.delete("all")

        canvas_key = str(canvas)
        if not hasattr(self, "_evo_canvas_image_refs"):
            self._evo_canvas_image_refs = {}
        refs = self._evo_canvas_image_refs.setdefault(canvas_key, [])
        refs.clear()
        previous_refs = self._party_evo_canvas_image_refs
        self._party_evo_canvas_image_refs = refs
        previous_show_all = bool(getattr(self, "_evo_chart_show_all_conditions", False))
        self._evo_chart_show_all_conditions = bool(show_all_conditions)

        try:
            try:
                canvas.update_idletasks()
            except Exception:
                pass
            width = max(340, canvas.winfo_width())
            viewport_height = max(220, canvas.winfo_height())
            section_margin = 20

            def _reset_view():
                canvas.configure(scrollregion=(0, 0, width, viewport_height))
                canvas.yview_moveto(0.0)

            if not self.catalogs:
                canvas.create_text(8, 8, anchor="nw", text="No game data loaded.")
                _reset_view()
                return viewport_height

            species_text = str(species_raw or "").strip()
            if not species_text:
                canvas.create_text(8, 8, anchor="nw", text=no_species_text)
                _reset_view()
                return viewport_height

            try:
                species_id = self.resolve_species_id(species_text)
            except Exception:
                species_id = extract_internal_id(species_text).strip().lstrip(":")
                if not species_id:
                    canvas.create_text(8, 8, anchor="nw", text=invalid_species_text)
                    _reset_view()
                    return viewport_height

            all_edges = self.catalogs.species_evolution_family_edges(species_id, form=form)
            edges, nodes = self._filter_evolution_edges_for_selected_species(species_id, all_edges)
            undirected_neighbors: dict[str, set[str]] = {}
            direct_children: dict[str, set[str]] = {}
            outgoing_counts: dict[str, int] = {}
            for source, target, _conditions in edges:
                undirected_neighbors.setdefault(source, set()).add(target)
                undirected_neighbors.setdefault(target, set()).add(source)
                direct_children.setdefault(source, set()).add(target)
                outgoing_counts[source] = outgoing_counts.get(source, 0) + 1

            root_branch_count = sum(1 for source, _target, _conds in edges if source.upper() == species_id.upper())
            max_branch_count = max(outgoing_counts.values()) if outgoing_counts else 0
            hub_species_id = species_id
            if max_branch_count > 4:
                hub_species_id = min(
                    (src for src, cnt in outgoing_counts.items() if cnt == max_branch_count),
                    key=str.casefold,
                )
            chart_branch_count = outgoing_counts.get(hub_species_id, root_branch_count)
            node_size = 32
            node_half = node_size // 2
            # Height follows chart content (not viewport), with visible margins.
            base_height = self._estimate_party_evolution_height(chart_branch_count, 320)
            height = max(220, base_height + (section_margin * 2))
            if max_branch_count > 4:
                cluster_count = (chart_branch_count + 3) // 4
                split_cols = self._split_chart_columns_for_width(cluster_count, width, node_half)
                split_rows = (cluster_count + split_cols - 1) // max(1, split_cols)
                root_edge_lines = 1
                if bool(show_all_conditions):
                    for source, target, conds in edges:
                        if source.upper() != hub_species_id.upper():
                            continue
                        root_edge_lines = max(root_edge_lines, self._evolution_condition_line_count(conds, target_node=target))
                line_extra = max(0, root_edge_lines - 1) * 16
                row_height = 268 + line_extra
                needed = (split_rows * row_height) + ((split_rows + 1) * section_margin)
                height = max(height, needed)

            center_degree = len(undirected_neighbors.get(species_id, set()))
            if max_branch_count > 4:
                # Multi-branch species must always use clustered layout.
                if self._draw_split_center_evolution_chart(
                    canvas,
                    hub_species_id,
                    nodes,
                    edges,
                    width,
                    height,
                    node_half,
                    focus_species_id=species_id,
                ):
                    canvas.configure(scrollregion=(0, 0, width, height))
                    canvas.yview_moveto(min(max(old_top, 0.0), 1.0) if height > viewport_height else 0.0)
                    return height
            elif self._draw_branch_bus_evolution_chart(
                canvas,
                species_id,
                nodes,
                edges,
                width,
                height,
                node_half,
                focus_species_id=species_id,
            ):
                canvas.configure(scrollregion=(0, 0, width, height))
                canvas.yview_moveto(min(max(old_top, 0.0), 1.0) if height > viewport_height else 0.0)
                return height

            has_multi_branch = center_degree >= 4 or any(len(v) >= 4 for v in direct_children.values())
            use_radial = has_multi_branch or len(nodes) >= 12

            if use_radial:
                positions = self._radial_evolution_positions(nodes, edges, species_id, width, height, node_half)
            else:
                positions = self._layered_evolution_positions(nodes, edges, species_id, width, height, node_half)

            if root_branch_count <= 4:
                positions = self._compress_positions_horizontally(positions, width, node_half, ratio=0.70)

            self._draw_evolution_edges(canvas, edges, positions, node_half)
            self._draw_evolution_nodes(canvas, positions, species_id, node_half, height)
            canvas.configure(scrollregion=(0, 0, width, height))
            canvas.yview_moveto(min(max(old_top, 0.0), 1.0) if height > viewport_height else 0.0)
            return height
        finally:
            self._evo_chart_show_all_conditions = previous_show_all
            if hasattr(self, "party_evo_canvas") and canvas == self.party_evo_canvas:
                self._party_evo_canvas_image_refs = refs
            else:
                self._party_evo_canvas_image_refs = previous_refs

    @staticmethod
    def _compress_positions_horizontally(
        positions: dict[str, tuple[int, int]],
        width: int,
        node_half: int,
        ratio: float,
    ) -> dict[str, tuple[int, int]]:
        if not positions:
            return positions
        safe_ratio = max(0.1, min(1.0, float(ratio)))
        if safe_ratio >= 0.999:
            return positions
        cx = width // 2
        min_x = node_half + 10
        max_x = width - node_half - 10
        out: dict[str, tuple[int, int]] = {}
        for node, (x, y) in positions.items():
            nx = cx + int((x - cx) * safe_ratio)
            nx = max(min_x, min(max_x, nx))
            out[node] = (nx, y)
        return out

    def _layered_evolution_positions(
        self,
        nodes: set[str],
        edges: list[tuple[str, str, list[tuple[str, str]]]],
        species_id: str,
        width: int,
        height: int,
        node_half: int,
    ) -> dict[str, tuple[int, int]]:
        parents: dict[str, set[str]] = {}
        for source, target, _conditions in edges:
            parents.setdefault(target, set()).add(source)

        level_cache: dict[str, int] = {}

        def compute_level(node: str, path: set[str]) -> int:
            if node in level_cache:
                return level_cache[node]
            if node in path:
                return 0
            prev = parents.get(node, set())
            if not prev:
                lvl = 0
            else:
                lvl = 1 + max(compute_level(parent, path | {node}) for parent in prev)
            level_cache[node] = lvl
            return lvl

        for node in nodes:
            compute_level(node, set())

        unique_levels = sorted(set(level_cache.values()))
        if not unique_levels:
            unique_levels = [0]
        remap = {lvl: idx for idx, lvl in enumerate(unique_levels)}
        grouped: dict[int, list[str]] = {}
        for node in nodes:
            grouped.setdefault(remap.get(level_cache.get(node, 0), 0), []).append(node)
        for lvl, arr in grouped.items():
            arr.sort(key=lambda n: (n.upper() != species_id.upper(), n.casefold()))
            grouped[lvl] = arr

        margin_x = 26
        margin_y = 20
        label_space = 20
        level_ids = sorted(grouped.keys())
        if not level_ids:
            level_ids = [0]
            grouped[0] = [species_id]
        col_count = len(level_ids)
        x_for_level: dict[int, int] = {}
        if col_count == 1:
            x_for_level[level_ids[0]] = width // 2
        else:
            span = max(1, width - (2 * margin_x))
            for idx, lvl in enumerate(level_ids):
                x_for_level[lvl] = margin_x + int((idx * span) / (col_count - 1))

        positions: dict[str, tuple[int, int]] = {}
        y_top = margin_y + node_half
        y_bottom = max(y_top, height - margin_y - label_space - node_half)
        for lvl in level_ids:
            arr = grouped.get(lvl, [])
            if not arr:
                continue
            if len(arr) == 1:
                ys = [int((y_top + y_bottom) / 2)]
            else:
                step = (y_bottom - y_top) / (len(arr) - 1)
                ys = [int(y_top + (idx * step)) for idx in range(len(arr))]
            x = x_for_level[lvl]
            for node, y in zip(arr, ys):
                positions[node] = (x, y)
        return positions

    def _radial_evolution_positions(
        self,
        nodes: set[str],
        edges: list[tuple[str, str, list[tuple[str, str]]]],
        species_id: str,
        width: int,
        height: int,
        node_half: int,
    ) -> dict[str, tuple[int, int]]:
        center_x = width // 2
        center_y = height // 2
        positions: dict[str, tuple[int, int]] = {species_id: (center_x, center_y)}

        neighbors: dict[str, set[str]] = {}
        for source, target, _conditions in edges:
            neighbors.setdefault(source, set()).add(target)
            neighbors.setdefault(target, set()).add(source)

        distance: dict[str, int] = {species_id: 0}
        queue: list[str] = [species_id]
        while queue:
            current = queue.pop(0)
            for nxt in sorted(neighbors.get(current, set()), key=str.casefold):
                if nxt in distance:
                    continue
                distance[nxt] = distance[current] + 1
                queue.append(nxt)

        if nodes:
            max_d = max(distance.values()) if distance else 0
            for node in sorted(nodes, key=str.casefold):
                if node not in distance:
                    max_d += 1
                    distance[node] = max_d

        grouped: dict[int, list[str]] = {}
        for node, d in distance.items():
            if d <= 0:
                continue
            grouped.setdefault(d, []).append(node)

        max_radius = max(110, min(width, height) // 2 - (node_half + 20))
        ring_step = 110
        ring_cursor = 0
        for d in sorted(grouped.keys()):
            nodes_in_ring = sorted(grouped[d], key=str.casefold)
            if not nodes_in_ring:
                continue
            radius = min(max_radius, 102 + ((d - 1) * ring_step))
            remaining = list(nodes_in_ring)
            while remaining:
                circumference = max(1.0, 2.0 * math.pi * max(radius, 1))
                capacity = max(5, int(circumference / 98.0))
                take = max(1, min(len(remaining), capacity))
                segment = remaining[:take]
                remaining = remaining[take:]
                start_angle = -90.0 + (ring_cursor * 14.0)
                step = 360.0 / max(1, len(segment))
                for idx, node in enumerate(segment):
                    ang = math.radians(start_angle + (idx * step))
                    x = int(center_x + (radius * math.cos(ang)))
                    y = int(center_y + (radius * math.sin(ang)))
                    x = max(node_half + 10, min(width - node_half - 10, x))
                    y = max(node_half + 10, min(height - node_half - 20, y))
                    positions[node] = (x, y)
                ring_cursor += 1
                if len(remaining) > 0:
                    radius = min(max_radius, radius + 72)
        return positions

    @staticmethod
    def _split_branch_targets_balanced(targets: list[str], max_per_cluster: int = 4) -> list[list[str]]:
        if not targets:
            return []
        max_cap = max(1, int(max_per_cluster))
        cluster_count = (len(targets) + max_cap - 1) // max_cap
        base = len(targets) // cluster_count
        extra = len(targets) % cluster_count
        sizes = [base + (1 if i < extra else 0) for i in range(cluster_count)]
        out: list[list[str]] = []
        cursor = 0
        for size in sizes:
            out.append(targets[cursor : cursor + size])
            cursor += size
        return out

    def _draw_single_evolution_edge(
        self,
        canvas: tk.Canvas,
        sx: int,
        sy: int,
        tx: int,
        ty: int,
        conditions: list[tuple[str, str]],
        node_half: int,
        show_condition_text: bool = True,
        target_node: str | None = None,
    ):
        dx = tx - sx
        dy = ty - sy
        dist = math.sqrt((dx * dx) + (dy * dy))
        if dist <= 0.0:
            return
        ux = dx / dist
        uy = dy / dist
        start_x = sx + int(ux * (node_half + 3))
        start_y = sy + int(uy * (node_half + 3))
        end_x = tx - int(ux * (node_half + 3))
        end_y = ty - int(uy * (node_half + 3))
        canvas.create_line(start_x, start_y, end_x, end_y, arrow=tk.LAST, width=2, fill="#666666")
        mid_x = int((start_x + end_x) / 2)
        mid_y = int((start_y + end_y) / 2)
        item_id = self._evolution_edge_item_id(conditions)
        time_marker = self._evolution_edge_time_marker(conditions, target_node)

        edge_icons: list[tuple[str, Any]] = []
        icon_half_span = 0
        has_item_icon = False
        if item_id:
            item_img = self._get_item_icon_image(item_id)
            if item_img is not None:
                scaled_item = self._chart_scaled_image(item_img, f"evo_item:{item_id}", 2 if item_img.width() >= 40 else 1)
                self._party_evo_canvas_image_refs.append(scaled_item)
                edge_icons.append(("item", scaled_item))
                icon_half_span = max(icon_half_span, max(scaled_item.width(), scaled_item.height()) // 2 + 2)
                has_item_icon = True
        if time_marker:
            edge_icons.append(("time", time_marker))
            icon_half_span = max(icon_half_span, 9)

        if edge_icons:
            icon_gap = 22
            start_icon_x = mid_x - int(((len(edge_icons) - 1) * icon_gap) / 2)
            for idx, (icon_kind, payload) in enumerate(edge_icons):
                icon_x = start_icon_x + (idx * icon_gap)
                icon_y = mid_y
                if icon_kind == "item":
                    assert isinstance(payload, tk.PhotoImage)
                    half = max(8, max(payload.width(), payload.height()) // 2 + 2)
                    self._draw_evolution_marker_badge(canvas, icon_x, icon_y, half=half)
                    canvas.create_image(icon_x, icon_y, image=payload)
                    continue
                marker_kind = str(payload)
                if marker_kind == "day":
                    self._draw_sun_marker(canvas, icon_x, icon_y)
                else:
                    self._draw_moon_marker(canvas, icon_x, icon_y)

        if not show_condition_text:
            return
        force_show_all = bool(getattr(self, "_evo_chart_show_all_conditions", False))
        if not force_show_all and (item_id or time_marker):
            return
        cond_text = self._evolution_edge_short_text(conditions, item_id)
        if not cond_text:
            return
        wrap_width_px = 170
        lines = self._estimate_wrapped_line_count(cond_text, max_chars=30)
        text_x = mid_x
        if has_item_icon:
            # Keep text as close as possible to item icon without touching it.
            text_y = mid_y + icon_half_span + 2
        elif icon_half_span > 0:
            # Non-item markers still keep a minimal non-overlap gap from marker icon.
            text_y = mid_y + icon_half_span + 2
        else:
            # No icon: keep text close to the arrow line without touching.
            text_y = mid_y + 4
        tid = canvas.create_text(
            text_x,
            text_y,
            text=cond_text,
            fill="#555555",
            font=("", 8),
            anchor="n",
            justify="center",
            width=wrap_width_px,
        )
        if lines > 0:
            bbox = canvas.bbox(tid)
            if bbox:
                bg = str(canvas.cget("bg") or "#fbfbfb")
                rect = canvas.create_rectangle(
                    bbox[0] - 2,
                    bbox[1] - 1,
                    bbox[2] + 2,
                    bbox[3] + 1,
                    fill=bg,
                    outline="",
                )
                canvas.tag_raise(tid, rect)

    def _draw_evolution_marker_badge(self, canvas: tk.Canvas, x: int, y: int, half: int = 9):
        bg = str(canvas.cget("bg") or "#fbfbfb")
        r = max(6, int(half))
        canvas.create_rectangle(x - r, y - r, x + r, y + r, fill=bg, outline="#c8c8c8", width=1)

    def _draw_sun_marker(self, canvas: tk.Canvas, x: int, y: int):
        self._draw_evolution_marker_badge(canvas, x, y, half=9)
        r = 5
        canvas.create_oval(x - r, y - r, x + r, y + r, fill="#f3c623", outline="#b98500", width=1)
        for idx in range(8):
            ang = (idx * math.pi) / 4.0
            x1 = x + int(math.cos(ang) * (r + 2))
            y1 = y + int(math.sin(ang) * (r + 2))
            x2 = x + int(math.cos(ang) * (r + 4))
            y2 = y + int(math.sin(ang) * (r + 4))
            canvas.create_line(x1, y1, x2, y2, fill="#b98500", width=1)

    def _draw_moon_marker(self, canvas: tk.Canvas, x: int, y: int):
        self._draw_evolution_marker_badge(canvas, x, y, half=9)
        r = 6
        bg = str(canvas.cget("bg") or "#fbfbfb")
        canvas.create_oval(x - r, y - r, x + r, y + r, fill="#7296df", outline="#4f6ea8", width=1)
        canvas.create_oval(x - r + 3, y - r - 1, x + r - 1, y + r - 1, fill=bg, outline=bg)

    @staticmethod
    def _evolution_edge_time_marker(conditions: list[tuple[str, str]], target_node: str | None = None) -> str:
        for method, _param in conditions:
            key = str(method or "").strip().upper()
            if key == "HAPPINESSDAY":
                return "day"
            if key == "HAPPINESSNIGHT":
                return "night"
            if key == "DAYHOLDITEM":
                return "day"
        target = str(target_node or "").strip().upper()
        if target == "ESPEON":
            return "day"
        if target == "UMBREON":
            return "night"
        return ""

    def _draw_single_evolution_node(
        self,
        canvas: tk.Canvas,
        node: str,
        x: int,
        y: int,
        selected: bool,
        node_half: int,
        canvas_height: int,
        label_anchor: tuple[int, int] | None = None,
    ):
        _ = label_anchor  # label is intentionally tied directly to its own icon
        left = x - node_half - 2
        top = y - node_half - 2
        right = x + node_half + 2
        bottom = y + node_half + 2
        canvas.create_rectangle(
            left,
            top,
            right,
            bottom,
            outline="#e3a100" if selected else "#9a9a9a",
            width=2 if selected else 1,
            fill="#ffffff",
        )
        icon = self._get_party_icon_image_for_fields(node, form=0, shiny=False)
        if icon is not None:
            scaled_icon = self._chart_scaled_image(icon, f"evo_node:{node}", 2 if icon.width() >= 56 else 1)
            self._party_evo_canvas_image_refs.append(scaled_icon)
            canvas.create_image(x, y, image=scaled_icon)
        else:
            canvas.create_text(x, y, text=node[:2], font=("", 8, "bold"), fill="#333333")
        canvas_width = max(1, int(canvas.winfo_width()))
        label_margin_x = 54
        label_x = max(label_margin_x, min(canvas_width - label_margin_x, x))
        # Keep each name directly under its own icon for unambiguous mapping.
        label_y = y + node_half + 16
        label_y = max(14, min(canvas_height - 10, label_y))
        canvas.create_text(
            label_x,
            label_y,
            text=self._prettify_internal_id(node),
            fill="#1f1f1f",
            font=("", 8, "bold" if selected else "normal"),
            anchor="center",
        )

    def _draw_evolution_edges(
        self,
        canvas: tk.Canvas,
        edges: list[tuple[str, str, list[tuple[str, str]]]],
        positions: dict[str, tuple[int, int]],
        node_half: int,
    ):
        for source, target, conditions in edges:
            if source not in positions or target not in positions:
                continue
            sx, sy = positions[source]
            tx, ty = positions[target]
            self._draw_single_evolution_edge(
                canvas,
                sx,
                sy,
                tx,
                ty,
                conditions,
                node_half,
                target_node=target,
            )

    def _draw_evolution_nodes(
        self,
        canvas: tk.Canvas,
        positions: dict[str, tuple[int, int]],
        species_id: str,
        node_half: int,
        canvas_height: int,
    ):
        for node, (x, y) in positions.items():
            selected = node.upper() == species_id.upper()
            self._draw_single_evolution_node(canvas, node, x, y, selected, node_half, canvas_height)

    def _draw_bus_outgoing_from_point(
        self,
        canvas: tk.Canvas,
        sx: int,
        sy: int,
        outgoing: list[tuple[str, list[tuple[str, str]]]],
        positions: dict[str, tuple[int, int]],
        node_half: int,
        show_condition_text: bool,
    ):
        rows: list[tuple[str, int, int, list[tuple[str, str]]]] = []
        for target, conditions in outgoing:
            pos = positions.get(target)
            if pos is None:
                continue
            tx, ty = pos
            rows.append((target, tx, ty, conditions))
        if not rows:
            return
        rows.sort(key=lambda row: (row[2], row[1], row[0].casefold()))

        if len(rows) == 1:
            target, tx, ty, conditions = rows[0]
            self._draw_single_evolution_edge(
                canvas,
                sx,
                sy,
                tx,
                ty,
                conditions,
                node_half=node_half,
                show_condition_text=show_condition_text,
                target_node=target,
            )
            return

        min_tx = min(row[1] for row in rows)
        start_x = sx + node_half + 2
        bus_x = sx + max(24, min(68, int((min_tx - sx) * 0.36)))
        bus_x = min(bus_x, min_tx - 14)
        if bus_x < start_x:
            bus_x = start_x

        canvas.create_line(start_x, sy, bus_x, sy, width=2, fill="#666666")
        y_values = [row[2] for row in rows]
        canvas.create_line(bus_x, min(y_values), bus_x, max(y_values), width=2, fill="#666666")

        for target, tx, ty, conditions in rows:
            self._draw_single_evolution_edge(
                canvas,
                bus_x,
                ty,
                tx,
                ty,
                conditions,
                node_half=0,
                show_condition_text=show_condition_text,
                target_node=target,
            )

    def _draw_branch_bus_evolution_chart(
        self,
        canvas: tk.Canvas,
        species_id: str,
        nodes: set[str],
        edges: list[tuple[str, str, list[tuple[str, str]]]],
        width: int,
        height: int,
        node_half: int,
        focus_species_id: str | None = None,
    ) -> bool:
        outgoing_by_source: dict[str, list[tuple[str, list[tuple[str, str]]]]] = {}
        for source, target, conds in edges:
            outgoing_by_source.setdefault(source, []).append((target, conds))
        if not any(len(v) >= 2 for v in outgoing_by_source.values()):
            return False

        positions = self._layered_evolution_positions(nodes, edges, species_id, width, height, node_half)
        root_branch_count = sum(1 for source, _target, _conds in edges if source.upper() == species_id.upper())
        if root_branch_count <= 4:
            positions = self._compress_positions_horizontally(positions, width, node_half, ratio=0.70)
        for source, outgoing in outgoing_by_source.items():
            if source not in positions:
                continue
            sx, sy = positions[source]
            self._draw_bus_outgoing_from_point(
                canvas,
                sx,
                sy,
                outgoing,
                positions,
                node_half=node_half,
                show_condition_text=True,
            )
        self._draw_evolution_nodes(canvas, positions, focus_species_id or species_id, node_half, height)
        return True

    def _draw_split_center_evolution_chart(
        self,
        canvas: tk.Canvas,
        species_id: str,
        nodes: set[str],
        edges: list[tuple[str, str, list[tuple[str, str]]]],
        width: int,
        height: int,
        node_half: int,
        focus_species_id: str | None = None,
    ) -> bool:
        children: dict[str, list[tuple[str, list[tuple[str, str]]]]] = {}
        parents: dict[str, set[str]] = {}
        for source, target, conditions in edges:
            children.setdefault(source, []).append((target, conditions))
            parents.setdefault(target, set()).add(source)

        root_children = sorted(children.get(species_id, []), key=lambda row: row[0].casefold())
        if len(root_children) <= 4:
            return False

        side_pad = node_half + 10
        top_pad = node_half + 10
        bottom_pad = node_half + 10
        usable_w = width - (2 * side_pad)
        usable_h = height - top_pad - bottom_pad
        if usable_w < 120:
            side_pad = node_half + 4
            usable_w = width - (2 * side_pad)
        if usable_h < 90:
            top_pad = node_half + 4
            bottom_pad = node_half + 4
            usable_h = height - top_pad - bottom_pad

        root_targets = [target for target, _conds in root_children]
        chunks = self._split_branch_targets_balanced(root_targets, max_per_cluster=4)
        cluster_count = len(chunks)
        if cluster_count == 0:
            return False

        cols = self._split_chart_columns_for_width(cluster_count, width, node_half)
        rows = (cluster_count + cols - 1) // cols
        cell_w = usable_w / max(1, cols)
        cell_h = usable_h / max(1, rows)
        cluster_raise = max(10, int(cell_h * 0.10))

        def cluster_center(index: int) -> tuple[int, int]:
            r = index // cols
            c = index % cols
            # Place center toward the left side of each cell so right branches can spread wider.
            x = int(side_pad + (c * cell_w) + (cell_w * 0.12))
            y = int(top_pad + ((r + 0.52) * cell_h) - cluster_raise)
            row_top = int(top_pad + (r * cell_h))
            row_bottom = int(top_pad + ((r + 1) * cell_h))
            y = max(row_top + node_half + 12, min(row_bottom - node_half - 12, y))
            return x, y

        positions: dict[str, tuple[int, int]] = {}
        group_centers: list[tuple[int, int]] = []
        group_bounds: list[tuple[int, int, int, int]] = []
        group_roots: list[list[str]] = []
        node_group: dict[str, int] = {}
        root_group: dict[str, int] = {}
        root_conditions: dict[str, list[tuple[str, str]]] = {}
        for target, conds in root_children:
            root_conditions.setdefault(target, conds)

        for idx, roots_in_group in enumerate(chunks):
            cx, cy = cluster_center(idx)
            group_centers.append((cx, cy))
            group_roots.append(roots_in_group)
            col = idx % cols
            row = idx // cols
            cell_left = int(side_pad + (col * cell_w))
            cell_right = int(side_pad + ((col + 1) * cell_w))
            cell_top = int(top_pad + (row * cell_h))
            cell_bottom = int(top_pad + ((row + 1) * cell_h))
            left = max(side_pad, cell_left + 8)
            right = min(width - side_pad, cell_right - 8)
            top = max(top_pad, cell_top + 8)
            bottom = min(height - bottom_pad, cell_bottom - 8)
            group_bounds.append((left, right, top, bottom))

            # Keep branch column wide, but shorten center->branch distance to 70% for readability.
            target_right = right - (node_half + 2)
            target_x = cx + int((target_right - cx) * 0.70)
            branch_count = len(roots_in_group)
            if branch_count == 1:
                ys = [cy]
            else:
                # Ensure enough vertical spacing so labels below icons don't overlap the next icon.
                top_limit = top + 12
                bot_limit = bottom - 12
                base_ratio = 0.30 if branch_count <= 3 else 0.40
                cond_lines = 1
                if bool(getattr(self, "_evo_chart_show_all_conditions", False)):
                    for node in roots_in_group:
                        conds = root_conditions.get(node, [])
                        cond_lines = max(cond_lines, self._evolution_condition_line_count(conds, target_node=node))
                min_step = (node_half * 4) + max(0, cond_lines - 1) * 14
                min_span = min_step * (branch_count - 1)
                desired_span = max(int(cell_h * base_ratio * 2.0), min_span)
                max_half_span = max(0, min(cy - top_limit, bot_limit - cy))
                if max_half_span <= 0:
                    top_line = top_limit
                    bot_line = bot_limit
                else:
                    half_span = min(desired_span // 2, max_half_span)
                    top_line = cy - half_span
                    bot_line = cy + half_span
                if bot_line <= top_line:
                    ys = [cy for _ in range(branch_count)]
                else:
                    step = (bot_line - top_line) / max(1, branch_count - 1)
                    ys = [int(top_line + (i * step)) for i in range(branch_count)]

            for node, y in zip(roots_in_group, ys):
                x = target_x
                y = max(top, min(bottom, y))
                positions[node] = (x, y)
                node_group[node] = idx
                root_group[node] = idx

        root_set = set(root_targets)
        extras_by_group: dict[int, list[str]] = {i: [] for i in range(cluster_count)}
        for node in sorted(nodes, key=str.casefold):
            if node == species_id or node in positions:
                continue
            visited: set[str] = set()
            queue: list[str] = [node]
            owner_group = 0
            while queue:
                cur = queue.pop(0)
                for prev in parents.get(cur, set()):
                    if prev in root_set:
                        owner_group = root_group.get(prev, 0)
                        queue = []
                        break
                    if prev != species_id and prev not in visited:
                        visited.add(prev)
                        queue.append(prev)
            extras_by_group.setdefault(owner_group, []).append(node)

        for group_idx, extra_nodes in extras_by_group.items():
            if not extra_nodes:
                continue
            left, right, top, bottom = group_bounds[group_idx]
            base_x = max(
                left + 70,
                max((positions[n][0] for n in group_roots[group_idx] if n in positions), default=left + 70) + 192,
            )
            col_step = 220
            per_col = 4
            cursor = 0
            col = 0
            while cursor < len(extra_nodes):
                seg = extra_nodes[cursor : cursor + per_col]
                x = min(right - (node_half + 6), base_x + (col * col_step))
                if len(seg) == 1:
                    ys = [int((top + bottom) / 2)]
                else:
                    y_top = top + 16
                    y_bottom = bottom - 16
                    step = (y_bottom - y_top) / max(1, len(seg) - 1)
                    ys = [int(y_top + (i * step)) for i in range(len(seg))]
                for node, y in zip(seg, ys):
                    y = max(top, min(bottom, y))
                    positions[node] = (x, y)
                    node_group[node] = group_idx
                cursor += per_col
                col += 1

        for group_idx, roots_in_group in enumerate(group_roots):
            cx, cy = group_centers[group_idx]
            outgoing = [(node, root_conditions.get(node, [])) for node in roots_in_group if node in positions]
            self._draw_bus_outgoing_from_point(
                canvas,
                cx,
                cy,
                outgoing,
                positions,
                node_half=node_half,
                show_condition_text=bool(getattr(self, "_evo_chart_show_all_conditions", False)),
            )

        outgoing_by_source: dict[str, list[tuple[str, list[tuple[str, str]]]]] = {}
        for source, target, conds in edges:
            if source == species_id:
                continue
            if source in positions and target in positions:
                outgoing_by_source.setdefault(source, []).append((target, conds))

        for source, outgoing in outgoing_by_source.items():
            sx, sy = positions[source]
            self._draw_bus_outgoing_from_point(
                canvas,
                sx,
                sy,
                outgoing,
                positions,
                node_half=node_half,
                show_condition_text=True,
            )

        focus_upper = str(focus_species_id or species_id).strip().upper()
        center_selected = species_id.upper() == focus_upper
        for cx, cy in group_centers:
            self._draw_single_evolution_node(canvas, species_id, cx, cy, center_selected, node_half, height)

        for node, (x, y) in positions.items():
            group_idx = node_group.get(node, 0)
            anchor_center = group_centers[group_idx] if 0 <= group_idx < len(group_centers) else None
            self._draw_single_evolution_node(
                canvas,
                node,
                x,
                y,
                node.upper() == focus_upper,
                node_half,
                height,
                label_anchor=anchor_center,
            )
        return True

    def update_party_description(self, source: str | None = None, index: int | None = None, force: bool = False) -> str:
        lock = self._desc_lock.get("party")
        if not force and lock is not None:
            lock_source, lock_index = lock
            if source is None:
                source = lock_source
                index = lock_index
            else:
                norm_index = index if source in {"move", "relearn"} else None
                lock_norm_index = lock_index if lock_source in {"move", "relearn"} else None
                if source != lock_source or norm_index != lock_norm_index:
                    return ""
        if source is None:
            if self.pk_ability_var.get().strip():
                source = "ability"
            elif self.pk_item_var.get().strip():
                source = "item"
            elif self.pk_nature_var.get().strip():
                source = "nature"
            elif self.pk_species_var.get().strip():
                source = "species"
            else:
                source = "move"
        if not self._party_description_has_value(source, index):
            self._party_last_description_text = ""
            self._hide_party_tooltip()
            return ""
        title = ""
        description = ""
        try:
            if source == "item":
                item_id = self.resolve_item_id(self.pk_item_var.get()) if self.pk_item_var.get().strip() else ""
                title = f"Item: {item_id}" if item_id else "Item"
                raw_desc = self.catalogs.item_description(item_id) if self.catalogs and item_id else ""
                summary = self._item_numeric_summary_lines(item_id, raw_desc, "")
                base_desc, summary = self._resolve_entity_description("item", item_id, raw_desc, summary)
                description = self._append_mechanics_block(base_desc, summary)
            elif source == "ability":
                ability_id = self.resolve_selected_ability_id(self.pk_ability_var.get())
                title = f"Ability: {ability_id}" if ability_id else "Ability"
                raw_desc = self.catalogs.ability_description(ability_id) if self.catalogs and ability_id else ""
                summary = self._ability_numeric_summary_lines(ability_id, raw_desc, "")
                base_desc, summary = self._resolve_entity_description("ability", ability_id, raw_desc, summary)
                description = self._append_mechanics_block(base_desc, summary)
            elif source == "nature":
                nature_id = self.resolve_selected_nature_id(self.pk_nature_var.get())
                title = f"Nature: {nature_id}" if nature_id else "Nature"
                description = self._nature_description(nature_id)
            elif source == "species":
                species_id = self.resolve_species_id(self.pk_species_var.get()) if self.pk_species_var.get().strip() else ""
                title = f"Species: {species_id}" if species_id else "Species"
                lines: list[str] = []
                if self.catalogs and species_id:
                    form = self._clamp_int(self.pk_form_var.get(), 0, 99, 0)
                    base = self.catalogs.base_stats_for_species(species_id, form=form)
                    if base:
                        lines.append(
                            f"Base stats: HP {base.get('HP', 0)}, Atk {base.get('ATTACK', 0)}, Def {base.get('DEFENSE', 0)}, "
                            f"SpA {base.get('SPECIAL_ATTACK', 0)}, SpD {base.get('SPECIAL_DEFENSE', 0)}, Spe {base.get('SPEED', 0)}."
                        )
                    lines.append(self._species_evolution_description(species_id, form))
                description = "\n\n".join(line for line in lines if line.strip())
            elif source == "relearn":
                idx = index if index is not None else 0
                if 0 <= idx < len(self.relearn_move_vars):
                    move_id = self.resolve_selected_relearn_move_id(self.relearn_move_vars[idx].get())
                else:
                    move_id = ""
                title = f"Relearn Move {idx + 1}: {move_id}" if move_id else "Relearn Move"
                raw_desc = self.catalogs.move_description(move_id) if self.catalogs and move_id else ""
                summary = self._move_numeric_summary_lines(move_id, raw_desc, "")
                base_desc, summary = self._resolve_entity_description("move", move_id, raw_desc, summary)
                description = self._append_mechanics_block(base_desc, summary)
            else:
                idx = index if index is not None else 0
                if 0 <= idx < len(self.move_id_vars):
                    move_id = self.resolve_selected_move_id(self.move_id_vars[idx].get())
                else:
                    move_id = ""
                title = f"Move {idx + 1}: {move_id}" if move_id else "Move"
                raw_desc = self.catalogs.move_description(move_id) if self.catalogs and move_id else ""
                summary = self._move_numeric_summary_lines(move_id, raw_desc, "")
                base_desc, summary = self._resolve_entity_description("move", move_id, raw_desc, summary)
                description = self._append_mechanics_block(base_desc, summary)
        except Exception:
            title = "Description"
            description = ""
        body = description.strip() if description else "No description available."
        text = f"{title}\n\n{body}" if title else body
        self._party_last_description_text = text
        tip = self._party_tooltip_window
        label = self._party_tooltip_label
        if tip is not None and label is not None:
            try:
                if tip.winfo_exists() and label.winfo_exists() and tip.state() != "withdrawn":
                    label.configure(text=text)
            except Exception:
                pass
        if hasattr(self, "party_desc_text"):
            self._set_text_widget_content(self.party_desc_text, text)
        return text

    def update_bag_description(self, source: str | None = None, force: bool = False):
        if not hasattr(self, "bag_desc_text"):
            return
        lock = self._desc_lock.get("bag")
        if not force and lock is not None:
            lock_source, _lock_index = lock
            if source is None:
                source = lock_source
            elif source != lock_source:
                return
        title = "Item"
        description = ""
        try:
            item_id = self.resolve_item_id(self.bag_item_var.get()) if self.bag_item_var.get().strip() else ""
            if item_id:
                title = f"Item: {item_id}"
                raw_desc = self.catalogs.item_description(item_id) if self.catalogs else ""
                summary = self._item_numeric_summary_lines(item_id, raw_desc, "")
                base_desc, summary = self._resolve_entity_description("item", item_id, raw_desc, summary)
                description = self._append_mechanics_block(base_desc, summary)
        except Exception:
            pass
        body = description.strip() if description else "No description available."
        self._set_text_widget_content(self.bag_desc_text, f"{title}\n\n{body}")

    def _ability_label_for_id(self, ability_id: str, hidden_ids: set[str]) -> str:
        base = self._english_ability_name_for_id(ability_id)
        if ability_id in hidden_ids:
            return f"{base} (H)"
        return base

    def _move_label_for_id(self, move_id: str) -> str:
        return move_id

    def refresh_party_legality_dropdowns(self, reset_invalid: bool):
        if not self.catalogs:
            return
        if not hasattr(self, "pk_ability_combo"):
            return
        species_raw = self.pk_species_var.get().strip()
        if not species_raw:
            return
        try:
            species_id = self.resolve_species_id(species_raw)
        except Exception:
            return
        try:
            form = int(self.pk_form_var.get().strip()) if self.pk_form_var.get().strip() else 0
        except ValueError:
            form = 0

        ability_ids, hidden_ids = self.catalogs.valid_abilities_for_species(species_id, form=form)
        if not ability_ids:
            ability_ids = sorted(self.catalogs.abilities_by_id.keys(), key=str.casefold)
            hidden_ids = set()
        self._party_hidden_abilities = set(hidden_ids)
        ability_pairs: list[tuple[str, str]] = []
        for ability_id in ability_ids:
            label = self._ability_label_for_id(ability_id, hidden_ids)
            if any(existing == label for existing, _ in ability_pairs):
                label = f"{label} [{ability_id}]"
            ability_pairs.append((label, ability_id))
        ability_pairs.sort(key=lambda x: x[0].casefold())
        self._party_ability_label_to_id = {label: aid for label, aid in ability_pairs}
        self._party_ability_id_to_label = {}
        for label, ability_id in ability_pairs:
            self._party_ability_id_to_label.setdefault(ability_id, label)
        ability_labels = [label for label, _ in ability_pairs]
        self._set_combo_values(self.pk_ability_combo, ability_labels)

        current_ability_id = self.resolve_selected_ability_id(self.pk_ability_var.get())
        if current_ability_id and current_ability_id in self._party_ability_id_to_label:
            self.pk_ability_var.set(self._party_ability_id_to_label[current_ability_id])
        elif reset_invalid:
            self.pk_ability_var.set(ability_labels[0] if ability_labels else "")
        self._sync_ability_index_from_selection(force=reset_invalid)

        valid_move_ids = self.catalogs.valid_moves_for_species(species_id, form=form)
        if not valid_move_ids:
            valid_move_ids = sorted(self.catalogs.moves_by_id.keys(), key=str.casefold)
        move_pairs: list[tuple[str, str]] = []
        for move_id in valid_move_ids:
            label = self._move_label_for_id(move_id)
            if any(existing == label for existing, _ in move_pairs):
                label = f"{label} [{move_id}]"
            move_pairs.append((label, move_id))
        move_pairs.sort(key=lambda x: x[0].casefold())
        self._party_move_label_to_id = {label: mid for label, mid in move_pairs}
        self._party_move_id_to_label = {}
        for label, move_id in move_pairs:
            self._party_move_id_to_label.setdefault(move_id, label)
        move_labels = [label for label, _ in move_pairs]
        for combo in self.move_id_combos:
            self._set_combo_values(combo, move_labels)
        for i, var in enumerate(self.move_id_vars):
            current_move_id = self.resolve_selected_move_id(var.get())
            if current_move_id and current_move_id in self._party_move_id_to_label:
                var.set(self._party_move_id_to_label[current_move_id])
            elif reset_invalid:
                var.set(move_labels[min(i, len(move_labels) - 1)] if move_labels else "")
            self.on_move_combo_changed(i, force_pp=False, update_description=False)

        relearn_ids = self.catalogs.valid_relearn_moves_for_species(species_id, form=form)
        if not relearn_ids:
            relearn_ids = valid_move_ids
        relearn_pairs: list[tuple[str, str]] = []
        for move_id in relearn_ids:
            label = self._move_label_for_id(move_id)
            if any(existing == label for existing, _ in relearn_pairs):
                label = f"{label} [{move_id}]"
            relearn_pairs.append((label, move_id))
        relearn_pairs.sort(key=lambda x: x[0].casefold())
        self._party_relearn_label_to_id = {label: mid for label, mid in relearn_pairs}
        self._party_relearn_id_to_label = {}
        for label, move_id in relearn_pairs:
            self._party_relearn_id_to_label.setdefault(move_id, label)
        relearn_labels = ["(None)"] + [label for label, _ in relearn_pairs]
        for combo in self.relearn_move_combos:
            self._set_combo_values(combo, relearn_labels)
        for var in self.relearn_move_vars:
            current_move_id = self.resolve_selected_relearn_move_id(var.get())
            if current_move_id and current_move_id in self._party_relearn_id_to_label:
                var.set(self._party_relearn_id_to_label[current_move_id])
            elif reset_invalid:
                var.set("(None)")

    def resolve_selected_ability_id(self, text: str) -> str:
        raw = text.strip()
        if not raw:
            return ""
        if raw in self._party_ability_label_to_id:
            return self._party_ability_label_to_id[raw]
        cleaned = re.sub(r"\s+\(H\)\s*$", "", raw)
        cleaned = re.sub(r"\s+\[[^\]]+\]\s*$", "", cleaned)
        try:
            return self.resolve_ability_id(cleaned)
        except Exception:
            return ""

    def resolve_selected_move_id(self, text: str) -> str:
        raw = text.strip()
        if not raw:
            return ""
        if raw in self._party_move_label_to_id:
            return self._party_move_label_to_id[raw]
        cleaned = re.sub(r"\s+\[[^\]]+\]\s*$", "", raw)
        try:
            return self.resolve_move_id(cleaned)
        except Exception:
            return ""

    def resolve_selected_relearn_move_id(self, text: str) -> str:
        raw = text.strip()
        if not raw or raw == "(None)":
            return ""
        if raw in self._party_relearn_label_to_id:
            return self._party_relearn_label_to_id[raw]
        cleaned = re.sub(r"\s+\[[^\]]+\]\s*$", "", raw)
        try:
            return self.resolve_move_id(cleaned)
        except Exception:
            return ""

    def _nature_changed_stats(self) -> tuple[str | None, str | None]:
        nature = self.resolve_selected_nature_id(self.pk_nature_var.get())
        if not nature:
            return None, None
        return NATURE_EFFECTS.get(nature, (None, None))

    def _update_nature_stat_label_colors(self):
        up, down = self._nature_changed_stats()
        for stat_id, lbl in self.party_stat_name_labels.items():
            if stat_id == up:
                lbl.configure(fg="#c03535")
            elif stat_id == down:
                lbl.configure(fg="#2b5fc9")
            else:
                lbl.configure(fg="black")

    def _update_nature_effect_labels(self):
        up, down = self._nature_changed_stats()
        if not up or not down:
            self.pk_nature_effect_var.set("Nature effect: neutral")
            self.pk_nature_neutral_var.set("Neutral")
            self.pk_nature_up_var.set("")
            self.pk_nature_sep_var.set("")
            self.pk_nature_down_var.set("")
            return
        self.pk_nature_effect_var.set("Nature effect:")
        self.pk_nature_neutral_var.set("")
        self.pk_nature_up_var.set(f"{STAT_SHORT_LABELS.get(up, up)}↑")
        self.pk_nature_sep_var.set(" / ")
        self.pk_nature_down_var.set(f"{STAT_SHORT_LABELS.get(down, down)}↓")

    def _read_symbol_stat_dict(self, pkmn: core.RubyObject, attr: str) -> dict[str, int]:
        raw = core.read_attr(pkmn, attr, {})
        out: dict[str, int] = {sid: 0 for sid, _ in STAT_ORDER}
        if not isinstance(raw, dict):
            return out
        for key, value in raw.items():
            name = symbol_name(key).strip().lstrip(":").upper()
            if name not in out:
                continue
            try:
                out[name] = int(value)
            except (TypeError, ValueError):
                continue
        return out

    def _write_symbol_stat_dict(self, pkmn: core.RubyObject, attr: str, values: dict[str, int]):
        current = core.read_attr(pkmn, attr, {})
        key_map: dict[str, Any] = {}
        if isinstance(current, dict):
            for key in current.keys():
                key_map[symbol_name(key).strip().lstrip(":").upper()] = key
        out: dict[Any, int] = {}
        for sid, _label in STAT_ORDER:
            key = key_map.get(sid, core.Symbol(sid))
            out[key] = int(values.get(sid, 0))
        pkmn.attributes[attr] = out

    @staticmethod
    def _clamp_int(text: str, low: int, high: int, default: int = 0) -> int:
        try:
            value = int(text.strip())
        except (TypeError, ValueError, AttributeError):
            value = default
        if value < low:
            return low
        if value > high:
            return high
        return value

    def _current_species_form(self) -> tuple[str | None, int]:
        species_raw = self.pk_species_var.get().strip()
        if not species_raw:
            return None, 0
        try:
            species_id = self.resolve_species_id(species_raw)
        except Exception:
            return None, 0
        try:
            form = int(self.pk_form_var.get().strip()) if self.pk_form_var.get().strip() else 0
        except ValueError:
            form = 0
        return species_id, form

    def _sync_exp_with_level(self, force: bool = False):
        level = self._clamp_int(self.pk_level_var.get(), 1, 100, 1)
        self.pk_level_var.set(str(level))
        species_id, form = self._current_species_form()
        if not species_id or not self.catalogs:
            if force and not self.pk_exp_var.get().strip():
                self.pk_exp_var.set("0")
            return
        minimum_exp = self.catalogs.minimum_exp_for_level(species_id, level, form=form)
        current_exp = self._clamp_int(self.pk_exp_var.get(), 0, 99999999, minimum_exp)
        if force or current_exp < minimum_exp:
            current_exp = minimum_exp
        self.pk_exp_var.set(str(current_exp))

    def _nature_multiplier(self, stat_id: str) -> int:
        up, down = self._nature_changed_stats()
        if stat_id == up:
            return 110
        if stat_id == down:
            return 90
        return 100

    def _calc_stat_value(self, stat_id: str, base: int, level: int, iv: int, ev: int) -> int:
        if stat_id == "HP":
            if base == 1:
                return 1
            return (((base * 2) + iv + (ev // 4)) * level // 100) + level + 10
        core_val = (((base * 2) + iv + (ev // 4)) * level // 100) + 5
        return (core_val * self._nature_multiplier(stat_id)) // 100

    def _hidden_power_type_from_ivs(self, ivs: dict[str, int]) -> str:
        if not self.catalogs:
            return "Unknown"
        types = self.catalogs.hidden_power_type_ids
        if not types:
            return "Unknown"
        idx_type = 0
        idx_type |= (ivs.get("HP", 0) & 1)
        idx_type |= (ivs.get("ATTACK", 0) & 1) << 1
        idx_type |= (ivs.get("DEFENSE", 0) & 1) << 2
        idx_type |= (ivs.get("SPEED", 0) & 1) << 3
        idx_type |= (ivs.get("SPECIAL_ATTACK", 0) & 1) << 4
        idx_type |= (ivs.get("SPECIAL_DEFENSE", 0) & 1) << 5
        idx_type = (len(types) - 1) * idx_type // 63
        if idx_type < 0 or idx_type >= len(types):
            return "Unknown"
        type_id = types[idx_type]
        return type_id

    def _current_editor_iv_values(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for sid, _label in STAT_ORDER:
            out[sid] = self._clamp_int(self.party_iv_vars[sid].get(), 0, 31, 0)
        total = sum(out.values())
        if total > 186:
            overflow = total - 186
            for sid, _label in reversed(STAT_ORDER):
                if overflow <= 0:
                    break
                reducible = min(overflow, out[sid])
                out[sid] -= reducible
                overflow -= reducible
        return out

    def _current_editor_ev_values(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for sid, _label in STAT_ORDER:
            out[sid] = self._clamp_int(self.party_ev_vars[sid].get(), 0, 252, 0)
        return out

    def _refresh_stats_from_editor_inputs(self):
        species_id, form = self._current_species_form()
        base_stats = self.catalogs.base_stats_for_species(species_id, form=form) if self.catalogs and species_id else {}
        level = self._clamp_int(self.pk_level_var.get(), 1, 100, 1)
        self.pk_level_var.set(str(level))
        self._sync_exp_with_level(force=False)

        ivs = self._current_editor_iv_values()
        evs = self._current_editor_ev_values()
        for sid, _label in STAT_ORDER:
            self.party_iv_vars[sid].set(str(ivs[sid]))
            self.party_ev_vars[sid].set(str(evs[sid]))
            self.party_base_stat_vars[sid].set(str(base_stats.get(sid, 0)))

        computed: dict[str, int] = {}
        for sid, _label in STAT_ORDER:
            stat_value = self._calc_stat_value(sid, base_stats.get(sid, 0), level, ivs[sid], evs[sid])
            computed[sid] = stat_value
            self.party_final_stat_vars[sid].set(str(stat_value))

        self.pk_totalhp_var.set(str(computed.get("HP", 0)))
        self.pk_attack_var.set(str(computed.get("ATTACK", 0)))
        self.pk_defense_var.set(str(computed.get("DEFENSE", 0)))
        self.pk_spatk_var.set(str(computed.get("SPECIAL_ATTACK", 0)))
        self.pk_spdef_var.set(str(computed.get("SPECIAL_DEFENSE", 0)))
        self.pk_speed_var.set(str(computed.get("SPEED", 0)))
        hidden_power_type = self._hidden_power_type_from_ivs(ivs)
        self.party_hidden_power_var.set(hidden_power_type)
        if hasattr(self, "party_hidden_power_chip_host"):
            hp_ids = self._extract_type_ids(hidden_power_type)
            self._render_type_chip_row(
                self.party_hidden_power_chip_host,
                hp_ids,
                short=False,
                empty_text=hidden_power_type or "Unknown",
            )
        self._update_nature_stat_label_colors()
        self.update_party_editor_preview()

    def on_iv_ev_focus_out(self, kind: str, stat_id: str):
        stat_id = stat_id.upper()
        if kind == "iv":
            values = self._current_editor_iv_values()
            for sid, _label in STAT_ORDER:
                self.party_iv_vars[sid].set(str(values[sid]))
        else:
            values = self._current_editor_ev_values()
            for sid, _label in STAT_ORDER:
                self.party_ev_vars[sid].set(str(values[sid]))
        self._refresh_stats_from_editor_inputs()

        entry, _slot_label = self._selected_slot_entry()
        if isinstance(entry, core.RubyObject):
            self._apply_stat_block_to_pokemon(entry, preserve_hp_ratio=True)
            self.mark_modified()

    def set_all_evs_max(self):
        for sid, _label in STAT_ORDER:
            self.party_ev_vars[sid].set("252")
        self._refresh_stats_from_editor_inputs()
        entry, _slot_label = self._selected_slot_entry()
        if isinstance(entry, core.RubyObject):
            self._apply_stat_block_to_pokemon(entry, preserve_hp_ratio=True)
            self.mark_modified()

    def _apply_stat_block_to_pokemon(self, pkmn: core.RubyObject, preserve_hp_ratio: bool):
        ivs = self._current_editor_iv_values()
        evs = self._current_editor_ev_values()
        self._write_symbol_stat_dict(pkmn, "@iv", ivs)
        self._write_symbol_stat_dict(pkmn, "@ev", evs)

        final_stats: dict[str, int] = {}
        for sid, _label in STAT_ORDER:
            final_stats[sid] = self._clamp_int(self.party_final_stat_vars[sid].get(), 0, 9999, 0)

        old_total_hp = core.read_attr(pkmn, "@totalhp", final_stats["HP"])
        old_hp = core.read_attr(pkmn, "@hp", final_stats["HP"])
        try:
            old_total_hp = int(old_total_hp)
        except (TypeError, ValueError):
            old_total_hp = final_stats["HP"]
        try:
            old_hp = int(old_hp)
        except (TypeError, ValueError):
            old_hp = final_stats["HP"]

        if preserve_hp_ratio and old_total_hp > 0:
            new_hp = old_hp + (final_stats["HP"] - old_total_hp)
            new_hp = max(1, min(final_stats["HP"], new_hp))
        else:
            new_hp = final_stats["HP"]

        pkmn.attributes["@totalhp"] = final_stats["HP"]
        pkmn.attributes["@hp"] = new_hp
        pkmn.attributes["@attack"] = final_stats["ATTACK"]
        pkmn.attributes["@defense"] = final_stats["DEFENSE"]
        pkmn.attributes["@spatk"] = final_stats["SPECIAL_ATTACK"]
        pkmn.attributes["@spdef"] = final_stats["SPECIAL_DEFENSE"]
        pkmn.attributes["@speed"] = final_stats["SPEED"]

        self.pk_hp_var.set(str(new_hp))
        self.pk_totalhp_var.set(str(final_stats["HP"]))
        self.pk_attack_var.set(str(final_stats["ATTACK"]))
        self.pk_defense_var.set(str(final_stats["DEFENSE"]))
        self.pk_spatk_var.set(str(final_stats["SPECIAL_ATTACK"]))
        self.pk_spdef_var.set(str(final_stats["SPECIAL_DEFENSE"]))
        self.pk_speed_var.set(str(final_stats["SPEED"]))
        self.update_party_editor_preview()

    def load_species_defaults_into_editor(self):
        species_id, form = self._current_species_form()
        if not species_id:
            messagebox.showwarning("Missing Species", "Choose a species first.")
            return
        level = self._clamp_int(self.pk_level_var.get(), 1, 100, 1)
        self.pk_level_var.set(str(level))
        if not self.pk_nature_var.get().strip():
            self.pk_nature_var.set(self._party_nature_id_to_label.get("HARDY", self._nature_label_for_id("HARDY")))
        if not self.pk_happiness_var.get().strip():
            self.pk_happiness_var.set("70")
        if not self.pk_name_var.get().strip():
            self.pk_name_var.set(species_id)
        if not self.pk_gender_var.get().strip():
            self.pk_gender_var.set("0")
        self._sync_exp_with_level(force=True)

        for sid, _label in STAT_ORDER:
            self.party_iv_vars[sid].set("31")
            self.party_ev_vars[sid].set("0")

        self.refresh_party_legality_dropdowns(reset_invalid=True)
        self._sync_ability_index_from_selection(force=True)
        initial_moves = self.catalogs.initial_moves_for_species(species_id, form=form, level=level) if self.catalogs else []
        for i in range(4):
            if i < len(initial_moves):
                move_id = initial_moves[i]
                self.move_id_vars[i].set(self._party_move_id_to_label.get(move_id, move_id))
            else:
                self.move_id_vars[i].set("")
            self.move_ppup_vars[i].set("0")
            move_id = self.resolve_selected_move_id(self.move_id_vars[i].get())
            self.move_pp_vars[i].set(str(self._move_max_pp(move_id, 0)) if move_id else "")

        relearn_ids = self.catalogs.valid_relearn_moves_for_species(species_id, form=form) if self.catalogs else []
        for i in range(4):
            if i < len(relearn_ids):
                mid = relearn_ids[i]
                self.relearn_move_vars[i].set(self._party_relearn_id_to_label.get(mid, mid))
            else:
                self.relearn_move_vars[i].set("(None)")

        self._refresh_stats_from_editor_inputs()
        self._update_nature_effect_labels()
        self.update_party_evolution_chart()
        self.update_party_description("species")

    def _clone_ruby_object(self, obj: core.RubyObject) -> core.RubyObject:
        buf = io.BytesIO()
        core.marshal_write(buf, obj, cls=core.SaveWriter)
        buf.seek(0)
        if buf.read(1) != b"\x04" or buf.read(1) != b"\x08":
            raise ValueError("Failed to clone object (marshal header mismatch).")
        reader = core.CycleAwareReader(buf, registry=core.global_registry)
        cloned = reader.read()
        if not isinstance(cloned, core.RubyObject):
            raise TypeError("Cloned object is not a RubyObject.")
        return cloned

    def _find_template_pokemon(self) -> core.RubyObject | None:
        player = self.get_root_key("player")
        party = core.read_attr(player, "@party", []) if isinstance(player, core.RubyObject) else []
        if isinstance(party, list):
            for p in party:
                if isinstance(p, core.RubyObject):
                    return p
        boxes = self._get_storage_boxes()
        for box in boxes:
            for p in self._get_box_pokemon_list(box):
                if isinstance(p, core.RubyObject):
                    return p
        return None

    def _set_selected_slot_entry(self, value: Any):
        if self._party_selected_mode is None or self._party_selected_index is None:
            raise ValueError("No slot selected.")
        idx = self._party_selected_index
        if self._party_selected_mode == "party":
            player = self.get_root_key("player")
            if not isinstance(player, core.RubyObject):
                raise ValueError("Player section missing.")
            party = core.read_attr(player, "@party", [])
            if not isinstance(party, list):
                party = []
            while len(party) <= idx:
                party.append(None)
            party[idx] = value
            player.attributes["@party"] = party
            return
        boxes = self._get_storage_boxes()
        box_idx = self._party_selected_box_index if self._party_selected_box_index is not None else self._selected_box_index()
        if box_idx < 0 or box_idx >= len(boxes):
            raise ValueError("Box index out of range.")
        box_obj = boxes[box_idx]
        if not isinstance(box_obj, core.RubyObject):
            raise ValueError("Selected box is invalid.")
        box_data = self._get_box_pokemon_list(box_obj)
        while len(box_data) <= idx:
            box_data.append(None)
        box_data[idx] = value
        box_obj.attributes["@pokemon"] = box_data

    def _create_new_pokemon_from_editor(self) -> core.RubyObject:
        self._refresh_stats_from_editor_inputs()
        self._sync_exp_with_level(force=True)
        species_id, form = self._current_species_form()
        if not species_id:
            raise ValueError("Species is required.")
        template = self._party_template_pokemon or self._find_template_pokemon()
        if template is None:
            pkmn = core.RubyObject("Pokemon", {})
        else:
            self._party_template_pokemon = template
            pkmn = self._clone_ruby_object(template)

        level = self._clamp_int(self.pk_level_var.get(), 1, 100, 1)
        pkmn.attributes["@species"] = core.Symbol(species_id)
        if "@form" in pkmn.attributes:
            pkmn.attributes["@form"] = form
        if "@level" in pkmn.attributes:
            pkmn.attributes["@level"] = level
        if "@name" in pkmn.attributes:
            pkmn.attributes["@name"] = self.pk_name_var.get().strip() or species_id
        if "@exp" in pkmn.attributes:
            pkmn.attributes["@exp"] = self._clamp_int(self.pk_exp_var.get(), 0, 99999999, 0)
        if "@nature" in pkmn.attributes:
            nature = self.resolve_selected_nature_id(self.pk_nature_var.get()) or "HARDY"
            pkmn.attributes["@nature"] = core.Symbol(nature)
        if "@item" in pkmn.attributes:
            item_id = self.resolve_item_id(self.pk_item_var.get().strip()) if self.pk_item_var.get().strip() else ""
            pkmn.attributes["@item"] = core.Symbol(item_id) if item_id else None
        if "@ability" in pkmn.attributes:
            ability_id = self.resolve_selected_ability_id(self.pk_ability_var.get())
            if not ability_id and self._party_ability_id_to_label:
                ability_id = next(iter(self._party_ability_id_to_label.keys()))
            pkmn.attributes["@ability"] = core.Symbol(ability_id) if ability_id else None
        if "@ability_index" in pkmn.attributes:
            pkmn.attributes["@ability_index"] = self._clamp_int(self.pk_ability_index_var.get(), 0, 3, 0)
        if "@gender" in pkmn.attributes:
            pkmn.attributes["@gender"] = self._clamp_int(self.pk_gender_var.get(), 0, 2, 0)
        if "@happiness" in pkmn.attributes:
            pkmn.attributes["@happiness"] = self._clamp_int(self.pk_happiness_var.get(), 0, 255, 70)
        if "@shiny" in pkmn.attributes:
            pkmn.attributes["@shiny"] = bool(self.pk_shiny_var.get())
        if "@super_shiny" in pkmn.attributes:
            pkmn.attributes["@super_shiny"] = bool(self.pk_super_shiny_var.get())
        if "@personalID" in pkmn.attributes:
            pkmn.attributes["@personalID"] = random.randint(0, 2**32 - 1)
        if "@obtain_level" in pkmn.attributes:
            pkmn.attributes["@obtain_level"] = self._clamp_int(self.pk_obtain_level_var.get(), 0, 100, level)
        if "@obtain_map" in pkmn.attributes:
            pkmn.attributes["@obtain_map"] = self._clamp_int(self.pk_obtain_map_var.get(), 0, 999999, 0)
        if "@obtain_method" in pkmn.attributes:
            pkmn.attributes["@obtain_method"] = self._clamp_int(self.pk_obtain_method_var.get(), 0, 999, 0)
        if "@hatched_map" in pkmn.attributes:
            pkmn.attributes["@hatched_map"] = self._clamp_int(self.pk_hatched_map_var.get(), 0, 999999, 0)

        moves = core.read_attr(pkmn, "@moves", [])
        if not isinstance(moves, list):
            moves = []
        initial_moves = self.catalogs.initial_moves_for_species(species_id, form=form, level=level) if self.catalogs else []
        while len(moves) < 4:
            moves.append(core.RubyObject("Pokemon::Move", {"@id": core.Symbol("TACKLE"), "@pp": 35, "@ppup": 0}))
        for i, move_obj in enumerate(moves[:4]):
            if not isinstance(move_obj, core.RubyObject):
                move_obj = core.RubyObject("Pokemon::Move", {"@id": core.Symbol("TACKLE"), "@pp": 35, "@ppup": 0})
                moves[i] = move_obj
            move_id = self.resolve_selected_move_id(self.move_id_vars[i].get()) if self.move_id_vars[i].get().strip() else ""
            if not move_id and i < len(initial_moves):
                move_id = initial_moves[i]
            if not move_id:
                continue
            move_obj.attributes["@id"] = core.Symbol(move_id)
            ppup_value = self._clamp_int(self.move_ppup_vars[i].get(), 0, 3, 0)
            max_pp = self._move_max_pp(move_id, ppup_value)
            if "@ppup" in move_obj.attributes:
                move_obj.attributes["@ppup"] = ppup_value
            if "@pp" in move_obj.attributes:
                move_obj.attributes["@pp"] = self._clamp_int(self.move_pp_vars[i].get(), 0, max_pp, max_pp)
        pkmn.attributes["@moves"] = moves

        if "@first_moves" in pkmn.attributes:
            relearn_ids: list[str] = []
            for i in range(4):
                mid = self.resolve_selected_relearn_move_id(self.relearn_move_vars[i].get())
                if mid and mid not in relearn_ids:
                    relearn_ids.append(mid)
            if not relearn_ids:
                relearn_ids = initial_moves[:]
            pkmn.attributes["@first_moves"] = [core.Symbol(mid) for mid in relearn_ids]
        elif initial_moves:
            pkmn.attributes["@first_moves"] = [core.Symbol(mid) for mid in initial_moves[:4]]

        # Ensure essential fields exist for newly-created objects.
        pkmn.attributes.setdefault("@species", core.Symbol(species_id))
        pkmn.attributes.setdefault("@form", form)
        pkmn.attributes.setdefault("@level", level)
        pkmn.attributes.setdefault("@exp", self._clamp_int(self.pk_exp_var.get(), 0, 99999999, 0))
        pkmn.attributes.setdefault("@name", self.pk_name_var.get().strip() or species_id)
        pkmn.attributes.setdefault("@nature", core.Symbol(self.resolve_selected_nature_id(self.pk_nature_var.get()) or "HARDY"))
        pkmn.attributes.setdefault("@happiness", self._clamp_int(self.pk_happiness_var.get(), 0, 255, 70))
        pkmn.attributes.setdefault("@gender", self._clamp_int(self.pk_gender_var.get(), 0, 2, 0))
        pkmn.attributes.setdefault("@item", None)
        pkmn.attributes.setdefault("@ability_index", 0)
        pkmn.attributes.setdefault("@forced_form", form)
        pkmn.attributes.setdefault("@obtain_level", level)
        pkmn.attributes.setdefault("@obtain_map", 0)
        pkmn.attributes.setdefault("@obtain_method", 0)
        pkmn.attributes.setdefault("@hatched_map", 0)
        pkmn.attributes.setdefault("@personalID", random.randint(0, 2**32 - 1))
        pkmn.attributes.setdefault("@shiny", bool(self.pk_shiny_var.get()))
        pkmn.attributes.setdefault("@super_shiny", bool(self.pk_super_shiny_var.get()))
        pkmn.attributes.setdefault("@iv", {core.Symbol(sid): 31 for sid, _ in STAT_ORDER})
        pkmn.attributes.setdefault("@ev", {core.Symbol(sid): 0 for sid, _ in STAT_ORDER})
        pkmn.attributes.setdefault("@moves", moves[:4])

        self._apply_stat_block_to_pokemon(pkmn, preserve_hp_ratio=False)
        return pkmn

    def set_new_pokemon_to_selected_slot(self):
        try:
            new_pkmn = self._create_new_pokemon_from_editor()
            self._set_selected_slot_entry(new_pkmn)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Set Error", str(exc))
            return
        self.mark_modified()
        self._render_party_slot_grid()
        self._load_selected_pokemon_into_editor(new_pkmn)
        self.set_status("New Pokemon created and assigned to selected slot.")

    def _clear_party_detail_fields(self):
        for v in [
            self.pk_species_var,
            self.pk_form_var,
            self.pk_level_var,
            self.pk_exp_var,
            self.pk_hp_var,
            self.pk_totalhp_var,
            self.pk_attack_var,
            self.pk_defense_var,
            self.pk_spatk_var,
            self.pk_spdef_var,
            self.pk_speed_var,
            self.pk_happiness_var,
            self.pk_nature_var,
            self.pk_item_var,
            self.pk_ability_var,
            self.pk_gender_var,
            self.pk_name_var,
            self.pk_obtain_level_var,
            self.pk_obtain_map_var,
            self.pk_obtain_method_var,
            self.pk_obtain_text_var,
            self.pk_hatched_map_var,
            self.pk_ability_index_var,
            self.pk_personal_id_var,
            self.pk_forced_form_var,
            self.pk_legacy_var,
        ]:
            v.set("")
        for sid, _label in STAT_ORDER:
            self.party_iv_vars[sid].set("0")
            self.party_ev_vars[sid].set("0")
            self.party_base_stat_vars[sid].set("0")
            self.party_final_stat_vars[sid].set("0")
        self.party_hidden_power_var.set("Unknown")
        if hasattr(self, "party_hidden_power_chip_host"):
            self._render_type_chip_row(
                self.party_hidden_power_chip_host,
                [],
                short=False,
                empty_text="Unknown",
            )
        self.pk_shiny_var.set(False)
        self.pk_super_shiny_var.set(False)
        for i in range(4):
            self.move_id_vars[i].set("")
            self.move_pp_vars[i].set("")
            self.move_ppup_vars[i].set("")
            self.relearn_move_vars[i].set("(None)")
        self.pk_nature_effect_var.set("")
        self.pk_nature_neutral_var.set("")
        self.pk_nature_up_var.set("")
        self.pk_nature_sep_var.set("")
        self.pk_nature_down_var.set("")
        self._update_nature_stat_label_colors()
        self.update_party_editor_preview()
        self.update_party_evolution_chart()
        self.update_party_description()

    def apply_selected_pokemon(self):
        entry, slot_label = self._selected_slot_entry()
        if not isinstance(entry, core.RubyObject):
            messagebox.showwarning("No Selection", "Select a non-empty Party/Box slot first.")
            return
        self._sync_exp_with_level(force=True)
        self.on_ability_index_focus_out()
        self.on_forced_form_focus_out()
        pkmn = entry

        def set_int_attr(attr: str, value: str, field_name: str):
            if attr in pkmn.attributes:
                clean = value.strip()
                if clean != "":
                    pkmn.attributes[attr] = parse_int(clean, field_name)

        try:
            if "@species" in pkmn.attributes:
                pkmn.attributes["@species"] = core.Symbol(self.resolve_species_id(self.pk_species_var.get()))
            set_int_attr("@form", self.pk_form_var.get(), "Form")
            set_int_attr("@level", self.pk_level_var.get(), "Level")
            set_int_attr("@exp", self.pk_exp_var.get(), "EXP")
            set_int_attr("@happiness", self.pk_happiness_var.get(), "Friendship")
            set_int_attr("@gender", self.pk_gender_var.get(), "Gender")
            set_int_attr("@obtain_level", self.pk_obtain_level_var.get(), "Obtain Level")
            set_int_attr("@obtain_map", self.pk_obtain_map_var.get(), "Obtain Map")
            set_int_attr("@obtain_method", self.pk_obtain_method_var.get(), "Obtain Method")
            set_int_attr("@hatched_map", self.pk_hatched_map_var.get(), "Hatched Map")
            if "@ability_index" in pkmn.attributes:
                raw_ability_index = self.pk_ability_index_var.get().strip()
                if raw_ability_index.lower() in {"", "none", "nil", "null"}:
                    suggested = self._suggest_ability_index_for_current()
                    ability_index = self._clamp_int(str(suggested if suggested is not None else 0), 0, 3, 0)
                else:
                    ability_index = self._clamp_int(str(parse_int(raw_ability_index, "Ability Index")), 0, 3, 0)
                pkmn.attributes["@ability_index"] = ability_index
                self.pk_ability_index_var.set(str(ability_index))
            set_int_attr("@personalID", self.pk_personal_id_var.get(), "Personal ID")
            if "@forced_form" in pkmn.attributes:
                raw_forced_form = self.pk_forced_form_var.get().strip()
                if raw_forced_form.lower() in {"", "none", "nil", "null"}:
                    pkmn.attributes["@forced_form"] = None
                    self.pk_forced_form_var.set("")
                else:
                    forced_form = parse_int(raw_forced_form, "Forced Form")
                    pkmn.attributes["@forced_form"] = forced_form
                    self.pk_forced_form_var.set(str(forced_form))

            if "@name" in pkmn.attributes:
                pkmn.attributes["@name"] = self.pk_name_var.get().strip()
            if "@obtain_text" in pkmn.attributes:
                pkmn.attributes["@obtain_text"] = self.pk_obtain_text_var.get().strip()
            if "@nature" in pkmn.attributes:
                nature_raw = self.resolve_selected_nature_id(self.pk_nature_var.get())
                pkmn.attributes["@nature"] = core.Symbol(nature_raw) if nature_raw else None
            if "@item" in pkmn.attributes:
                item_raw = self.pk_item_var.get().strip()
                pkmn.attributes["@item"] = core.Symbol(self.resolve_item_id(item_raw)) if item_raw else None
            if "@ability" in pkmn.attributes:
                ability_id = self.resolve_selected_ability_id(self.pk_ability_var.get())
                pkmn.attributes["@ability"] = core.Symbol(ability_id) if ability_id else None
            if "@shiny" in pkmn.attributes:
                pkmn.attributes["@shiny"] = bool(self.pk_shiny_var.get())
            if "@super_shiny" in pkmn.attributes:
                pkmn.attributes["@super_shiny"] = bool(self.pk_super_shiny_var.get())

            moves = core.read_attr(pkmn, "@moves", [])
            if isinstance(moves, list):
                for i in range(min(4, len(moves))):
                    move_obj = moves[i]
                    if not isinstance(move_obj, core.RubyObject):
                        continue
                    move_id = self.resolve_selected_move_id(self.move_id_vars[i].get())
                    if move_id and "@id" in move_obj.attributes:
                        move_obj.attributes["@id"] = core.Symbol(move_id)
                    pp_text = self.move_pp_vars[i].get().strip()
                    ppup_text = self.move_ppup_vars[i].get().strip()
                    ppup_value = self._clamp_int(ppup_text, 0, 3, 0)
                    if "@ppup" in move_obj.attributes:
                        move_obj.attributes["@ppup"] = ppup_value
                    if "@pp" in move_obj.attributes:
                        max_pp = self._move_max_pp(move_id, ppup_value) if move_id else 999
                        move_obj.attributes["@pp"] = self._clamp_int(pp_text, 0, max_pp, max_pp if move_id else 0)
                pkmn.attributes["@moves"] = moves

            if "@first_moves" in pkmn.attributes:
                relearn_ids: list[str] = []
                for i in range(4):
                    mid = self.resolve_selected_relearn_move_id(self.relearn_move_vars[i].get())
                    if mid and mid not in relearn_ids:
                        relearn_ids.append(mid)
                pkmn.attributes["@first_moves"] = [core.Symbol(mid) for mid in relearn_ids]
            self._apply_stat_block_to_pokemon(pkmn, preserve_hp_ratio=True)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Apply Error", str(exc))
            return
        self.mark_modified()
        self._render_party_slot_grid()
        self._load_selected_pokemon_into_editor(pkmn)
        self.set_status(f"Party changes applied ({slot_label}).")

    # ------------------------- Bag tab -------------------------
    def get_selected_bag_pocket_index(self) -> int:
        raw = self.bag_pocket_var.get().strip()
        if raw in self.bag_pocket_option_to_index:
            return self.bag_pocket_option_to_index[raw]
        m = re.match(r"^\s*(\d+)", raw)
        if m:
            return int(m.group(1))
        raw_ci = raw.casefold()
        for idx, label in EN_POCKET_NAMES.items():
            if label.casefold() == raw_ci:
                return idx
        raise ValueError(f"Invalid pocket selection: {raw}")

    def bag_pocket_label(self, index: int) -> str:
        if index in EN_POCKET_NAMES:
            return EN_POCKET_NAMES[index]
        return f"Pocket {index}"

    @staticmethod
    def _parse_pocket_value(value: Any) -> int | None:
        if value is None:
            return None
        if isinstance(value, int):
            return value
        text = str(value).strip()
        if not text:
            return None
        m = re.match(r"^\s*(\d+)", text)
        if m:
            return int(m.group(1))
        return None

    def update_bag_item_dropdown(self):
        if not hasattr(self, "bag_item_combo"):
            return
        if not self.catalogs:
            return
        try:
            pocket_index = self.get_selected_bag_pocket_index()
        except Exception:
            return
        label_pairs: list[tuple[str, str]] = []
        for iid, item in self.catalogs.items_by_id.items():
            p_idx = self._parse_pocket_value(item.extra.get("Pocket", ""))
            if p_idx is None:
                continue
            if p_idx == pocket_index:
                label = self._tm_hm_display_label(iid, pocket_index=pocket_index)
                if any(existing == label for existing, _ in label_pairs):
                    label = f"{label} [{iid}]"
                label_pairs.append((label, iid))
        label_pairs.sort(key=lambda x: x[0].casefold())
        self._bag_item_label_to_id = {label: iid for label, iid in label_pairs}
        self._bag_item_id_to_label = {}
        for label, iid in label_pairs:
            self._bag_item_id_to_label.setdefault(iid, label)
        self._set_combo_values(self.bag_item_combo, [label for label, _ in label_pairs])

        current = self.bag_item_var.get().strip()
        if not current:
            return
        try:
            cur_id = self.resolve_item_id(current)
            cur_item = self.catalogs.items_by_id.get(cur_id)
            cur_pocket = self._parse_pocket_value(cur_item.extra.get("Pocket", "")) if cur_item else None
            if cur_pocket != pocket_index:
                self.bag_item_var.set("")
            elif cur_id in self._bag_item_id_to_label:
                self.bag_item_var.set(self._bag_item_id_to_label[cur_id])
        except Exception:
            self.bag_item_var.set("")

    def on_bag_pocket_selected(self, _event=None):
        self.bag_item_var.set("")
        self.bag_qty_var.set("")
        self.refresh_bag_list()
        self.update_bag_description()

    def get_bag_pocket(self) -> list:
        bag = self.get_root_key("bag")
        if not isinstance(bag, core.RubyObject):
            raise ValueError("Bag section is missing.")
        pockets = core.read_attr(bag, "@pockets", [])
        if not isinstance(pockets, list):
            raise ValueError("Bag pockets format is invalid.")
        pocket_index = self.get_selected_bag_pocket_index()
        if pocket_index < 0 or pocket_index >= len(pockets):
            raise ValueError(f"Pocket index out of range (0-{len(pockets)-1}).")
        pocket = pockets[pocket_index]
        if pocket is None:
            pocket = []
            pockets[pocket_index] = pocket
            bag.attributes["@pockets"] = pockets
        if not isinstance(pocket, list):
            raise ValueError("Pocket is not a list.")
        return pocket

    def refresh_bag_list(self):
        self.bag_list.delete(0, "end")
        self.update_bag_item_dropdown()
        if self.save_data is None:
            self.update_bag_description()
            return
        try:
            pocket = self.get_bag_pocket()
        except Exception as exc:  # noqa: BLE001
            self.set_status(f"Bag load error: {exc}")
            self.update_bag_description()
            return
        for i, entry in enumerate(pocket):
            if isinstance(entry, list) and len(entry) >= 2:
                item_id = symbol_name(entry[0])
                item = self._tm_hm_display_label(self._item_choice(item_id), pocket_index=self.get_selected_bag_pocket_index())
                qty = entry[1]
                self.bag_list.insert("end", f"{i}: {item} x{qty}")
            else:
                self.bag_list.insert("end", f"{i}: {entry}")
        self.update_bag_description()

    def on_bag_item_select(self, _event=None):
        sel = self.bag_list.curselection()
        if not sel:
            return
        idx = int(sel[0])
        try:
            pocket = self.get_bag_pocket()
        except Exception:
            return
        if idx >= len(pocket):
            return
        entry = pocket[idx]
        if isinstance(entry, list) and len(entry) >= 2:
            item_id = symbol_name(entry[0])
            canonical = self._item_choice(item_id)
            self.bag_item_var.set(self._bag_item_id_to_label.get(canonical, self._tm_hm_display_label(canonical)))
            self.bag_qty_var.set(str(entry[1]))
        self.update_bag_description()

    def bag_add_item(self):
        if self.save_data is None:
            return
        try:
            item = self.bag_item_var.get().strip()
            qty = parse_int(self.bag_qty_var.get(), "Quantity")
            if not item:
                raise ValueError("Item symbol is required.")
            pocket_index = self.get_selected_bag_pocket_index()
            pocket = self.get_bag_pocket()
            item_id = self.resolve_item_id(item)
            if self.catalogs:
                item_data = self.catalogs.items_by_id.get(item_id)
                if item_data:
                    item_pocket = int(item_data.extra.get("Pocket", "0"))
                    if item_pocket != pocket_index:
                        raise ValueError(
                            f"Item '{item_data.display_name}' belongs to pocket {item_pocket} "
                            f"({self.bag_pocket_label(item_pocket)}), not pocket {pocket_index} "
                            f"({self.bag_pocket_label(pocket_index)})."
                        )
            pocket.append([core.Symbol(item_id), qty])
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Bag Error", str(exc))
            return
        self.mark_modified()
        self.refresh_bag_list()
        self.set_status("Bag item added.")

    def bag_update_item(self):
        sel = self.bag_list.curselection()
        if not sel:
            messagebox.showwarning("No Selection", "Select a bag item first.")
            return
        idx = int(sel[0])
        try:
            item = self.bag_item_var.get().strip()
            qty = parse_int(self.bag_qty_var.get(), "Quantity")
            if not item:
                raise ValueError("Item symbol is required.")
            pocket_index = self.get_selected_bag_pocket_index()
            pocket = self.get_bag_pocket()
            if idx >= len(pocket):
                return
            item_id = self.resolve_item_id(item)
            if self.catalogs:
                item_data = self.catalogs.items_by_id.get(item_id)
                if item_data:
                    item_pocket = int(item_data.extra.get("Pocket", "0"))
                    if item_pocket != pocket_index:
                        raise ValueError(
                            f"Item '{item_data.display_name}' belongs to pocket {item_pocket} "
                            f"({self.bag_pocket_label(item_pocket)}), not pocket {pocket_index} "
                            f"({self.bag_pocket_label(pocket_index)})."
                        )
            pocket[idx] = [core.Symbol(item_id), qty]
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Bag Error", str(exc))
            return
        self.mark_modified()
        self.refresh_bag_list()
        self.set_status("Bag item updated.")

    def bag_remove_item(self):
        sel = self.bag_list.curselection()
        if not sel:
            messagebox.showwarning("No Selection", "Select a bag item first.")
            return
        idx = int(sel[0])
        try:
            pocket = self.get_bag_pocket()
            if idx < len(pocket):
                pocket.pop(idx)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Bag Error", str(exc))
            return
        self.mark_modified()
        self.refresh_bag_list()
        self.set_status("Bag item removed.")

    # ------------------------- Switches / Variables -------------------------
    def load_switch(self):
        if self.save_data is None:
            return
        try:
            switches = self.get_root_key("switches")
            if not isinstance(switches, core.RubyObject):
                return
            data = core.read_attr(switches, "@data", [])
            idx = parse_int(self.switch_index_var.get(), "Switch index")
            if idx < 0 or idx >= len(data):
                raise ValueError(f"Switch index out of range (0-{len(data)-1})")
            self.switch_value_var.set(bool(data[idx]))
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Switch Error", str(exc))

    def apply_switch(self):
        if self.save_data is None:
            return
        try:
            switches = self.get_root_key("switches")
            if not isinstance(switches, core.RubyObject):
                raise ValueError("Switches section missing.")
            data = core.read_attr(switches, "@data", [])
            idx = parse_int(self.switch_index_var.get(), "Switch index")
            if idx < 0 or idx >= len(data):
                raise ValueError(f"Switch index out of range (0-{len(data)-1})")
            data[idx] = bool(self.switch_value_var.get())
            switches.attributes["@data"] = data
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Switch Error", str(exc))
            return
        self.mark_modified()
        self.set_status("Switch updated.")

    def load_variable(self):
        if self.save_data is None:
            return
        try:
            variables = self.get_root_key("variables")
            if not isinstance(variables, core.RubyObject):
                return
            data = core.read_attr(variables, "@data", [])
            idx = parse_int(self.var_index_var.get(), "Variable index")
            if idx < 0 or idx >= len(data):
                raise ValueError(f"Variable index out of range (0-{len(data)-1})")
            value = data[idx]
            self.var_type_label_var.set(f"Type: {type(value).__name__}")
            self.var_value_var.set(symbol_name(value))
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Variable Error", str(exc))

    def apply_variable(self):
        if self.save_data is None:
            return
        try:
            variables = self.get_root_key("variables")
            if not isinstance(variables, core.RubyObject):
                raise ValueError("Variables section missing.")
            data = core.read_attr(variables, "@data", [])
            idx = parse_int(self.var_index_var.get(), "Variable index")
            if idx < 0 or idx >= len(data):
                raise ValueError(f"Variable index out of range (0-{len(data)-1})")
            current = data[idx]
            raw = self.var_value_var.get()

            if isinstance(current, bool):
                parsed = raw.strip().lower() in {"1", "true", "yes", "y", "on"}
            elif isinstance(current, int) and not isinstance(current, bool):
                parsed = int(raw)
            elif isinstance(current, float):
                parsed = float(raw)
            elif isinstance(current, core.Symbol):
                parsed = core.Symbol(raw.lstrip(":"))
            elif current is None:
                text = raw.strip()
                if text.lower() in {"nil", "none", ""}:
                    parsed = None
                else:
                    try:
                        parsed = int(text)
                    except ValueError:
                        try:
                            parsed = float(text)
                        except ValueError:
                            parsed = text
            elif isinstance(current, (str, core.RubyString, bytes)):
                parsed = raw
            else:
                raise ValueError(
                    f"Variable at index {idx} has unsupported type {type(current).__name__}. "
                    "Use Advanced tab for complex objects."
                )

            data[idx] = parsed
            variables.attributes["@data"] = data
            self.var_type_label_var.set(f"Type: {type(parsed).__name__}")
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Variable Error", str(exc))
            return
        self.mark_modified()
        self.set_status("Variable updated.")

    # ------------------------- Advanced tab -------------------------
    def adv_get(self):
        if self.save_data is None:
            return
        path = self.adv_path_var.get().strip()
        try:
            value = core.get_path_value(self.save_data, path)
            text = core.describe(value, depth=4)
            self.adv_output.delete("1.0", "end")
            self.adv_output.insert("1.0", text)
            if isinstance(value, (str, core.RubyString, int, float, bool, type(None), core.Symbol)):
                self.adv_value_var.set(symbol_name(value))
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Get Error", str(exc))

    def adv_set(self):
        if self.save_data is None:
            return
        path = self.adv_path_var.get().strip()
        raw = self.adv_value_var.get()
        value_type = self.adv_type_var.get()
        try:
            current = core.get_path_value(self.save_data, path)
            parsed = core.parse_value(raw, value_type, current)
            core.set_path_value(self.save_data, path, parsed)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Set Error", str(exc))
            return
        self.mark_modified()
        self.adv_get()
        self.set_status(f"Advanced path updated: {path}")

    def adv_list_children(self):
        if self.save_data is None:
            return
        path = self.adv_path_var.get().strip()
        try:
            value = core.get_path_value(self.save_data, path) if path else self.save_data
            if isinstance(value, core.RubyObject):
                out = "\n".join(sorted(value.attributes.keys()))
            elif isinstance(value, dict):
                out = "\n".join(core.format_atom(k) for k in value.keys())
            elif isinstance(value, (list, tuple)):
                out = "\n".join(str(i) for i in range(len(value)))
            else:
                out = f"Scalar: {core.format_atom(value)}"
            self.adv_output.delete("1.0", "end")
            self.adv_output.insert("1.0", out)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("List Error", str(exc))

    # ------------------------- Legality tab -------------------------
    def normalize_known_ids(self) -> tuple[int, list[str]]:
        if self.save_data is None or not self.catalogs:
            return 0, []

        changes = 0
        unresolved: set[str] = set()

        def normalize_symbol_attr(
            obj: Any,
            attr_name: str,
            canonical_fn,
            unresolved_tag: str,
        ):
            nonlocal changes
            if not isinstance(obj, core.RubyObject):
                return
            if attr_name not in obj.attributes:
                return
            raw = symbol_name(obj.attributes[attr_name]).strip()
            if not raw:
                return
            raw_clean = raw.lstrip(":")
            canonical = canonical_fn(raw_clean)
            if canonical is None:
                unresolved.add(f"{unresolved_tag}:{raw_clean}")
                return
            if canonical != raw_clean:
                obj.attributes[attr_name] = core.Symbol(canonical)
                changes += 1

        player = self.get_root_key("player")
        party = core.read_attr(player, "@party", []) if isinstance(player, core.RubyObject) else []
        if isinstance(party, list):
            for pidx, pkmn in enumerate(party):
                if not isinstance(pkmn, core.RubyObject):
                    continue
                normalize_symbol_attr(
                    pkmn, "@species", self.catalogs.canonical_species_id, f"party[{pidx}].species"
                )
                normalize_symbol_attr(
                    pkmn, "@item", self.catalogs.canonical_item_id, f"party[{pidx}].item"
                )
                normalize_symbol_attr(
                    pkmn, "@ability", self.catalogs.canonical_ability_id, f"party[{pidx}].ability"
                )
                moves = core.read_attr(pkmn, "@moves", [])
                if isinstance(moves, list):
                    for midx, move in enumerate(moves):
                        normalize_symbol_attr(
                            move,
                            "@id",
                            self.catalogs.canonical_move_id,
                            f"party[{pidx}].move[{midx}]",
                        )

        bag = self.get_root_key("bag")
        pockets = core.read_attr(bag, "@pockets", []) if isinstance(bag, core.RubyObject) else []
        if isinstance(pockets, list):
            for pidx, pocket in enumerate(pockets):
                if not isinstance(pocket, list):
                    continue
                for eidx, entry in enumerate(pocket):
                    if not isinstance(entry, list) or len(entry) < 1:
                        continue
                    raw = symbol_name(entry[0]).strip()
                    if not raw:
                        continue
                    raw_clean = raw.lstrip(":")
                    canonical = self.catalogs.canonical_item_id(raw_clean)
                    if canonical is None:
                        unresolved.add(f"bag[{pidx}][{eidx}]:{raw_clean}")
                        continue
                    if canonical != raw_clean:
                        entry[0] = core.Symbol(canonical)
                        changes += 1
        return changes, sorted(unresolved)

    def run_legality_check(self):
        self.legal_output.delete("1.0", "end")
        if self.save_data is None:
            self.legal_output.insert("1.0", "No save loaded.")
            return
        issues: list[str] = []
        warnings: list[str] = []
        if not self.catalogs:
            warnings.append("PBS catalogs are not loaded. ID checks are limited.")

        # Core structure sanity
        core_issues = core.sanity_check_save_data(self.save_data)
        for x in core_issues:
            issues.append(f"[Structure] {x}")

        party = self.get_party()
        for idx, pkmn in enumerate(party):
            if not isinstance(pkmn, core.RubyObject):
                warnings.append(f"[Party #{idx + 1}] Slot is not a Pokemon object.")
                continue

            species = symbol_name(core.read_attr(pkmn, "@species", ""))
            species_key = None
            if self.catalogs and species:
                species_key = self.catalogs.canonical_species_id(species)
                if species_key is None:
                    issues.append(f"[Party #{idx + 1}] Unknown species ID: {species}")

            level = core.read_attr(pkmn, "@level", None)
            if isinstance(level, int) and (level < 1 or level > 100):
                issues.append(f"[Party #{idx + 1}] Level out of range: {level}")

            held_item = symbol_name(core.read_attr(pkmn, "@item", ""))
            if self.catalogs and held_item:
                if self.catalogs.canonical_item_id(held_item) is None:
                    issues.append(f"[Party #{idx + 1}] Unknown held item ID: {held_item}")

            ability = symbol_name(core.read_attr(pkmn, "@ability", ""))
            if self.catalogs and ability:
                if self.catalogs.canonical_ability_id(ability) is None:
                    issues.append(f"[Party #{idx + 1}] Unknown ability ID: {ability}")

            moves = core.read_attr(pkmn, "@moves", [])
            if isinstance(moves, list):
                for mi, move_obj in enumerate(moves):
                    if not isinstance(move_obj, core.RubyObject):
                        warnings.append(f"[Party #{idx + 1} Move #{mi + 1}] Not a move object.")
                        continue
                    move_id = symbol_name(core.read_attr(move_obj, "@id", ""))
                    pp = core.read_attr(move_obj, "@pp", None)
                    ppup = core.read_attr(move_obj, "@ppup", 0)
                    move_key = None
                    if self.catalogs and move_id:
                        move_key = self.catalogs.canonical_move_id(move_id)
                    if self.catalogs and move_id and move_key is None:
                        issues.append(f"[Party #{idx + 1} Move #{mi + 1}] Unknown move ID: {move_id}")
                    if isinstance(pp, int) and pp < 0:
                        issues.append(f"[Party #{idx + 1} Move #{mi + 1}] Negative PP: {pp}")
                    if self.catalogs and move_key and move_key in self.catalogs.moves_by_id and isinstance(pp, int):
                        base = self.catalogs.moves_by_id[move_key].extra.get("TotalPP", "")
                        try:
                            base_pp = int(base)
                            max_pp = int(base_pp * (5 + (ppup if isinstance(ppup, int) else 0)) / 5)
                            if pp > max_pp:
                                warnings.append(
                                    f"[Party #{idx + 1} Move #{mi + 1}] PP {pp} > expected max {max_pp} ({move_key})."
                                )
                        except ValueError:
                            pass

        # Bag check
        bag = self.get_root_key("bag")
        pockets = core.read_attr(bag, "@pockets", []) if isinstance(bag, core.RubyObject) else []
        if isinstance(pockets, list):
            for pidx, pocket in enumerate(pockets):
                if not isinstance(pocket, list):
                    continue
                for eidx, entry in enumerate(pocket):
                    if not isinstance(entry, list) or len(entry) < 2:
                        warnings.append(f"[Bag pocket {pidx} idx {eidx}] Invalid entry structure.")
                        continue
                    iid = symbol_name(entry[0])
                    qty = entry[1]
                    if self.catalogs and iid and self.catalogs.canonical_item_id(iid) is None:
                        issues.append(f"[Bag pocket {pidx} idx {eidx}] Unknown item ID: {iid}")
                    if not isinstance(qty, int) or qty < 0:
                        issues.append(f"[Bag pocket {pidx} idx {eidx}] Invalid quantity: {qty}")

        report = []
        report.append("Legality Check Report")
        report.append("=" * 60)
        report.append(f"Issues: {len(issues)}")
        report.append(f"Warnings: {len(warnings)}")
        report.append("")
        if issues:
            report.append("[Issues]")
            report.extend(f"- {x}" for x in issues)
            report.append("")
        if warnings:
            report.append("[Warnings]")
            report.extend(f"- {x}" for x in warnings)
            report.append("")
        if not issues and not warnings:
            report.append("No obvious legality/consistency problems found.")

        self.legal_output.insert("1.0", "\n".join(report))
        if issues:
            self.set_status("Legality check finished: issues found.")
        else:
            self.set_status("Legality check finished: no hard issues.")

    # ------------------------- Helpers -------------------------
    def _species_choice(self, sid: str) -> str:
        sid = sid.lstrip(":")
        canonical = sid
        if self.catalogs:
            canonical = self.catalogs.canonical_species_id(sid) or sid
        return canonical

    def _move_choice(self, mid: str) -> str:
        mid = mid.lstrip(":")
        canonical = mid
        if self.catalogs:
            canonical = self.catalogs.canonical_move_id(mid) or mid
        return canonical

    def _item_choice(self, iid: str) -> str:
        iid = iid.lstrip(":")
        canonical = iid
        if self.catalogs:
            canonical = self.catalogs.canonical_item_id(iid) or iid
        return canonical

    def _ability_choice(self, aid: str) -> str:
        aid = aid.lstrip(":")
        canonical = aid
        if self.catalogs:
            canonical = self.catalogs.canonical_ability_id(aid) or aid
        return canonical

    def resolve_species_id(self, text: str) -> str:
        value = extract_internal_id(text)
        if self.catalogs:
            return self.catalogs.resolve_species_id(value)
        return value.lstrip(":")

    def resolve_move_id(self, text: str) -> str:
        value = extract_internal_id(text)
        if self.catalogs:
            return self.catalogs.resolve_move_id(value)
        return value.lstrip(":")

    def resolve_item_id(self, text: str) -> str:
        raw = text.strip()
        if hasattr(self, "_bag_item_label_to_id") and raw in self._bag_item_label_to_id:
            return self._bag_item_label_to_id[raw]
        value = extract_internal_id(raw)
        value = re.sub(r"\s+\[[^\]]+\]\s*$", "", value).strip()
        if " - " in value:
            value = value.split(" - ", 1)[0].strip()
        if self.catalogs:
            return self.catalogs.resolve_item_id(value)
        return value.lstrip(":")

    def resolve_ability_id(self, text: str) -> str:
        value = extract_internal_id(text)
        if self.catalogs:
            return self.catalogs.resolve_ability_id(value)
        return value.lstrip(":")

    def get_root_key(self, key_name: str):
        if self.save_data is None:
            return None
        return core.read_root_key(self.save_data, key_name)

    def get_player(self):
        player = self.get_root_key("player")
        if not isinstance(player, core.RubyObject):
            messagebox.showerror("Error", "Player section missing in save.")
            return None
        return player

    def get_party(self) -> list:
        player = self.get_player()
        if not player:
            return []
        party = core.read_attr(player, "@party", [])
        if not isinstance(party, list):
            return []
        return party


def run_self_test() -> int:
    try:
        save_path = core.resolve_save_path(None)
        data = core.load_save(save_path)
        player = core.read_root_key(data, "player")
        money = core.read_attr(player, "@money") if isinstance(player, core.RubyObject) else None
        print(f"OK: loaded {save_path}")
        print(f"Player money: {money}")
        return 0
    except Exception as exc:  # noqa: BLE001
        print(f"SELF-TEST FAILED: {exc}", file=sys.stderr)
        return 1


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Pokemon Indigo Save Editor GUI")
    parser.add_argument("--self-test", action="store_true", help="Run load test and exit.")
    args = parser.parse_args(argv)

    if args.self_test:
        return run_self_test()

    root = tk.Tk()
    SaveEditorApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
