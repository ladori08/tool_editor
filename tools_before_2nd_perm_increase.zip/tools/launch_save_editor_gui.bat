@echo off
setlocal
cd /d "%~dp0\.."
python tools\pokemon_indigo_save_editor_gui.py
endlocal
